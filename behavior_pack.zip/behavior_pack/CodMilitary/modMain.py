# -*- coding: utf-8 -*-
from mod.common.mod import Mod
import mod.server.extraServerApi as serverApi
import mod.client.extraClientApi as clientApi
from CodMilitary import config


@Mod.Binding(name=config.NS, version=config.VERSION)
class RemoteCarMod(object):
    @Mod.InitServer()
    def InitServer(self):
        serverApi.RegisterSystem(config.NS, config.SERVER,
                                 "CodMilitary.server.RemoteCarServer")

    @Mod.InitClient()
    def InitClient(self):
        clientApi.RegisterSystem(config.NS, config.CLIENT,
                                 "CodMilitary.client.RemoteCarClient")

    @Mod.DestroyServer()
    def DestroyServer(self):
        pass

    @Mod.DestroyClient()
    def DestroyClient(self):
        pass
