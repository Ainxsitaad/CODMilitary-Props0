# -*- coding: utf-8 -*-
"""Resource bindings from the generated fixed-vehicle contract (Python 2.7).

Current tablet/car assets are placeholders, not a finished folding computer.
Sockets are model integration references, not live client bone queries.
"""
import copy
from CodMilitary.vehicle_registry import RESOURCE_CONTRACT, VEHICLE_DEFINITIONS

_CAR = RESOURCE_CONTRACT['vehicles']['explosive_car']
CAR_GEOMETRY = _CAR['geometry']
CAR_TEXTURE = _CAR['texture']
# Physical sensor origin retained for the engine, not chase-camera distance.
CAMERA_HEIGHT = VEHICLE_DEFINITIONS['explosive_car']['camera']['anchor_height']
BONE_ALIASES = copy.deepcopy(_CAR['sockets'])
ANIMATION_SLOTS = tuple(sorted(_CAR['animations']))
TABLET_ATTACHABLE_ENABLED = True
CONTROLLER_ITEM = RESOURCE_CONTRACT['controllers']['explosive_car']['item_id']
CONTROLLER_RESOURCE_STATUS = RESOURCE_CONTRACT['controllers']['explosive_car']['status']
SHOUBI_SOURCE_SHA256 = RESOURCE_CONTRACT['arms']['source_sha256']


def vehicle_resources(vehicle_type):
    if vehicle_type not in RESOURCE_CONTRACT['vehicles']:
        raise ValueError('unknown vehicle resource contract')
    return copy.deepcopy(RESOURCE_CONTRACT['vehicles'][vehicle_type])


def controller_resources(vehicle_type='explosive_car'):
    if vehicle_type not in RESOURCE_CONTRACT['controllers']:
        raise ValueError('unknown controller resource contract')
    return copy.deepcopy(RESOURCE_CONTRACT['controllers'][vehicle_type])
