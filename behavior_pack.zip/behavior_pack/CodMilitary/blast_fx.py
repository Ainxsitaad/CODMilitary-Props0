# -*- coding: utf-8 -*-
"""Small bounded test blast flash. Visual only: never applies world damage."""
from collections import OrderedDict
from CodMilitary.audio import valid_position


class BlastFlash(object):
    def __init__(self, factory, level):
        self.factory, self.level = factory, level
        self.component = None
        self.seen = OrderedDict()
        self.active = {}

    def event(self, event_id, position, tick):
        pos = valid_position(position)
        if pos is None or event_id in self.seen or len(self.active) >= 8:
            return False
        self.seen[event_id] = True
        while len(self.seen) > 128:
            self.seen.popitem(last=False)
        if self.component is None:
            self.component = self.factory.CreateParticleSystem(self.level)
        particle = self.component.Create('cm:vehicle_blast_test',
            (pos[0], pos[1] + .3, pos[2]), (0., 0., 0.))
        if not particle:
            return False
        self.active[particle] = tick + 60
        return True

    def update(self, tick, clear=False):
        if self.component is None:
            return
        for particle, expires in list(self.active.items()):
            if clear or tick >= expires:
                if self.component.Remove(particle) is not False:
                    self.active.pop(particle, None)

