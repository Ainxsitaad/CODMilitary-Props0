# -*- coding: utf-8 -*-
"""Render-frame aircraft pose, independent of physical motion and camera anchors.

Only the caller's verified aircraft are tracked. GetRot supplies the replicated
heading target; it is never confused with GetBodyRot. The animation subtracts
query.body_y_rotation *in its render context*, then applies local pitch/roll in
separate child bones. No position, physical rotation or camera is written here.
"""
from CodMilitary.camera_follow import monotonic_time, number
from CodMilitary.flight_dynamics import advance_axis, wrap_degrees
from CodMilitary.sdk_compat import sdk_argument


QUERY_PREFIX = 'query.mod.cg_rc_flight_'
QUERIES = dict((name, QUERY_PREFIX + name) for name in ('active', 'yaw', 'pitch', 'roll', 'lease'))
KINDS = frozenset(('bomb_glider', 'bomb_drone'))


class FlightVisual(object):
    MAX_TRACKED = 64
    MISSING_TIMEOUT_SECONDS = 1.0
    MISSING_RETRY_SECONDS = .10
    MAX_FRAME_GAP = .25
    RETRY_SECONDS = 1.0
    RESPONSE_SECONDS = .06
    LEASE_SECONDS = .25
    LEASE_REFRESH_SECONDS = .10

    def __init__(self, factory, level_id, logger=None):
        self.f = factory
        self.level = level_id
        self.logger = logger
        self.rows = {}
        self.registered = set()
        self.register_retry = 0.0
        self.closed = False
        self.frames = 0
        self.failures = 0
        self.last_now = None
        self.warned = set()

    def _warn(self, label, error):
        if label in self.warned:
            return
        self.warned.add(label)
        if self.logger is not None:
            try:
                if callable(self.logger):
                    self.logger('flight_visual %s: %s' % (label, error))
                else:
                    self.logger.warning('[RemoteCar] flight_visual %s: %s', label, error)
            except Exception:
                pass

    def _register(self, now):
        if len(self.registered) == len(QUERIES):
            return True
        if now < self.register_retry:
            return False
        try:
            component = self.f.CreateQueryVariable(self.level)
            for key in QUERIES:
                if key not in self.registered:
                    if component.Register(sdk_argument(QUERIES[key]), 0.0) is not True:
                        raise ValueError('query registration rejected: ' + key)
                    self.registered.add(key)
            return True
        except Exception as exc:
            self.register_retry = now + self.RETRY_SECONDS
            self._warn('register', exc)
            return False

    def track(self, entity_id, vehicle_type):
        """Caller must verify AddEntity identifier or a trusted status snapshot.

        Unknown kinds are rejected before creating an SDK component. No world
        scans or query writes on unrelated entities are performed by this class.
        """
        # Exact aliases only: a foreign namespace must not become our aircraft.
        kind = {'bomb_glider': 'bomb_glider', 'cg_rc:bomb_glider': 'bomb_glider',
                'bomb_drone': 'bomb_drone', 'cg_rc:bomb_drone': 'bomb_drone'}.get(vehicle_type)
        if self.closed or not entity_id or kind not in KINDS:
            return False
        existing = self.rows.get(entity_id)
        if existing is not None:
            return existing['kind'] == kind
        if len(self.rows) >= self.MAX_TRACKED:
            return False
        self.rows[entity_id] = dict(kind=kind, pose=None, velocity=(0., 0., 0.),
            target=None, now=None, active=False, missing=0, retry=0., error=None,
            rot=None, query=None, lease_refresh=0., missing_since=None)
        return True

    def _component(self, entity_id, row, key):
        if row[key] is None:
            maker = self.f.CreateRot if key == 'rot' else self.f.CreateQueryVariable
            row[key] = maker(entity_id)
        return row[key]

    def _disable(self, entity_id, row):
        row['active'] = False
        if 'active' not in self.registered:
            return
        try:
            self._component(entity_id, row, 'query').Set(sdk_argument(QUERIES['active']), 0.0)
        except Exception:
            # Removed/unloaded entities may reject their final write. Values are
            # entity-scoped. A refused final write is bounded by the Molang lease,
            # not falsely assumed to have erased the engine's previous value.
            pass

    def reset(self, entity_id):
        row = self.rows.get(entity_id)
        if row is None:
            return False
        self._disable(entity_id, row)
        row.update(pose=None, velocity=(0., 0., 0.), target=None, now=None,
                   missing=0, retry=0., error=None, lease_refresh=0., missing_since=None)
        return True

    def untrack(self, entity_id):
        row = self.rows.pop(entity_id, None)
        if row is not None:
            self._disable(entity_id, row)
        return row is not None

    def clear(self):
        for entity_id in list(self.rows):
            self.untrack(entity_id)
        self.last_now = None

    def close(self):
        self.clear()
        self.closed = True
        # Do not unregister shared engine names while another client system or
        # reload might still evaluate them. The default active value is zero.

    def _target(self, entity_id, row):
        value = self._component(entity_id, row, 'rot').GetRot()
        if not isinstance(value, (tuple, list)) or len(value) != 2:
            raise ValueError('aircraft orientation unavailable')
        pitch, yaw = number(value[0], None), number(value[1], None)
        if pitch is None or yaw is None or abs(pitch) > 180. or abs(yaw) > 360000.:
            raise ValueError('invalid aircraft orientation')
        return (min(89., max(-89., pitch)), wrap_degrees(yaw))

    def _write(self, entity_id, row):
        component = self._component(entity_id, row, 'query')
        renew = not row['active'] or row['now'] >= row['lease_refresh']
        life = None
        if renew:
            life = number(component.GetMolangValue(sdk_argument('query.life_time')), None)
            if life is None or life < 0.:
                raise ValueError('aircraft render lifetime unavailable')
        # Write all channels before enabling the layer. On any rejected channel,
        # disable the whole layer. If even disabling is rejected, the old lease
        # expires in <=.25 game seconds; no permanently frozen pose is left active.
        for name, value in zip(('pitch', 'yaw', 'roll'), row['pose']):
            if component.Set(sdk_argument(QUERIES[name]), float(value)) is not True:
                raise ValueError('query write rejected: ' + name)
        if renew:
            if component.Set(sdk_argument(QUERIES['lease']), life + self.LEASE_SECONDS) is not True:
                raise ValueError('query write rejected: lease')
            if component.Set(sdk_argument(QUERIES['active']), 1.0) is not True:
                raise ValueError('query write rejected: active')
            row['lease_refresh'] = row['now'] + self.LEASE_REFRESH_SECONDS
        row['active'] = True

    def render(self, now=None):
        if self.closed or not self.rows:
            return
        now = monotonic_time() if now is None else number(now, None)
        if now is None:
            for entity_id, row in self.rows.items():
                self._disable(entity_id, row)
                row['pose'], row['now'] = None, None
            return
        self.frames += 1
        if self.last_now is not None and now < self.last_now:
            self.register_retry = 0.
            for row in self.rows.values():
                row['retry'] = 0.
                row['lease_refresh'] = 0.
                row['missing_since'] = None
        self.last_now = now
        if not self._register(now):
            return
        for entity_id, row in list(self.rows.items()):
            if now < row['retry']:
                continue
            try:
                target = self._target(entity_id, row)
            except Exception as exc:
                self._disable(entity_id, row)
                row['missing'] += 1
                row['error'] = str(exc)
                row['pose'], row['now'] = None, None
                row['rot'], row['query'] = None, None
                if row['missing_since'] is None:
                    row['missing_since'] = now
                row['retry'] = now + self.MISSING_RETRY_SECONDS
                # AddEntity may precede a usable rotation component. Observe a
                # time window instead of discarding other players after 3 frames.
                if now - row['missing_since'] >= self.MISSING_TIMEOUT_SECONDS:
                    self.untrack(entity_id)
                continue
            row['missing'] = 0
            row['missing_since'] = None
            dt = now - row['now'] if row['now'] is not None else 0.
            row['target'], row['now'] = target, now
            if row['pose'] is None or dt < 0. or dt > self.MAX_FRAME_GAP:
                row['pose'] = (target[0], target[1], 0.)
                row['velocity'] = (0., 0., 0.)
            elif dt > 0.:
                pitch, vp = advance_axis(row['pose'][0], row['velocity'][0], target[0], dt,
                    self.RESPONSE_SECONDS, 720., 12000., lower=-89., upper=89.)
                yaw, vy = advance_axis(row['pose'][1], row['velocity'][1], target[1], dt,
                    self.RESPONSE_SECONDS, 720., 12000., wrapped=True)
                limit, gain = (18., .08) if row['kind'] == 'bomb_glider' else (9., .04)
                bank = min(limit, max(-limit, -vy * gain))
                roll, vr = advance_axis(row['pose'][2], row['velocity'][2], bank, dt,
                    .10, 180., 2400., lower=-limit, upper=limit)
                row['pose'], row['velocity'] = (pitch, yaw, roll), (vp, vy, vr)
            try:
                self._write(entity_id, row)
                row['error'] = None
            except Exception as exc:
                self.failures += 1
                self._disable(entity_id, row)
                row['pose'], row['now'] = None, None
                row['retry'] = now + self.RETRY_SECONDS
                row['error'] = str(exc)
                self._warn('set', exc)

    def snapshot(self, entity_id=None):
        """Small JSON-compatible QA snapshot, never an engine state claim."""
        def sample(row):
            return dict(kind=row['kind'], active=row['active'], target=row['target'],
                        pose=row['pose'], angular_velocity=row['velocity'], error=row['error'])
        if entity_id is not None:
            row = self.rows.get(entity_id)
            return sample(row) if row else None
        return dict(tracked=len(self.rows), frames=self.frames, failures=self.failures,
                    registered=len(self.registered), entities=dict((key, sample(row))
                    for key, row in self.rows.items()))
