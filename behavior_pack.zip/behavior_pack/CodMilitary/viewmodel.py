# -*- coding: utf-8 -*-
"""Local player render layers, independent of the currently selected item.

Only names owned by this add-on are registered/removed. Inventory selection is
never delayed or rewritten: the outgoing presentation may outlive that item.
"""
from CodMilitary import presentation, catalog
from CodMilitary.config import CAPSULE_ITEM
from CodMilitary.sdk_compat import sdk_argument

ITEM_QUERY = 'query.mod.cg_rc_vm_item'
VISIBLE_QUERY = 'query.mod.cg_rc_vm_visible'
READY_QUERY = 'query.mod.cg_rc_vm_ready'
ITEMS = {'car': CAPSULE_ITEM}
ITEM_INDEX = {'car': 2}
for number, item in enumerate(catalog.CONTROLLER_ITEMS):
    key = item.split(':', 1)[-1]
    ITEMS[key] = item
    ITEM_INDEX[key] = 1 if number == 0 else number + 2
for item in catalog.VEHICLE_ITEMS:
    if item == CAPSULE_ITEM:
        continue
    key = presentation.hand_config(item)['kind']
    ITEMS[key] = item
    ITEM_INDEX[key] = max(ITEM_INDEX.values()) + 1
KINDS = ('arms',) + tuple(sorted(ITEMS, key=lambda key: ITEM_INDEX[key]))
ACTIONS = {'tablet': ('idle', 'draw', 'holster', 'inspect', 'connect_open'),
           'car': ('idle', 'draw', 'holster', 'inspect', 'place')}
CONDITION = ('query.mod.cg_rc_vm_visible > 0 && variable.is_first_person '
             '&& query.is_alive && !query.is_sleeping')


def animation_groups(kind, action):
    family = presentation.hand_config(ITEMS[kind]).get('kind', 'car')
    return [(presentation.animation_identifier(ITEMS[kind], action, family), None)]


def item_index(item):
    return next((ITEM_INDEX[key] for key, value in ITEMS.items() if value == item), 0)


class PlayerViewModel(object):
    def __init__(self, factory, player, level):
        self.factory, self.player, self.level = factory, player, level
        self.render = None
        self.ready = False
        self.last_state = None
        # Compatibility state for objects created before the 0.4 live fix.
        # New presentation never changes native held-item visibility.
        self.hidden = False
        self.retry_after = 0
        self.registered_queries = set()
        self.geometries = set()
        self.controllers = set()
        self.scripts = set()
        self.cleanup_jobs = []

    def checked(self, method, *args):
        sdk_args = tuple(sdk_argument(value) for value in args)
        if method(*sdk_args) is False:
            raise RuntimeError('viewmodel API rejected %s%r' % (
                getattr(method, '__name__', 'call'), sdk_args))

    def install(self, tick):
        if self.cleanup_jobs:
            self.flush_cleanup()
        if self.ready or tick < self.retry_after:
            return self.ready
        self.retry_after = tick + 60
        self.render = self.factory.CreateActorRender(self.player)
        register = self.factory.CreateQueryVariable(self.level).Register
        for query in (ITEM_QUERY, VISIBLE_QUERY, READY_QUERY):
            if query not in self.registered_queries:
                self.checked(register, query, 0.0)
                self.registered_queries.add(query)
        comp = self.render
        try:
            self.checked(comp.AddPlayerRenderMaterial, 'cg_rc_vm', 'entity_alphatest')
            for kind, item in ITEMS.items():
                hand = presentation.hand_config(item)
                family = hand.get('kind', 'car')
                self.checked(comp.AddPlayerTexture, 'cg_rc_vm_' + kind,
                             hand.get('texture', 'textures/entity/cg_rc/' + family + '_viewmodel'))
            for kind in KINDS:
                hand = presentation.hand_config(ITEMS[kind]) if kind in ITEMS else {}
                family = 'arms' if kind == 'arms' else hand.get('kind', 'car')
                self.checked(comp.AddPlayerGeometry, 'cg_rc_vm_' + kind,
                             hand.get('geometry', 'geometry.cg_rc.viewmodel_' + family))
                self.geometries.add('cg_rc_vm_' + kind)
                condition = CONDITION
                if kind != 'arms':
                    condition += ' && query.mod.cg_rc_vm_item == %d' % ITEM_INDEX[kind]
                self.checked(comp.AddPlayerRenderController,
                             'controller.render.cg_rc.viewmodel_' + kind, condition)
                self.controllers.add('controller.render.cg_rc.viewmodel_' + kind)
            self.checked(comp.AddPlayerAnimation, 'cg_rc_vm_align', 'animation.cg_rc.viewmodel_align')
            self.checked(comp.AddPlayerScriptAnimate, 'cg_rc_vm_align', CONDITION, True)
            self.scripts.add('cg_rc_vm_align')
            for kind in KINDS[1:]:
                family = presentation.hand_config(ITEMS[kind]).get('kind', 'car')
                actions = ACTIONS['tablet' if family == 'tablet' else 'car']
                for action in actions:
                    condition = CONDITION + ' && query.mod.cg_rc_vm_item == %d && %s == %d' % (
                        ITEM_INDEX[kind], presentation.HAND_ACTION_QUERY,
                        presentation.HAND_ACTIONS[action])
                    if action == 'idle':
                        condition = CONDITION + ' && query.mod.cg_rc_vm_item == %d && ' % (
                            ITEM_INDEX[kind]) + ' && '.join(
                                '%s != %d' % (presentation.HAND_ACTION_QUERY, presentation.HAND_ACTIONS[name])
                                for name in actions if name != 'idle')
                    for identifier, indices in animation_groups(kind, action):
                        key = 'cg_rc_vm_' + kind + '_' + action
                        final_condition = condition
                        if identifier != 'animation.cg_rc.viewmodel_' + family + '.' + action:
                            # Non-default clips get a separate owned alias; the
                            # default family clip remains gated to its own items.
                            key += '_configured'
                        self.checked(comp.AddPlayerAnimation, key, identifier)
                        self.checked(comp.AddPlayerScriptAnimate, key, final_condition, True)
                        self.scripts.add(key)
            self.checked(comp.RebuildPlayerRender)
            self.ready = True
            self.checked(self.factory.CreateQueryVariable(self.player).Set, READY_QUERY, 1.0)
            return True
        except Exception:
            self.close()
            raise

    def show(self, item_index, visible):
        if not self.ready:
            return
        state = (float(item_index), float(bool(visible and item_index)))
        if self.last_state == state:
            return
        query = self.factory.CreateQueryVariable(self.player)
        for key, value in zip((ITEM_QUERY, VISIBLE_QUERY), state):
            self.checked(query.Set, key, value)
        self.last_state = state
        # Extra player layers retain native hand visibility; attachable fallback
        # is gated by READY_QUERY and only the native FP arm bones are hidden.

    def close(self):
        self.ready = False
        self.last_state = None
        if not self.cleanup_jobs:
            # Restore only a legacy object that records our previous mutation.
            if self.render and self.hidden:
                self.cleanup_jobs.append(('SetPlayerItemInHandVisible', (True, 2)))
            for name in self.registered_queries:
                self.cleanup_jobs.append(('query', (name, 0.0)))
            for name in self.controllers:
                self.cleanup_jobs.append(('RemovePlayerRenderController', (name,)))
            for name in self.geometries:
                self.cleanup_jobs.append(('RemovePlayerGeometry', (name,)))
            # There is no RemovePlayerScriptAnimate API. Disable only our keys.
            for name in self.scripts:
                self.cleanup_jobs.append(('AddPlayerScriptAnimate', (name, '0.0', True)))
            if self.controllers or self.geometries or self.scripts:
                self.cleanup_jobs.append(('RebuildPlayerRender', ()))
        self.flush_cleanup()

    def flush_cleanup(self):
        pending, errors = [], []
        for name, args in self.cleanup_jobs:
            if name == 'RebuildPlayerRender' and pending:
                pending.append((name, args))
                continue
            try:
                # Resolve query independently so an unavailable entity does not
                # prevent restoring native hand visibility or owned render keys.
                method = (self.factory.CreateQueryVariable(self.player).Set if name == 'query'
                          else getattr(self.render, name))
                self.checked(method, *args)
                if name == 'SetPlayerItemInHandVisible':
                    self.hidden = False
            except Exception as exc:
                pending.append((name, args))
                errors.append(exc)
        self.cleanup_jobs = pending
        if not pending:
            self.geometries.clear()
            self.controllers.clear()
            self.scripts.clear()
        if errors:
            raise errors[0]
