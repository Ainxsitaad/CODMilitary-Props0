# -*- coding: utf-8 -*-
"""Server-owned rider/decoy transaction. No inventory copies or persistent immunity.

DamageEvent carries *raw* damage. Only an internal Hurt call may damage the
hidden rider; normal engine armour/buffs are evaluated once on the real player.
SDK Hurt event re-entry is expected to be synchronous and requires live QA.
The persisted return receipt is removed last, after return/death and cleanup.
"""
import json
import math
import uuid

PROXY_TYPE = 'cg_rc:operator_proxy'
HIDDEN_KEY = 'cm.vehicle.rider_hidden'
PENDING_KEY = 'cm.operator.return.v1'
PROXY_TAG = 'cm.operator.proxy.v1'
VERSION = 1


def number(value):
    if isinstance(value, bool):
        return None
    try:
        value = float(value)
        return value if not math.isnan(value) and not math.isinf(value) else None
    except (TypeError, ValueError, OverflowError):
        return None


def point(value):
    if not isinstance(value, (tuple, list)) or len(value) != 3:
        return None
    result = tuple(number(v) for v in value)
    return result if all(v is not None and abs(v) <= 30000000 for v in result) else None


def near(a, b, tolerance=.20):
    a, b = point(a), point(b)
    return bool(a and b and sum((a[i]-b[i])**2 for i in range(3)) <= tolerance*tolerance)


class OperatorLink(object):
    def __init__(self, port):
        self.port, self.f = port, port.f
        self.rows = {}
        self.proxies = {}
        self.service = None
        self.forwarding = set()
        self.syncing = set()
        self.killing = set()
        self.created = set()
        self.removed = set()
        self.ticks = 0

    def bind_service(self, service):
        self.service = service

    def _safe(self, label, action, default=None):
        return self.port.safe('operator '+label, action, default)

    def _read(self, player):
        value = self.f.CreateExtraData(player).GetExtraData(PENDING_KEY)
        if value is None:
            return None
        if not isinstance(value, dict):
            value = json.loads(value)
        if (not isinstance(value, dict) or value.get('version') != VERSION or
                not value.get('token') or not value.get('owner') or
                point(value.get('anchor')) is None or
                isinstance(value.get('dimension'), bool) or
                not isinstance(value.get('dimension'), int)):
            raise ValueError('invalid pending operator return; refusing replacement')
        return value

    def _write(self, row):
        data = json.dumps(row['journal'], ensure_ascii=True, allow_nan=False,
                          sort_keys=True, separators=(',', ':'))
        component = self.f.CreateExtraData(row['player'])
        return (component.SetExtraData(PENDING_KEY, data, True) is True and
                component.GetExtraData(PENDING_KEY) == data)

    def _persist(self, row):
        return self._safe('persist return', lambda: self._write(row), False) is True

    def _clear_pending(self, row):
        component = self.f.CreateExtraData(row['player'])
        return (component.SetExtraData(PENDING_KEY, None, True) is True and
                component.GetExtraData(PENDING_KEY) is None)

    def _tag(self, row):
        return dict(token=row['journal']['token'], owner=row['journal']['owner'])

    def _proxy_owned(self, row):
        proxy = row['journal'].get('proxy_id')
        if not proxy or proxy in self.removed:
            return False
        return self._safe('proxy identity', lambda:
            self.f.CreateEngineType(proxy).GetEngineTypeStr() == PROXY_TYPE and
            self.f.CreateExtraData(proxy).GetExtraData(PROXY_TAG) == self._tag(row), False) is True

    def _hide(self, player, value):
        def apply():
            comp = self.f.CreateModAttr(player)
            # SetAttr is a void SDK method. Readback, not a guessed bool return,
            # is the visibility receipt.
            comp.SetAttr(HIDDEN_KEY, bool(value), False, False)
            return comp.GetAttr(HIDDEN_KEY) == bool(value)
        return self._safe('visibility state', apply, False) is True

    def _context(self, row):
        context = self._safe('player context', lambda: self.port.player_context(row['player']))
        return context if context and context.get('owner') == row['journal']['owner'] else None

    def _mounted(self, row):
        riders = self._safe('riders', lambda: self.f.CreateRide(
            row['journal']['entity_id']).GetRiders())
        if not isinstance(riders, list):
            return None
        return any(isinstance(v, dict) and v.get('entityId') == row['player'] for v in riders)

    def _chunk(self, dimension, pos):
        block = tuple(int(math.floor(v)) for v in pos)
        return self._safe('return chunk', lambda: self.f.CreateChunkSource(
            self.port.level).CheckChunkState(dimension, block), False) is True

    def _position(self, entity):
        return point(self._safe('position', lambda: self.f.CreatePos(entity).GetFootPos()))

    def _dimension(self, entity):
        return self._safe('dimension', lambda: self.f.CreateDimension(entity).GetEntityDimensionId())

    def _sync_health(self, row):
        if not self._proxy_owned(row):
            return False
        player, proxy = row['player'], row['journal']['proxy_id']
        health = self.port.entity_health(player)
        if health is None or health <= 0:
            return False
        kind = self.port.enums.AttrType.HEALTH
        maximum = number(self._safe('maximum health', lambda:
            self.f.CreateAttr(player).GetAttrMaxValue(kind)))
        if maximum is None or maximum < health:
            return False
        def apply():
            self.syncing.add(proxy)
            try:
                comp = self.f.CreateAttr(proxy)
                if (number(comp.GetAttrValue(kind)) == health and
                        number(comp.GetAttrMaxValue(kind)) == maximum):
                    return True
                return (comp.SetAttrMaxValue(kind, maximum) is True and
                        comp.SetAttrValue(kind, health, 0) is True and
                        number(comp.GetAttrValue(kind)) == health)
            finally:
                self.syncing.discard(proxy)
        return self._safe('proxy health', apply, False) is True

    def begin(self, record, context):
        player = record.get('player')
        if (not player or player in self.rows or not context or not context.get('alive') or
                context.get('owner') != record.get('owner') or
                point(context.get('position')) is None or not record.get('session') or
                not self.port.owned(record)):
            return False
        try:
            if self._read(player) is not None:
                return False
        except Exception as exc:
            self.port.warn('operator pending read', exc)
            return False
        journal = dict(version=VERSION, token=uuid.uuid4().hex, owner=record['owner'],
            session=record['session'], vehicle_id=record['vehicle_id'],
            entity_id=record['entity_id'], proxy_id=None,
            anchor=list(context['position']), dimension=context['dimension'],
            yaw=float(context.get('yaw', 0.)), death_pending=False)
        row = dict(player=player, record=record, journal=journal, phase='preparing',
                   death_confirmed=False, finishing=False, authorized=False)
        self.rows[player] = row
        record['operator'] = row['journal']
        # The first durable receipt is written before any teleport/mount.
        if not self._persist(row):
            self.rows.pop(player, None)
            record.pop('operator', None)
            return False
        try:
            if not self._chunk(journal['dimension'], journal['anchor']):
                raise ValueError('operator origin chunk unavailable')
            proxy = self.port.system.CreateEngineEntityByTypeStr(PROXY_TYPE,
                tuple(journal['anchor']), (0., journal['yaw']), journal['dimension'])
            if proxy in (None, '', '-1'):
                raise ValueError('proxy creation failed')
            self.created.add(proxy)
            self.removed.discard(proxy)
            journal['proxy_id'] = proxy
            self.proxies[proxy] = player
            tag = self.f.CreateExtraData(proxy)
            if (tag.SetExtraData(PROXY_TAG, self._tag(row), True) is not True or
                    tag.GetExtraData(PROXY_TAG) != self._tag(row)):
                raise ValueError('proxy tag rejected')
            self.created.discard(proxy)
            # A tagged creation can be rediscovered by token if the following
            # player-journal write is interrupted before the ID reaches disk.
            if not self._persist(row):
                raise ValueError('proxy receipt write failed')
            if not self._sync_health(row) or not self._hide(player, True):
                raise ValueError('proxy health/visibility rejected')
            row['authorized'] = True
            accepted = self.f.CreateRide(record['entity_id']).SetRiderRideEntity(
                player, record['entity_id'], 0)
            row['authorized'] = False
            if accepted is not True or self._mounted(row) is not True:
                raise ValueError('native ride was not confirmed')
            row['phase'] = 'mounted'
            return True
        except Exception as exc:
            row['authorized'] = False
            self.port.warn('operator prepare', exc)
            row['phase'] = 'returning'
            self.finish(record, 'operator_prepare_failed')
            return False

    def _safe_return_point(self, row):
        journal = row['journal']
        anchor = tuple(journal['anchor'])
        if self._proxy_owned(row):
            actual = self._position(journal['proxy_id'])
            if actual and self._dimension(journal['proxy_id']) == journal['dimension']:
                anchor = actual
        # Prefer the actual decoy foot. If a new block obstructs it, use a small
        # local escape, never a distant spawn/world coordinate guess.
        offsets = ((0,0,0), (0,1,0), (0,2,0), (1,0,0), (-1,0,0), (0,0,1), (0,0,-1))
        blocks = self.f.CreateBlockInfo(self.port.level)
        for delta in offsets:
            candidate = tuple(anchor[i]+delta[i] for i in range(3))
            if not self._chunk(journal['dimension'], candidate):
                continue
            clear = True
            for x in (candidate[0]-.31, candidate[0]+.31):
                for z in (candidate[2]-.31, candidate[2]+.31):
                    for y in (candidate[1]+.01, candidate[1]+.90, candidate[1]+1.79):
                        pos = tuple(int(math.floor(v)) for v in (x,y,z))
                        block = self._safe('return clearance', lambda p=pos:
                            blocks.GetBlockNew(p, journal['dimension']))
                        if not isinstance(block, dict) or block.get('name') != 'minecraft:air':
                            clear = False
            if clear:
                return candidate
        return None

    def _request_chunk(self, row):
        if row.get('chunk_pending') or self.ticks < row.get('chunk_retry', 0):
            return
        row['chunk_pending'] = True
        row['chunk_retry'] = self.ticks+30
        p = row['journal']['anchor']
        lo = tuple(int(math.floor(v))-1 for v in p)
        hi = tuple(int(math.floor(v))+1 for v in p)
        def done(data):
            row['chunk_pending'] = False
        result = self._safe('load return chunk', lambda: self.f.CreateChunkSource(
            self.port.level).DoTaskOnChunkAsync(row['journal']['dimension'], lo, hi, done), False)
        if result is not True:
            row['chunk_pending'] = False

    def _return(self, row):
        context = self._context(row)
        if not context:
            return False
        if row.get('death_write_pending'):
            if not self._persist(row):
                return False
            row.pop('death_write_pending', None)
        if row.get('death_confirmed'):
            row['returned'] = True
            return True
        if row.get('returned') and not row['journal'].get('death_pending'):
            return True
        if self.port.entity_health(row['player']) == 0:
            row['death_confirmed'] = True
            row['returned'] = True
            return True
        target = self._safe_return_point(row)
        if target is None:
            self._request_chunk(row)
            return False
        # Persist an updated decoy/escape position before moving the player.
        if not near(target, row['journal']['anchor'], .001):
            row['journal']['anchor'] = list(target)
            if not self._persist(row):
                return False
        mounted = self._safe('player riding', lambda:
            self.f.CreateRide(row['player']).IsEntityRiding())
        if mounted is not False:
            self._safe('dismount', lambda: self.f.CreateRide(row['player']).StopEntityRiding(), False)
            mounted = self._safe('player riding', lambda:
                self.f.CreateRide(row['player']).IsEntityRiding())
            if mounted is not False:
                return False
        player, dimension = row['player'], row['journal']['dimension']
        if self._dimension(player) != dimension:
            # ChangePlayerDimension takes the player's HEAD, not feet.
            head = (target[0], target[1]+1.62, target[2])
            if self._safe('return dimension', lambda: self.f.CreateDimension(player).
                    ChangePlayerDimension(dimension, head), False) is not True:
                return False
            if self._dimension(player) != dimension:
                return False
        if not near(self._position(player), target):
            if self._safe('return feet', lambda: self.f.CreatePos(player).
                    SetFootPos(target), False) is not True:
                return False
        if self._dimension(player) != dimension or not near(self._position(player), target):
            return False
        row['returned'] = True
        self._safe('return stop motion', lambda: self.f.CreateActorMotion(player).SetMotion((0.,0.,0.)))
        if row['journal'].get('death_pending'):
            # Do not change game mode to manufacture death in creative.
            # The attempt is durable before entering a possibly fatal API.
            # After a process interruption an ambiguous attempt is never
            # replayed against a player who may already have respawned.
            row['journal']['death_attempted'] = True
            if not self._persist(row):
                return False
            self.killing.add(player)
            try:
                self._safe('operator death', lambda: self.port.game.KillEntity(player), False)
            finally:
                self.killing.discard(player)
            if self.port.entity_health(player) != 0 and not row.get('death_confirmed'):
                return False
            row['death_confirmed'] = True
            row['journal']['death_confirmed'] = True
            self._persist(row)
        return True

    def _cleanup(self, row):
        if not self._context(row):
            return False
        if not self._hide(row['player'], False):
            return False
        proxy = row['journal'].get('proxy_id')
        if proxy and row['journal'].get('proxy_removed'):
            self.removed.add(proxy)
        if not proxy or (proxy not in self.removed and proxy not in self.created and
                         not self._proxy_owned(row)):
            if not self._resolve_proxy(row):
                return False
            proxy = row['journal'].get('proxy_id')
        if proxy and proxy not in self.removed:
            # created is an exact-ID same-process creation receipt. Restarted
            # cleanup requires both persistent tag and entity type to match.
            if not self._proxy_owned(row) and proxy not in self.created:
                return False
            # DestroyEntity may synchronously emit EntityRemoveEvent. This is
            # the successful return transaction cleaning its own exact proxy,
            # not an external loss that should cancel a queued detonation.
            row['cleaning_proxy'] = proxy
            try:
                destroyed = self._safe('destroy proxy', lambda:
                    self.port.system.DestroyEntity(proxy), False)
            finally:
                row.pop('cleaning_proxy', None)
            if destroyed is not True:
                return False
            self.removed.add(proxy)
        if proxy and proxy in self.removed and not row['journal'].get('proxy_removed'):
            row['journal']['proxy_removed'] = True
            if not self._persist(row):
                return False
        if self._safe('clear return receipt', lambda: self._clear_pending(row), False) is not True:
            return False
        self.rows.pop(row['player'], None)
        self.proxies.pop(proxy, None)
        self.created.discard(proxy)
        self.removed.discard(proxy)
        row['record'].pop('operator', None)
        for previous in row.get('previous_records', []):
            previous.pop('operator', None)
        return True

    def _resolve_proxy(self, row):
        """Recover changed entity IDs using a bounded origin query and exact tag."""
        journal = row['journal']
        anchor = journal['anchor']
        if not self._chunk(journal['dimension'], anchor):
            self._request_chunk(row)
            return False
        low = tuple(int(math.floor(v))-4 for v in anchor)
        high = tuple(int(math.floor(v))+5 for v in anchor)
        candidates = self._safe('find return proxy', lambda:
            self.port.game.GetEntitiesInSquareArea(None, low, high, journal['dimension']))
        if not isinstance(candidates, list):
            return False
        matches = []
        for entity in candidates:
            matched = self._safe('find proxy identity', lambda e=entity:
                self.f.CreateEngineType(e).GetEngineTypeStr() == PROXY_TYPE and
                self.f.CreateExtraData(e).GetExtraData(PROXY_TAG) == self._tag(row), False)
            if matched:
                matches.append(entity)
        if len(matches) == 1:
            row.pop('missing_count', None)
            old = journal.get('proxy_id')
            journal['proxy_id'] = matches[0]
            if not self._persist(row):
                journal['proxy_id'] = old
                return False
            self.proxies.pop(old, None)
            self.proxies[matches[0]] = row['player']
            return True
        # No proxy was ever recorded and no matching tagged creation exists.
        # No movement occurs before the post-creation receipt is durable.
        if matches:
            return False
        if journal.get('proxy_id') is None:
            return True
        old_type = self._safe('old proxy existence', lambda:
            self.f.CreateEngineType(journal['proxy_id']).GetEngineTypeStr(), '__unavailable__')
        if old_type not in (None, '', '-1'):
            return False
        # Only after successful player return, a loaded origin, a successful
        # bounded entity enumeration, and six distinct script ticks of absence.
        # The decoy is stationary by definition; never delete an unmatched ID.
        if row.get('missing_tick') != self.ticks:
            row['missing_tick'] = self.ticks
            row['missing_count'] = row.get('missing_count', 0)+1
        if row.get('missing_count', 0) >= 6:
            self.removed.add(journal['proxy_id'])
            return True
        return False

    def finish(self, record, reason):
        row = self.rows.get(record.get('player'))
        if not row:
            return not bool(record.get('operator'))
        if row['record'] is not record or row.get('finishing'):
            return False
        row['phase'] = 'returning'
        row['reason'] = reason
        row['finishing'] = True
        try:
            return self._safe('finish', lambda: self._return(row) and self._cleanup(row), False) is True
        finally:
            row['finishing'] = False

    def check(self, record):
        row = self.rows.get(record.get('player'))
        if not row or row['record'] is not record:
            return 'operator_missing'
        if row['phase'] != 'mounted':
            return 'operator_returning'
        if not self._context(row):
            return 'operator_unavailable'
        if not self._proxy_owned(row):
            return 'operator_proxy_unavailable'
        proxy = row['journal']['proxy_id']
        pos = self._position(proxy)
        if (pos is None or self._dimension(proxy) != row['journal']['dimension'] or
                not self._chunk(row['journal']['dimension'], pos)):
            return 'operator_proxy_unavailable'
        if self._mounted(row) is not True:
            return 'operator_ride_lost'
        if not self._sync_health(row):
            return 'operator_health_unavailable'
        return None

    def snapshot(self, record):
        row = self.rows.get(record.get('player'))
        if not row or row['record'] is not record:
            return None
        journal = row['journal']
        return dict(state='mounted' if row['phase'] == 'mounted' else 'returning',
            vehicle_id=journal['entity_id'], proxy_id=journal.get('proxy_id'),
            anchor=list(journal['anchor']), dimension=journal['dimension'],
            session=journal.get('session'))

    def _stop(self, row, reason):
        row['phase'] = 'returning'
        row['reason'] = reason
        if self.service and row['record'].get('state') not in ('removed', 'cleanup_pending'):
            self._safe('stop service', lambda: self.service.stop(row['record'], reason))

    def _lethal(self, row):
        if row['phase'] != 'mounted' or not self._context(row):
            return
        row['journal']['death_pending'] = True
        if not self._persist(row):
            # Keep retryable intent in memory; never kill without a durable return.
            row['death_write_pending'] = True
        self._stop(row, 'operator_killed')

    def _forward(self, row, damage, cause, attacker=None, projectile=None):
        player = row['player']
        if (row['phase'] != 'mounted' or player in self.forwarding or damage <= 0 or
                not self._context(row)):
            return False
        self.forwarding.add(player)
        try:
            accepted = self._safe('forward damage', lambda: self.f.CreateHurt(player).Hurt(
                damage, cause, attacker, projectile, False), False)
        finally:
            self.forwarding.discard(player)
        self._sync_health(row)
        if accepted is not True:
            self._stop(row, 'operator_damage_unavailable')
        return accepted is True

    def damage(self, args):
        entity = args.get('entityId')
        row = self.rows.get(entity)
        if row:
            if not self._context(row):
                return False
            if not row.get('returned') and entity not in self.forwarding and entity not in self.killing:
                args['damage'], args['knock'], args['ignite'] = 0., False, False
            return True
        row = self.rows.get(self.proxies.get(entity))
        if not row or not self._proxy_owned(row):
            return False
        damage = number(args.get('damage'))
        args['damage'], args['knock'], args['ignite'] = 0., False, False
        if damage is not None and damage > 0:
            self._forward(row, damage, args.get('cause'), args.get('srcId'), args.get('projectileId'))
        return True

    def health_before(self, args):
        entity = args.get('entityId')
        if entity in self.syncing or entity in self.killing:
            return
        old, new = number(args.get('from')), number(args.get('to'))
        if old is None or new is None or new >= old:
            return
        row = self.rows.get(entity)
        if row:
            if not self._context(row):
                return
            # The remote player's environmental/script damage is not a second
            # vulnerable body. Proxy damage is the only allowed damage path.
            if entity not in self.forwarding and not row.get('returned'):
                args['cancel'] = True
            elif entity in self.forwarding and new <= 0:
                args['cancel'] = True
                self._lethal(row)
            return
        row = self.rows.get(self.proxies.get(entity))
        if row and self._proxy_owned(row):
            args['cancel'] = True
            # Potion/status damage skips DamageEvent. A Custom raw-damage
            # fallback is intentionally separate from ordinary damage causes.
            cause = getattr(self.port.enums.ActorDamageCause, 'Custom', 'custom')
            self._forward(row, old-new, cause)

    def health_changed(self, args):
        entity = args.get('entityId')
        row = self.rows.get(entity)
        if row and entity not in self.syncing and self._context(row):
            if number(args.get('to')) == 0:
                row['death_confirmed'] = True
                row['journal']['death_confirmed'] = True
                self._persist(row)
                self._stop(row, 'operator_killed')
            else:
                self._sync_health(row)

    def mob_die(self, args):
        entity = args.get('id', args.get('playerId'))
        row = self.rows.get(entity)
        if row and self._context(row):
            row['death_confirmed'] = True
            row['journal']['death_confirmed'] = True
            self._persist(row)
            self._stop(row, 'operator_killed')
            return
        row = self.rows.get(self.proxies.get(entity))
        if row and self._proxy_owned(row):
            self._lethal(row)

    def allow_ride(self, args):
        player, vehicle = args.get('actorId'), args.get('victimId')
        row = self.rows.get(player)
        owned_vehicle = any(v['journal']['entity_id'] == vehicle for v in self.rows.values())
        if not owned_vehicle:
            owned_vehicle = self._safe('ride target type', lambda:
                self.port.preview_entity_type(self.f.CreateEngineType(vehicle).GetEngineTypeStr()), False)
        if row or owned_vehicle:
            args['cancel'] = not bool(row and row.get('authorized') and
                row['journal']['entity_id'] == vehicle)

    def player_loaded(self, player, respawn=False):
        if player in self.rows:
            row = self.rows[player]
            if respawn:
                row['death_confirmed'] = True
                row['journal']['death_confirmed'] = True
                row['journal']['death_pending'] = False
                self._persist(row)
                self.finish(row['record'], 'operator_respawn')
            return
        try:
            journal = self._read(player)
            if journal is None:
                return
            context = self.port.player_context(player)
            if not context or context.get('owner') != journal['owner']:
                return
            previous_records = []
            for old_player, previous in list(self.rows.items()):
                if (old_player != player and previous['journal']['owner'] == journal['owner'] and
                        previous['journal']['token'] == journal['token']):
                    if self._context(previous):
                        # Never let a second live identity steal an active body.
                        return
                    previous_records.append(previous['record'])
                    previous_records.extend(previous.get('previous_records', []))
                    self.rows.pop(old_player, None)
            confirmed = bool(respawn or journal.get('death_confirmed'))
            if confirmed or journal.get('death_attempted'):
                # Ambiguous crash after KillEntity dispatch: return the player
                # if needed, but never issue the lethal API a second time.
                journal['death_pending'] = False
            if confirmed:
                journal['death_confirmed'] = True
            record = dict(player=player, operator=journal, state='returning',
                          entity_id=journal['entity_id'], vehicle_id=journal['vehicle_id'])
            row = dict(player=player, record=record, journal=journal, phase='returning',
                       death_confirmed=confirmed, finishing=False, authorized=False,
                       reason='operator_reconnect', previous_records=previous_records)
            self.rows[player] = row
            if journal.get('proxy_id'):
                self.proxies[journal['proxy_id']] = player
            self.finish(record, 'operator_reconnect')
        except Exception as exc:
            self.port.warn('operator reconnect', exc)

    def player_leaving(self, player):
        row = self.rows.get(player)
        if row:
            row['phase'] = 'returning'
            self._persist(row)
            self.finish(row['record'], 'operator_disconnect')

    def entity_removed(self, entity):
        player = self.proxies.get(entity)
        row = self.rows.get(player)
        if row and row['journal'].get('proxy_id') == entity:
            already_removed = entity in self.removed
            self.removed.add(entity)
            if row.get('cleaning_proxy') == entity or already_removed:
                return
            self._stop(row, 'operator_proxy_removed')

    def tick(self):
        self.ticks += 1
        for row in list(self.rows.values()):
            if row.get('death_write_pending'):
                if not self._persist(row):
                    continue
                row.pop('death_write_pending', None)
            if row['phase'] == 'returning' and not row.get('finishing'):
                self.finish(row['record'], row.get('reason', 'operator_returning'))
