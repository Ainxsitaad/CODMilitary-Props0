# -*- coding: utf-8 -*-
"""Editable hand-action timing; animation curves live in the resource pack.

Actions are cosmetic. Placement and camera connection still require normal
server validation. Idle has no oscillating time or breathing animation.
"""
import math
from CodMilitary import vehicle_registry

HAND_ACTION_QUERY = 'query.mod.cg_rc_hand_action'
HAND_TIME_QUERY = 'query.mod.cg_rc_hand_time'
HAND_ACTIONS = {'idle': 0, 'draw': 1, 'holster': 2, 'inspect': 3,
                'connect_open': 4, 'place': 5}
HAND_SECONDS = {0: 0.0, 1: .35, 2: .30, 3: 1.60, 4: .85, 5: .65}
CONNECT_OPEN_TICKS = 26
DISCONNECT_TICKS = 11
PLACE_COMMIT_TICKS = 11


def hand_config(item):
    try:
        return vehicle_registry.ITEM_DEFINITIONS.get(item, {}).get('hand', {})
    except TypeError:
        return {}


def action_seconds(action, item=None):
    default = HAND_SECONDS.get(action, 0.0)
    if action == HAND_ACTIONS['idle']:
        return 0.0
    name = next((name for name, number in HAND_ACTIONS.items() if number == action), None)
    try:
        value = float(hand_config(item).get('animation_seconds', {}).get(name, default))
        return value if not math.isnan(value) and not math.isinf(value) and 0 < value <= 60 else default
    except (ValueError, TypeError, OverflowError):
        return default


def animation_source(item, action, kind):
    return hand_config(item).get('animations', {}).get(action, 'animation.cg_rc.viewmodel_' + kind + '.' + action)


def animation_identifier(item, action, kind):
    default = 'animation.cg_rc.viewmodel_' + kind + '.' + action
    source = animation_source(item, action, kind)
    seconds = action_seconds(HAND_ACTIONS[action], item)
    if source != default or abs(seconds - HAND_SECONDS[HAND_ACTIONS[action]]) > 1e-8:
        return 'animation.cg_rc.config_' + item.split(':', 1)[-1] + '.' + action
    return source


def action_time(action, elapsed_ticks, item=None):
    return max(0.0, min(action_seconds(action, item), elapsed_ticks / 30.0))


def action_finished(action, elapsed_ticks, item=None):
    return elapsed_ticks / 30.0 >= action_seconds(action, item)


def commit_ticks(action, item=None):
    """Visual commit time is configurable but cannot outlive its action clip."""
    key = {'connect_open': 'connect_commit_seconds', 'place': 'place_commit_seconds'}[action]
    duration = action_seconds(HAND_ACTIONS[action], item)
    raw = hand_config(item).get('transition', {}).get(key, duration)
    try:
        seconds = float(raw)
        if math.isnan(seconds) or math.isinf(seconds) or seconds < 0:
            seconds = duration
    except (ValueError, TypeError, OverflowError):
        seconds = duration
    return max(1, int(math.ceil(min(duration, seconds) * 30.0)))


def sound_events(action, item):
    """Read one sound source only; a present empty timeline explicitly mutes."""
    item_config = vehicle_registry.ITEM_DEFINITIONS.get(item, {})
    hand = hand_config(item)
    events = hand.get('events', {})
    if action not in events:
        sound = item_config.get('sounds', {}).get(action)
        return [(0.0, sound, None)] if sound else []
    raw = events[action]
    if not isinstance(raw, list):
        return []
    duration = action_seconds(HAND_ACTIONS[action], item)
    result = []
    for event in raw[:16]:
        if not isinstance(event, dict) or event.get('event') != 'sound' or event.get('scope', 'local') != 'local':
            continue
        try:
            seconds = float(event.get('time_seconds', 0.0))
        except (ValueError, TypeError, OverflowError):
            continue
        if math.isnan(seconds) or math.isinf(seconds) or not 0. <= seconds <= duration:
            continue
        if event.get('sound'):
            result.append((seconds, event['sound'], event.get('volume')))
    return sorted(result, key=lambda row: row[0])
