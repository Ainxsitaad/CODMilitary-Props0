# -*- coding: utf-8 -*-
"""Engine-independent authoritative preview lifecycle.

All positions, ownership, health and permissions come from the engine port.
Client packets express intent only. Does not create, consume or refund items.
"""
import copy
import math
import uuid
from collections import OrderedDict
from CodMilitary import config, catalog, protocol, storage
from CodMilitary.extensions import MovementRegistry, AbilityRegistry, FEATURES
from CodMilitary.flight_dynamics import advance_flight, valid_turn_inertia

MAX_CARS = 8
HARD_PREVIEW_RANGE = 64.0
JUMP_COOLDOWN = 6
SPEED_SAMPLE_TICKS = 15


def distance(a, b):
    return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(3)))


def motion_target(forward, strafe, yaw, speed):
    norm = max(1.0, math.sqrt(forward * forward + strafe * strafe))
    radians = math.radians(yaw)
    forward, strafe = forward / norm, strafe / norm
    # MC yaw zero faces +Z; positive strafe is screen-right.
    return ((-math.sin(radians) * forward - math.cos(radians) * strafe) * speed,
            (math.cos(radians) * forward - math.sin(radians) * strafe) * speed)


def ground_motion(context):
    record, data, stats = context['record'], context['input'], context['stats']
    target = motion_target(data['forward'], data['strafe'], data['yaw'], stats['max_speed'])
    # Releasing both axes is a brake, not another acceleration interpolation.
    # Preserve vertical engine motion so braking in the air does not cancel gravity.
    velocity = ((0.0, 0.0) if data['forward'] == 0 and data['strafe'] == 0 else
                tuple(record['velocity'][i] + (target[i] - record['velocity'][i]) * stats['velocity_blend'] for i in range(2)))
    return {'ok': True, 'motion': (velocity[0], context['observed']['motion'][1], velocity[1])}


def air_motion(context):
    """Yaw-relative flight; no jump, pitch-driven climb or inherited gravity.

    Normalize all three intent axes before applying their configured speeds.
    A released axis brakes immediately; boost release cannot retain overspeed.
    The two-step height margin matches the adapter's swept collision check.
    """
    record, data, stats = context['record'], context['input'], context['stats']
    pose = advance_flight(record, data, stats, context.get('dt', 1. / config.TICK_RATE))
    fwd, side, rise = data['forward'], data['strafe'], data.get('vertical', 0.0)
    boost = stats['boost_multiplier'] if data.get('boost', False) else 1.0
    limit, vertical_limit = stats['max_speed'] * boost, stats['vertical_speed'] * boost
    norm = max(1.0, math.sqrt(fwd*fwd + side*side + rise*rise))
    horizontal = motion_target(fwd/norm, side/norm, pose['yaw'], limit)
    blend = stats['velocity_blend']
    velocity = ((0.0, 0.0) if fwd == 0 and side == 0 else tuple(
        record['velocity'][i] + (horizontal[i]-record['velocity'][i])*blend for i in range(2)))
    vertical = (0.0 if rise == 0 else record.get('vertical_velocity', 0.0) +
                (rise/norm*vertical_limit-record.get('vertical_velocity', 0.0))*blend)
    # Per-axis limits and total speed remain authoritative after interpolation.
    vertical = max(-vertical_limit, min(vertical_limit, vertical))
    magnitude = math.sqrt(velocity[0]**2 + velocity[1]**2 + vertical**2)
    if magnitude > limit:
        scale = limit / magnitude
        velocity = tuple(part*scale for part in velocity)
        vertical *= scale
    y = context['observed']['position'][1]
    low = record['flight_base_y'] + 0.08
    high = record['flight_base_y'] + stats['max_altitude']
    if vertical > 0:
        vertical = min(vertical, max(0.0, (high-y)/2.0))
    elif vertical < 0:
        vertical = max(vertical, min(0.0, (low-y)/2.0))
    pose.update(ok=True, motion=(velocity[0], vertical, velocity[1]))
    return pose


def valid_air_definition(movement):
    """Hard server envelope independent of client/config editor validation."""
    bounds = {'max_speed': (0.0, 0.5), 'vertical_speed': (0.0, 0.5),
              'boost_multiplier': (1.0, 2.0), 'max_altitude': (1.0, 128.0),
              'launch_height': (0.08, 4.0), 'velocity_blend': (0.0, 1.0)}
    for key, (low, high) in bounds.items():
        value = movement.get(key)
        if (isinstance(value, bool) or not isinstance(value, protocol.NUMBER_TYPES) or
                value < low or value > high or (low == 0 and value == 0) or
                math.isnan(float(value)) or math.isinf(float(value))):
            return False
    return (movement['launch_height'] < movement['max_altitude'] and
            valid_turn_inertia(movement.get('turn_inertia')))


def glider_motion(context):
    """Continuous forward flight; inertial orientation drives real motion."""
    record, data, stats = context['record'], context['input'], context['stats']
    pose = advance_flight(record, data, stats, context.get('dt', 1. / config.TICK_RATE))
    yaw, pitch = pose['yaw'], pose['pitch']
    target = stats['min_speed'] if data['forward'] < -.05 else (
        stats['max_speed'] if data['forward'] > .05 else stats['cruise_speed'])
    if data.get('boost'):
        target *= stats['boost_multiplier']
    target += stats['dive_speed_bonus']*max(0., pitch/stats['dive_pitch_limit'])
    target = max(stats['min_speed'], min(stats['max_speed'], target))
    previous = record.get('flight_speed', stats['cruise_speed'])
    speed = previous+max(-stats['acceleration'], min(stats['acceleration'],
        (target-previous)*stats['velocity_blend']))
    speed = max(stats['min_speed'], min(stats['max_speed'], speed))
    vertical = -math.sin(math.radians(pitch))*speed
    # Keep flying forward at the height ceiling. Descents deliberately reach
    # terrain: only a verified loaded full-cube impact can request detonation.
    if vertical > 0:
        high = record['flight_base_y']+stats['max_altitude']
        vertical = min(vertical, max(0., (high-context['observed']['position'][1])/2.))
    horizontal = math.sqrt(max(0., speed*speed-vertical*vertical))
    angle = math.radians(yaw)
    pose.update(ok=True, motion=(-math.sin(angle)*horizontal, vertical, math.cos(angle)*horizontal),
                speed=speed)
    return pose


def valid_glider_definition(movement):
    bounds = {'max_speed': (0.01, .5), 'min_speed': (.01, .5), 'cruise_speed': (.01, .5),
        'acceleration': (.001, .1),
        'climb_pitch_limit': (1., 80.), 'dive_pitch_limit': (1., 80.),
        'dive_speed_bonus': (0., .3), 'boost_multiplier': (1., 2.),
        'max_altitude': (2., 64.), 'launch_height': (.5, 3.), 'velocity_blend': (.01, 1.)}
    for key, (low, high) in bounds.items():
        value = movement.get(key)
        if (isinstance(value, bool) or not isinstance(value, protocol.NUMBER_TYPES) or
                value < low or value > high or math.isnan(float(value)) or math.isinf(float(value))):
            return False
    return (movement['min_speed'] <= movement['cruise_speed'] <= movement['max_speed'] and
            movement['launch_height'] < movement['max_altitude'] and
            valid_turn_inertia(movement.get('turn_inertia')))


def explosion_proposal(context):
    definition = context['definition']
    # This preview implements one safe blast policy only; JSON does not grant
    # block destruction, player damage or an unimplemented damage pipeline.
    if (definition.get('break_blocks') is not False or
            definition.get('friendly_fire') is not False or
            definition.get('damage_mode') != 'direct_health' or
            definition.get('cooldown_ticks', 0) != 0):
        return {'ok': False, 'code': 'capability_not_implemented'}
    try:
        radius, damage = definition['radius'], definition['damage']
        delay = definition['delay_ticks']
        if (isinstance(radius, bool) or isinstance(damage, bool) or
                not 0 < radius <= 16 or not 0 < damage <= 1000 or
                isinstance(delay, bool) or not isinstance(delay, protocol.integer_types) or
                not 0 <= delay <= 300):
            raise ValueError('unsupported explosion parameters')
    except (KeyError, ValueError, TypeError):
        return {'ok': False, 'code': 'capability_not_implemented'}
    return {'ok': True, 'code': 'self_destruct_started', 'action': 'detonate',
            'delay_ticks': definition['delay_ticks']}


class CarService(object):
    def __init__(self, engine):
        self.engine = engine
        self.tick = 0
        self.snapshot_seq = 0
        self.records = {}
        self.players = {}       # current connection entity ID -> vehicle ID
        self.requests = {}      # bounded reply caches per current player
        self.request_ticks = {}
        self.storage_ok = True
        self.dirty = False
        self.drivers = MovementRegistry()
        self.drivers.register('ground', ground_motion)
        self.drivers.register('air', air_motion)
        self.drivers.register('glider', glider_motion)
        self.abilities = AbilityRegistry()
        self.abilities.register('explosion', explosion_proposal)
        try:
            for row in storage.decode_journal(engine.load_journal()):
                row.update(state="cleanup_pending", player=None,
                           session=None, client_nonce=None)
                self.records[row["vehicle_id"]] = row
        except Exception as exc:
            self.storage_ok = False
            engine.warn("journal", exc)

    def save(self):
        if not self.storage_ok:
            return False
        try:
            ok = self.engine.save_journal(storage.encode_journal(
                list(self.records.values())))
        except Exception as exc:
            self.engine.warn("save journal", exc)
            ok = False
        # A transient write failure is retryable. A corrupt/failed initial read
        # remains locked, so it can never be replaced with a guessed empty file.
        self.dirty = not bool(ok)
        return bool(ok)

    def vehicle_for(self, player):
        return self.records.get(self.players.get(player))

    def controlling(self, player):
        record = self.vehicle_for(player)
        return bool(record and record.get("state") == "controlled")

    def control_reserved(self, player):
        record = self.vehicle_for(player)
        return bool(record and record.get('state') in ('connecting', 'controlled'))

    def definition_error(self, definition):
        if not self.drivers.available(definition['movement']['kind']):
            return 'movement_not_implemented'
        if definition['movement']['kind'] == 'air' and not valid_air_definition(definition['movement']):
            return 'movement_not_implemented'
        if definition['movement']['kind'] == 'glider' and not valid_glider_definition(definition['movement']):
            return 'movement_not_implemented'
        for ability in definition.get('abilities', {}).values():
            if not self.abilities.available(ability.get('kind')):
                return 'capability_not_implemented'
            if ability['kind'] == 'explosion' and not explosion_proposal({'definition': ability}).get('ok'):
                return 'capability_not_implemented'
        return None

    def emit_event(self, record, name, position=None, damage=None):
        """Presentation hook; base lifecycle has no engine/UI dependency."""
        return None

    def reply(self, player, request, ok, code, session=None):
        response = dict(protocol=config.PROTOCOL_VERSION,
                        request_id=request.get("request_id", 0),
                        client_nonce=request.get("client_nonce", "legacy"),
                        ok=bool(ok), code=code, message=code, session=session)
        self.engine.notify(player, "CarReply", response)
        return response

    def command(self, player, payload):
        try:
            request = protocol.validate_command(payload)
        except (ValueError, TypeError):
            return self.reply(player, {}, False, "invalid_request")
        cache = self.requests.setdefault(player, OrderedDict())
        key = (request["client_nonce"], request["request_id"])
        if key in cache:
            response = copy.deepcopy(cache[key])
            self.engine.notify(player, "CarReply", response)
            self.snapshot(player)
            return response
        action = request["action"]
        # Exit always bypasses ordinary command rate limits.
        if action not in ("exit", "status", "activate") and self.tick - self.request_ticks.get(player, -999) < config.REQUEST_INTERVAL_TICKS:
            return self.reply(player, request, False, "request_too_fast")
        if action not in ("exit", "status", "activate"):
            self.request_ticks[player] = self.tick
        ok, code, session = self._command(player, request)
        response = self.reply(player, request, ok, code, session)
        cache[key] = copy.deepcopy(response)
        while len(cache) > 32:
            cache.popitem(last=False)
        # A successful connect acknowledgement is sent before its snapshot.
        self.snapshot(player)
        return response

    def _command(self, player, request):
        action = request["action"]
        record = self.vehicle_for(player)
        if action == "status":
            return True, "status", record.get("session") if record else None
        if action == "exit":
            pending_blast = (record or {}).get('pending_detonation') or {}
            exit_session = (record or {}).get('session') or pending_blast.get('session')
            exit_nonce = (record or {}).get('client_nonce') or pending_blast.get('client_nonce')
            if record and exit_session:
                if exit_nonce != request["client_nonce"]:
                    return False, "stale_session", None
                if request.get("session") not in (None, exit_session):
                    return False, "stale_session", None
                self.stop(record, "manual_exit")
            return True, "exited", None
        context = self.engine.player_context(player)
        if not context or not context.get("alive"):
            return False, "player_unavailable", None
        if (not config.PROTOTYPE_MODE or not config.CREATIVE_TEST_BUILD or
                (action == 'deploy' and not context.get("creative"))):
            return False, "creative_preview_only", None
        placement = request.get('placement') if action == 'deploy' else None
        held_vehicle = catalog.vehicle_for_item(context.get('held_item'))
        if placement is not None:
            if held_vehicle is None:
                return False, 'hold_car_capsule', None
        elif action == 'deploy' and held_vehicle is not None:
            return False, 'placement_target_required', None
        elif not catalog.controller_vehicle(context.get('held_item')):
            return False, "hold_control_tablet", None
        if action == 'select_vehicle':
            if record or any(r['owner'] == context['owner'] for r in self.records.values()):
                return False, 'vehicle_already_exists', None
            vehicle_type = request['vehicle_type']
            if not catalog.available(vehicle_type):
                return False, 'vehicle_in_development', None
            definition = catalog.definition(vehicle_type)
            failure = self.definition_error(definition)
            if failure:
                return False, failure, None
            if vehicle_type != catalog.controller_vehicle(context.get('held_item')):
                return False, 'controller_item_mismatch', None
            return True, 'vehicle_selected', None
        if action == "deploy":
            vehicle_type = held_vehicle if placement is not None else catalog.controller_vehicle(context.get('held_item'))
            if not catalog.available(vehicle_type):
                return False, 'vehicle_in_development', None
            definition = catalog.definition(vehicle_type)
            failure = self.definition_error(definition)
            if failure:
                return False, failure, None
            if record or any(r["owner"] == context["owner"] for r in self.records.values()):
                return False, "vehicle_already_exists", None
            if not self.storage_ok or (self.dirty and not self.save()):
                return False, "journal_unavailable", None
            if len(self.records) >= MAX_CARS:
                return False, "preview_limit", None
            if placement is not None:
                site, failure = self.engine.placement_site(context, placement)
                if site is None:
                    return False, failure or 'no_safe_loaded_ground', None
            else:
                site = self.engine.spawn_site(context)
            if site is None:
                return False, "no_safe_loaded_ground", None
            ground_site = site
            if definition['movement']['kind'] in ('air', 'glider'):
                site = self.engine.flight_site(context, ground_site, definition['movement'])
                if site is None:
                    return False, 'no_safe_loaded_air', None
            vid = uuid.uuid4().hex
            entity = self.engine.spawn(site, context["dimension"], context["yaw"], vid, definition["entity_id"])
            if not entity:
                return False, "spawn_failed", None
            stats = catalog.stats_for(vehicle_type)
            record = dict(vehicle_id=vid, entity_id=entity, owner=context["owner"],
                          player=player, vehicle_type=vehicle_type, entity_type=definition["entity_id"],
                          state="deploying", ready_at=self.tick + stats["deploy_ticks"],
                          expires_at=self.tick + int(stats["lifetime_seconds"] * config.TICK_RATE),
                          dimension=context["dimension"], hp=stats["hp"],
                          max_hp=stats["hp"], remaining_seconds=stats["lifetime_seconds"],
                          lifetime_seconds=stats["lifetime_seconds"], session=None,
                          client_nonce=None, seq=0, input_tick=self.tick,
                          input=None, jump_pending=False, jump_after=0,
                          grounded=False, ground_y=None, velocity=(0.0, 0.0),
                          mobility=definition['movement']['kind'], vertical_velocity=0.0,
                          flight_base_y=float(math.floor(ground_site[1])), boosting=False,
                          yaw=context['yaw'],
                          speed_position=site, speed_last_tick=self.tick, speed_window_tick=self.tick,
                          speed_distance=0.0, horizontal_speed=None,
                          flight_yaw=context['yaw'], flight_pitch=0.,
                          flight_yaw_velocity=0., flight_pitch_velocity=0.,
                          flight_speed=stats.get('cruise_speed', 0.),
                          distance=0.0, signal=1.0, reason="deploying")
            self.records[vid] = record
            self.players[player] = vid
            if not self.save():
                self.retire(record, "journal_unavailable")
                return False, "journal_unavailable", None
            try:
                configured = self.engine.configure_vehicle(record)
            except Exception as exc:
                self.engine.warn('configure vehicle', exc)
                configured = False
            if not configured:
                self.retire(record, 'vehicle_setup_failed')
                return False, 'vehicle_setup_failed', None
            self.emit_event(record, 'deploy')
            return True, "deployed", None
        if not record or record.get("owner") != context["owner"]:
            return False, "no_owned_vehicle", None
        if catalog.controller_vehicle(context.get('held_item')) != record['vehicle_type']:
            if record.get('state') in ('connecting', 'controlled'):
                self.stop(record, 'controller_item_mismatch')
            return False, 'controller_item_mismatch', None
        if action == "connect":
            if record["state"] != "ready":
                return False, "vehicle_not_ready", None
            observed = self.engine.inspect(record)
            if not self._reachable(context, record, observed) or record["remaining_seconds"] <= 0:
                return False, "vehicle_unavailable", None
            record.update(state="connecting", session=uuid.uuid4().hex,
                          client_nonce=request["client_nonce"], seq=0,
                          input_tick=self.tick, input=None, velocity=(0.0, 0.0),
                          vertical_velocity=0.0, boosting=False,
                          body_position=context["position"], jump_pending=False,
                          prepare_until=self.tick + getattr(config, 'CONNECT_TIMEOUT_TICKS', 90),
                          reason="connection_prepared")
            record.pop('accepted_input_tick', None)
            self.engine.brake(record)
            if not self.engine.begin_control(record, context):
                self.stop(record, 'operator_link_failed')
                return False, 'operator_link_failed', None
            return True, "connection_prepared", record["session"]
        if action == 'activate':
            if not self.session_matches(record, request) or record['state'] != 'connecting':
                return False, 'stale_session', None
            observed = self.engine.inspect(record)
            failure = self.control_error(context, record, observed)
            if self.tick >= record.get('prepare_until', 0):
                failure = 'connection_timeout'
            if failure:
                self.stop(record, failure)
                return False, failure, None
            record.update(state='controlled', reason='connected', input_tick=self.tick,
                          input=None, prepare_until=0)
            return True, "connected", record["session"]
        if action == 'ability':
            if not self.session_matches(record, request) or record['state'] != 'controlled':
                return False, 'stale_session', None
            observed = self.engine.inspect(record)
            failure = self.control_error(context, record, observed)
            if failure:
                self.stop(record, failure)
                return False, failure, None
            definition = catalog.definition(record['vehicle_type'])['abilities'].get(request['ability'])
            if definition is None:
                return False, 'capability_not_installed', record['session']
            proposal = self.abilities.execute(definition['kind'],
                {'record': record, 'definition': definition, 'tick': self.tick})
            if not proposal.get('ok'):
                return False, proposal.get('code', 'capability_not_implemented'), record['session']
            if proposal.get('action') != 'detonate':
                return False, 'capability_not_implemented', record['session']
            token = record['session']
            if (not request.get('confirmed') or record.get('confirm_session') != token or
                    self.tick >= record.get('confirm_until', 0)):
                record.update(confirm_session=token, confirm_until=self.tick + 2 * config.TICK_RATE)
                return False, 'confirm_required', token
            accepted = self.queue_detonation(record, definition, proposal['delay_ticks'])
            return accepted, 'self_destruct_started' if accepted else 'ability_failed', token if accepted else None
        if action == "recall":
            if record.get("session") and (request.get("session") != record["session"] or
                    request["client_nonce"] != record.get("client_nonce")):
                return False, "stale_session", None
            if record['state'] not in ('ready', 'disabled'):
                return False, 'exit_before_recall', record.get('session')
            observed = self.engine.inspect(record)
            if not observed or observed['dimension'] != context['dimension'] or distance(context['position'], observed['position']) > 4.0:
                return False, 'recovery_out_of_range', record.get('session')
            self.emit_event(record, 'recover', observed['position'])
            done = self.retire(record, "preview_recalled")
            return done, "preview_recalled" if done else "cleanup_pending", None
        return False, "capability_not_implemented", None

    def _reachable(self, context, record, observed):
        limit = catalog.stats_for(record["vehicle_type"])["signal_cutoff"]
        return bool(observed and observed.get("hp", 0) > 0 and
                    context["dimension"] == record["dimension"] == observed["dimension"] and
                    (limit is None or distance(self.signal_origin(context, record), observed["position"]) <= limit))

    def signal_origin(self, context, record):
        # The rider follows the vehicle; signal must still be measured from
        # the stationary operator proxy, never the now-nearby rider.
        ride = self.engine.operator_snapshot(record)
        return record['body_position'] if ride else context['position']

    def session_matches(self, record, request):
        return bool(record.get('session') and request.get('session') == record['session'] and
                    request.get('client_nonce') == record.get('client_nonce'))

    def control_error(self, context, record, observed):
        if not self._reachable(context, record, observed) or record.get('remaining_seconds', 0) <= 0:
            return 'vehicle_unavailable'
        if not context.get('tablet'):
            return 'controller_not_available'
        if catalog.controller_vehicle(context.get('held_item')) != record['vehicle_type']:
            return 'controller_item_mismatch'
        return self.engine.control_error(record)

    def input(self, player, payload):
        try:
            data = protocol.validate_input(payload)
        except (ValueError, TypeError):
            return False
        record = self.vehicle_for(player)
        if not record or record["state"] != "controlled" or not self.session_matches(record, data):
            return False
        if data["seq"] <= record["seq"]:
            return False
        context = self.engine.player_context(player)
        if (not context or not context.get('alive') or
                not context.get('tablet')):
            self.stop(record, 'controller_not_available')
            return False
        if catalog.controller_vehicle(context.get('held_item')) != record['vehicle_type']:
            self.stop(record, 'controller_item_mismatch')
            return False
        # At most one driving input per tick, plus a newer neutral release.
        # A periodic held-input packet and its release can arrive in one tick;
        # dropping the release would keep driving until the next heartbeat.
        if record.get("accepted_input_tick") == self.tick:
            previous = record.get('input') or {}
            air = record.get('mobility') == 'air'
            neutral_release = (data['forward'] == 0 and data['strafe'] == 0 and
                               (not air or data['vertical'] == 0) and
                               not data['jump'] and
                               (previous.get('forward', 0) != 0 or previous.get('strafe', 0) != 0 or
                                (air and previous.get('vertical', 0) != 0)))
            if not neutral_release:
                return False
        record.update(seq=data["seq"], input=data, input_tick=self.tick,
                      accepted_input_tick=self.tick)
        if data["jump"] and record.get('mobility') not in ('air', 'glider'):
            record["jump_pending"] = True
        return True

    def queue_detonation(self, record, definition, delay_ticks):
        """Keep one validated intent while the native rider returns over ticks.

        This is deliberately not persisted: a restart cleans up, never resumes
        a delayed explosion. Only the same live owner/vehicle can consume it.
        """
        if (self.records.get(record.get('vehicle_id')) is not record or
                record.get('state') != 'controlled' or not record.get('session') or
                isinstance(delay_ticks, bool) or not isinstance(delay_ticks, protocol.integer_types) or
                not 0 <= delay_ticks <= 300 or
                not explosion_proposal({'definition': definition}).get('ok')):
            return False
        intent = dict(owner=record['owner'], player=record['player'],
            vehicle_id=record['vehicle_id'], entity_id=record['entity_id'],
            vehicle_type=record['vehicle_type'], session=record['session'],
            client_nonce=record['client_nonce'], definition=copy.deepcopy(definition),
            delay_ticks=delay_ticks)
        record['pending_detonation'] = intent
        returned = self.stop(record, 'self_destruct_started')
        # Synchronous death/removal/exit callbacks may cancel during end_control.
        if record.get('pending_detonation') is not intent:
            return False
        if returned:
            return self.start_pending_detonation(record)
        return True

    def pending_detonation_valid(self, record):
        intent = record.get('pending_detonation')
        if (not intent or self.records.get(record.get('vehicle_id')) is not record or
                record.get('reason') != 'self_destruct_started' or
                record.get('externally_removed') or record.get('return_retire') or
                self.players.get(intent['player']) != intent['vehicle_id'] or
                any(record.get(key) != intent[key] for key in
                    ('owner', 'player', 'vehicle_id', 'entity_id', 'vehicle_type')) or
                record.get('expires_at', 0) <= self.tick + intent['delay_ticks']):
            return False
        context = self.engine.player_context(intent['player'])
        observed = self.engine.inspect(record)
        return bool(context and context.get('alive') and context.get('owner') == intent['owner'] and
                    context.get('dimension') == record['dimension'] and observed and
                    observed.get('dimension') == record['dimension'] and observed.get('hp', 0) > 0)

    def start_pending_detonation(self, record):
        if not self.pending_detonation_valid(record) or self.engine.operator_snapshot(record):
            record.pop('pending_detonation', None)
            self.retire(record, 'ability_failed')
            return False
        # Consume before arming; reentrant callbacks cannot schedule it twice.
        intent = record.pop('pending_detonation')
        record.update(state='detonating', detonate_at=self.tick + intent['delay_ticks'],
                      pending_ability=intent['definition'], ability_executed=False)
        return True

    def stop(self, record, reason, retiring=False):
        if retiring or reason != 'self_destruct_started':
            record.pop('pending_detonation', None)
        if record.get('state') == 'removed':
            return True
        intent = record.get('pending_detonation')
        # Returning the actual player is a transaction. Never destroy a mount
        # or discard the return journal while its rider is still stranded.
        returned = self.engine.end_control(record, reason)
        if intent and record.get('pending_detonation') is not intent:
            # A synchronous death/removal/explicit exit owns the newer state.
            return False
        if record.get('state') == 'removed':
            return True
        if not returned:
            record.update(state='returning', reason=reason, session=None,
                          client_nonce=None, input=None, jump_pending=False,
                          return_retire=bool(retiring or record.get('return_retire') or
                                             (record.get('mobility') == 'glider' and
                                              reason != 'self_destruct_started')),
                          velocity=(0., 0.), vertical_velocity=0., boosting=False)
            self.engine.brake(record)
            return False
        if record.get('mobility') == 'glider' and not retiring and reason != 'self_destruct_started':
            # Fixed-wing flight never becomes an abandoned hovering vehicle.
            # Exits/failures are safe removal, never an implicit explosion.
            return self.retire(record, reason)
        record.update(confirm_until=0, confirm_session=None, session=None, client_nonce=None, input=None,
                      prepare_until=0, pending_ability=None, detonate_at=None,
                      jump_pending=False, velocity=(0.0, 0.0), reason=reason)
        record.update(vertical_velocity=0.0, boosting=False,
                      flight_yaw_velocity=0., flight_pitch_velocity=0.)
        if record["state"] != "cleanup_pending":
            record["state"] = "ready" if record.get("remaining_seconds", 0) > 0 else "disabled"
        self.engine.brake(record)
        return True

    def retire(self, record, reason):
        if record.get('state') == 'removed':
            return True
        if self.records.get(record.get('vehicle_id')) is not record:
            return False
        if self.stop(record, reason, retiring=True) is False:
            return False
        record["state"] = "cleanup_pending"
        entity = record["entity_id"]
        if self.engine.destroy_owned(record):
            self.removed(entity, reason)
            return True
        self.save()
        return False

    def removed(self, entity, reason="vehicle_removed"):
        for vid, record in list(self.records.items()):
            if record["entity_id"] != entity:
                continue
            record.pop('pending_detonation', None)
            player = record.get("player")
            if not self.engine.end_control(record, reason):
                record.update(state='returning', reason=reason, session=None,
                              client_nonce=None, input=None, return_retire=True,
                              externally_removed=True)
                return
            # Synchronous EntityRemove callbacks may arrive during retirement.
            # Invalidate the held record as well as deleting the dictionary row.
            record.update(state='removed', session=None, client_nonce=None, input=None,
                          pending_ability=None, detonate_at=None, confirm_until=0,
                          prepare_until=0, jump_pending=False, velocity=(0.0, 0.0))
            record.update(vertical_velocity=0.0, boosting=False)
            del self.records[vid]
            if player is not None:
                self.players.pop(player, None)
            self.save()
            if player is not None:
                self.snapshot(player, reason)

    def owner_leave(self, player, reason="owner_left"):
        record = self.vehicle_for(player)
        if record:
            self.retire(record, reason)
        self.requests.pop(player, None)
        self.request_ticks.pop(player, None)

    def grounded(self, entity):
        for record in self.records.values():
            if (record["entity_id"] == entity and record["state"] != "cleanup_pending" and
                    record.get('mobility') not in ('air', 'glider')):
                observed = self.engine.inspect(record)
                if observed:
                    record["grounded"] = True
                    record["ground_y"] = observed["position"][1]

    def loaded(self, entity, vehicle_id):
        """Rebind a retired preview by its persistent ID after world reload.

        The adapter must have checked both full entity type and stored tag.
        Live cars are never rebound; unknown tagged entities are never deleted.
        """
        record = self.records.get(vehicle_id)
        if not record or record["state"] != "cleanup_pending" or not storage.identifier(entity):
            return False
        if record["entity_id"] != entity:
            old_probe = self.engine.inspect(record)
            if old_probe is not None:
                return False  # Ambiguous duplicate persistent ID; keep both untouched.
            record["entity_id"] = entity
            self.save()
        return self.retire(record, record.get("reason", "restart_cleanup"))

    def step(self):
        self.tick += 1
        for record in list(self.records.values()):
            try:
                self._step_vehicle(record)
            except Exception as exc:
                self.engine.warn("vehicle step", exc)
                self.stop(record, "adapter_failure")
        if self.dirty and self.tick % 30 == 0:
            self.save()
        if self.tick % config.SNAPSHOT_INTERVAL == 0:
            for player in list(self.players):
                self.snapshot(player)

    def _step_vehicle(self, record):
        if record['state'] == 'returning':
            if record.get('pending_detonation') and not self.pending_detonation_valid(record):
                record.pop('pending_detonation', None)
                record.update(return_retire=True, reason='ability_failed')
            if self.engine.end_control(record, record.get('reason', 'return_pending')):
                if record.pop('externally_removed', False):
                    self.removed(record['entity_id'], record.get('reason', 'vehicle_removed'))
                elif record.get('pending_detonation'):
                    if self.start_pending_detonation(record):
                        self.snapshot(record['player'])
                elif record.pop('return_retire', False):
                    self.retire(record, record.get('reason', 'return_pending'))
                else:
                    self.stop(record, record.get('reason', 'return_pending'))
            return
        if record["state"] == "cleanup_pending":
            if self.tick % 30 == 0:
                self.retire(record, record.get("reason", "restart_cleanup"))
            return
        record['remaining_seconds'] = min(record['remaining_seconds'], max(0.0, (record['expires_at'] - self.tick) / float(config.TICK_RATE)))
        if record['remaining_seconds'] <= 0:
            self.retire(record, 'lifetime_expired')
            return
        context = self.engine.player_context(record["player"])
        if not context or not context.get("alive"):
            self.retire(record, "owner_died" if context and not context.get("alive") else "owner_unavailable")
            return
        if context.get("owner") != record["owner"]:
            self.retire(record, "owner_changed")
            return
        observed = self.engine.inspect(record)
        if not observed:
            if record.get('mobility') in ('air', 'glider'):
                record.update(speed_position=None, horizontal_speed=None)
            self.stop(record, "entity_unloaded")
            return
        record["hp"] = observed["hp"]
        if record["hp"] <= 0:
            self.retire(record, "vehicle_destroyed")
            return
        if context["dimension"] != record["dimension"] or observed["dimension"] != record["dimension"]:
            self.retire(record, "dimension_changed")
            return
        if record.get('mobility') in ('air', 'glider'):
            self.sample_air_speed(record, observed['position'])
        record["distance"] = distance(self.signal_origin(context, record), observed["position"])
        stats = catalog.stats_for(record["vehicle_type"])
        cutoff, warn = stats["signal_cutoff"], stats["signal_warn"]
        record["signal"] = (1.0 if cutoff is None else
                            max(0.0, min(1.0, (cutoff - record["distance"]) / max(1.0, cutoff - warn))))
        if record["state"] == "deploying":
            self.engine.brake(record)
            if self.tick >= record["ready_at"]:
                record.update(state="ready", reason="ready")
            return
        if record['state'] == 'detonating':
            self.engine.brake(record)
            if self.tick >= record['detonate_at'] and not record.get('ability_executed'):
                # Mark BEFORE the SDK call: an exception or synchronous event
                # cannot replay a partially applied blast on the next tick.
                record['ability_executed'] = True
                try:
                    ok, code = self.engine.explode(record, record['pending_ability'], self.begin_blast_hit)
                    if ok:
                        self.emit_event(record, 'detonate', observed['position'])
                except Exception as exc:
                    self.engine.warn('vehicle ability', exc)
                    code = 'ability_failed'
                self.retire(record, code)
            return
        if record["state"] not in ('connecting', 'controlled'):
            if record.get('mobility') == 'air':
                self.engine.brake(record)
            return
        if record["remaining_seconds"] <= 0:
            self.stop(record, "lifetime_expired")
            return
        if not context.get("tablet"):
            self.stop(record, "controller_not_available")
            return
        if catalog.controller_vehicle(context.get('held_item')) != record['vehicle_type']:
            self.stop(record, 'controller_item_mismatch')
            return
        if cutoff is not None and record["distance"] > cutoff:
            self.stop(record, "signal_lost")
            return
        transport_failure = self.engine.control_error(record)
        if transport_failure:
            self.stop(record, transport_failure)
            return
        if record['state'] == 'connecting':
            self.engine.brake(record)
            if self.tick >= record.get('prepare_until', 0):
                self.stop(record, 'connection_timeout')
            return
        age = self.tick - record["input_tick"]
        if record.get('mobility') == 'glider':
            if age > config.INPUT_TIMEOUT_TICKS:
                self.stop(record, 'input_timeout')
                return
            # Activation starts forward flight immediately, before the first
            # client packet. No new packet can inject a position or velocity.
            data = record['input'] or dict(forward=0., strafe=0., vertical=0.,
                yaw=record['flight_yaw'], pitch=record['flight_pitch'], jump=False, boost=False)
            proposal = self.drivers.execute('glider',
                {'record': record, 'input': data, 'observed': observed, 'stats': stats})
            if not isinstance(proposal, dict) or not proposal.get('ok'):
                self.stop(record, 'movement_not_implemented')
                return
            result = self.engine.move_glider(record, proposal['motion'])
            if result.get('impact') is True:
                definition = catalog.definition(record['vehicle_type'])['abilities'].get('self_destruct')
                if not definition or not explosion_proposal({'definition':definition}).get('ok'):
                    self.stop(record, 'glider_path_unavailable')
                    return
                self.queue_detonation(record, definition, 0)
                self.snapshot(record['player'])
                return
            if not result.get('ok'):
                self.stop(record, 'glider_path_unavailable')
                return
            motion = proposal['motion']
            record.update(velocity=(motion[0],motion[2]), vertical_velocity=motion[1],
                flight_yaw=proposal['yaw'], flight_pitch=proposal['pitch'], flight_speed=proposal['speed'],
                flight_yaw_velocity=proposal['yaw_velocity'], flight_pitch_velocity=proposal['pitch_velocity'],
                yaw=proposal['yaw'], boosting=bool(data.get('boost')), jump_pending=False, reason='connected')
            self.engine.turn_flight(record, proposal['yaw'], proposal['pitch'])
            return
        if age > config.SESSION_TIMEOUT_TICKS:
            self.stop(record, "input_timeout")
            return
        if age > config.INPUT_TIMEOUT_TICKS or not record["input"]:
            record["velocity"] = (0.0, 0.0)
            record['vertical_velocity'] = 0.0
            record['flight_yaw_velocity'] = 0.0
            record['flight_pitch_velocity'] = 0.0
            record['boosting'] = False
            record["jump_pending"] = False
            self.engine.brake(record)
            return
        data = record["input"]
        stats = catalog.stats_for(record["vehicle_type"])
        proposal = self.drivers.execute(catalog.definition(record['vehicle_type'])['movement']['kind'],
            {'record': record, 'input': data, 'observed': observed, 'stats': stats})
        if not proposal.get('ok'):
            self.stop(record, 'movement_not_implemented')
            return
        motion = proposal['motion']
        velocity, vertical = (motion[0], motion[2]), motion[1]
        if record.get('mobility') == 'air':
            record['jump_pending'] = False
            # Hovercraft can turn away from a wall while its translation is
            # blocked; retain the accepted angular state independently.
            record.update(flight_yaw=proposal['yaw'], flight_pitch=0.,
                          flight_yaw_velocity=proposal['yaw_velocity'], flight_pitch_velocity=0.,
                          yaw=proposal['yaw'])
            self.engine.turn(record, proposal['yaw'])
            if not self.engine.move(record, motion):
                # A wall, ceiling or unloaded edge acts as a bumper. Keep the
                # session so the player can reverse away; never force chunks.
                record.update(velocity=(0.0, 0.0), vertical_velocity=0.0,
                              boosting=False, reason='flight_obstructed')
                self.engine.brake(record)
                return
            record.update(velocity=velocity, vertical_velocity=vertical,
                          boosting=bool(data.get('boost') and any(abs(v) > .002 for v in motion)),
                          reason='connected')
            return
        if (record.get("ground_y") is not None and
                abs(observed["position"][1] - record["ground_y"]) > 0.04) or vertical > 0.05 or vertical < -0.15:
            record["grounded"] = False
        jumping = (record["jump_pending"] and record["grounded"] and
                   self.tick >= record["jump_after"])
        record["jump_pending"] = False
        if jumping:
            vertical = stats['jump_impulse']
        if not self.engine.move(record, (velocity[0], vertical, velocity[1])):
            self.stop(record, "motion_failed")
            return
        if jumping:
            record["grounded"] = False
            record["jump_after"] = self.tick + JUMP_COOLDOWN
            self.emit_event(record, 'jump', observed['position'])
        record["velocity"] = velocity
        if math.sqrt(velocity[0] ** 2 + velocity[1] ** 2) > 0.002:
            # Car heading follows movement, camera rotation remains independent.
            self.engine.turn(record, math.degrees(math.atan2(-velocity[0], velocity[1])))
        if record["remaining_seconds"] <= 0:
            self.stop(record, "lifetime_expired")

    def begin_blast_hit(self, record, entity, hp, position):
        # The engine-event subclass owns confirmation tracking; pure authority
        # simulations need no presentation side effects.
        return None

    def sample_air_speed(self, record, position):
        """Measure horizontal path length over 0.5s of server script time.

        SetMotion's units are not documented as blocks/second; entity physics
        ticks (20Hz) and script ticks (30Hz) differ. Accumulate observed position
        deltas instead of multiplying a velocity vector by either frequency.
        A window absorbs repeated positions between physical updates.
        """
        previous, stamp = record.get('speed_position'), record.get('speed_last_tick')
        if previous is None or stamp is None or self.tick-stamp > 3:
            record.update(speed_position=position, speed_last_tick=self.tick,
                          speed_window_tick=self.tick, speed_distance=0.0, horizontal_speed=None)
            return
        record['speed_distance'] += math.sqrt((position[0]-previous[0])**2+(position[2]-previous[2])**2)
        record.update(speed_position=position, speed_last_tick=self.tick)
        elapsed = self.tick-record['speed_window_tick']
        if elapsed >= SPEED_SAMPLE_TICKS:
            record.update(horizontal_speed=record['speed_distance']*config.TICK_RATE/float(elapsed),
                          speed_window_tick=self.tick, speed_distance=0.0)

    def snapshot(self, player, reason=None):
        self.snapshot_seq += 1
        record = self.vehicle_for(player)
        view, position = None, None
        if record and record["state"] not in ('cleanup_pending', 'removed'):
            view = dict((key, copy.deepcopy(record[key])) for key in
                        ("vehicle_id", "entity_id", "state", "vehicle_type", "hp", "max_hp",
                         "remaining_seconds", "lifetime_seconds", "distance", "signal"))
            definition = catalog.definition(record['vehicle_type'])
            view.update(display_name=definition['display_name'], mobility=definition['movement']['kind'],
                        abilities=catalog.capabilities(record['vehicle_type']), camera=definition['camera'])
            observed = self.engine.inspect(record)
            position = observed["position"] if observed else None
            if definition['movement']['kind'] in ('air', 'glider'):
                movement = definition['movement']
                view.update(altitude=max(0.0, position[1]-record['flight_base_y']) if position else None,
                            max_altitude=movement['max_altitude'],
                            horizontal_speed=record.get('horizontal_speed') if observed else None,
                            yaw=observed.get('yaw') if observed else None,
                            pitch=observed.get('pitch') if observed else None,
                            boosting=record.get('boosting', False))
        message = dict(protocol=config.PROTOCOL_VERSION, tick=self.tick,
                       snapshot_seq=self.snapshot_seq,
                       vehicle=view, controlling=self.controlling(player),
                       connection_pending=bool(record and record.get('state') == 'connecting'),
                       session=record.get("session") if record else None,
                       client_nonce=record.get("client_nonce") if record else None,
                       reason=reason or (record.get("reason", "idle") if record else "idle"),
                       position=position)
        message['features'] = copy.deepcopy(FEATURES)
        message['ride'] = self.engine.operator_snapshot(record) if record else None
        message['persistence_mode'] = 'preview_cleanup'
        context = self.engine.player_context(player) or {}
        selected = (catalog.controller_vehicle(context.get('held_item')) or
                    (record or {}).get('vehicle_type') or catalog.DEFAULT_VEHICLE)
        message['configuration'] = {'vehicle_type': selected, 'definition': catalog.definition(selected),
            'controller_item': catalog.controller_item(selected),
            'available_types': [catalog.definition(kind) for kind in catalog.VEHICLE_IDS]}
        self.engine.notify(player, "CarSnapshot", message)
        return message

    def close(self):
        for record in list(self.records.values()):
            self.retire(record, "server_shutdown")
