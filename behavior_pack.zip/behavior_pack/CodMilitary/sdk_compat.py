# -*- coding: utf-8 -*-
"""Keep JSON text internal; pass native str to the Python 2 ModSDK."""

try:
    _unicode_type = unicode
except NameError:
    _unicode_type = ()


def sdk_argument(value):
    """Encode Unicode only at an engine boundary, preserving other types.

    NetEase 3.10 live A/B: AddPlayerTexture rejects a json.loads Unicode path
    and accepts the identical UTF-8 str path. Python 3 authoring tools retain
    their ordinary text arguments; numbers, flags and existing bytes pass as-is.
    """
    return value.encode('utf-8') if isinstance(value, _unicode_type) else value
