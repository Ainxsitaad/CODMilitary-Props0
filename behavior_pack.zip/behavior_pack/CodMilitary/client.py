# -*- coding: utf-8 -*-
"""Remote-vehicle terminal, secure controls and client-only presentation."""
import copy
import math
import time
import uuid

import mod.client.extraClientApi as api
from mod_log import logger
from CodMilitary.config import NS, SERVER, CLIENT, PROTOCOL_VERSION, CAPSULE_ITEM, VERSION
from CodMilitary import catalog, presentation, viewmodel, audio, vehicle_registry, thirdperson, camera_follow, blast_fx, flight_visual, rider_visibility

Base = api.GetClientSystemCls()
try:
    string_types = (basestring,)
    integer_types = (int, long)
except NameError:
    string_types = (str,)
    integer_types = (int,)

GAME_SCREENS = ("hud_screen", "hud", "in_game_play_screen")
KEY_ACTIONS = {"71": "deploy", "82": "connect", "86": "recall", "74": "workshop",
               "72": "inspect"}
DRIVE_KEYS = {"87": "forward", "83": "back", "65": "left", "68": "right",
              "37": "look_left", "39": "look_right", "38": "look_up", "40": "look_down"}
FLIGHT_KEYS = {"32": "ascend", "67": "descend", "16": "boost", "160": "boost", "161": "boost"}
HOLD_ACTIONS = set(DRIVE_KEYS.values()) | set(FLIGHT_KEYS.values())
INPUT_INTERVAL = 3
LOOK_DEGREES_PER_SECOND = 60.0
SERVER_TIMEOUT = 60
HOLD_LEASE = 150  # Conservative fallback if a platform loses a key-up/cancel.
VEHICLE_ORDER = catalog.VEHICLE_IDS
ABILITY_NAMES = {"self_destruct": u"引爆"}
ACTION_QUERY = "query.mod.cg_rc_action"
CAMERA_QUERY = "query.mod.cg_rc_camera_active"
REPLIES = {
    "deployed": u"载具已部署，展开后按R接入",
    "connection_prepared": u"正在准备载具镜头",
    "operator_link_failed": u"骑乘与本体代理准备失败，正在恢复",
    "operator_return_pending": u"正在返回本体，请稍候再操作",
    "return_pending": u"正在返回本体，请稍候再操作",
    "operator_returning": u"正在返回本体，请稍候再操作",
    "operator_missing": u"本体连接记录不可用，已停止遥控",
    "operator_unavailable": u"玩家状态已改变，正在返回本体",
    "operator_proxy_unavailable": u"原地本体代理不可用，正在结束遥控",
    "operator_proxy_removed": u"原地本体代理已移除，正在结束遥控",
    "proxy_missing": u"原地本体代理不可用，正在结束遥控",
    "operator_ride_lost": u"骑乘已断开，正在返回本体",
    "ride_lost": u"骑乘已断开，正在返回本体",
    "operator_health_unavailable": u"玩家生命状态不可读，已停止遥控",
    "operator_damage_unavailable": u"本体受击结算不可用，已停止遥控",
    "operator_killed": u"本体已阵亡，遥控结束",
    "operator_reconnect": u"正在恢复上次遥控前的位置",
    "connected": u"载具控制已连接",
    "exited": u"已退出遥控",
    "status": u"载具状态已刷新",
    "creative_preview_only": u"请在创造模式中使用测试框架",
    "creative_test_only": u"请在创造模式中使用测试框架",
    "hold_control_tablet": u"请先手持遥控电脑",
    "controller_item_mismatch": u"请手持此载具对应的操控道具",
    "hold_car_capsule": u"请先拿出手持载具",
    "placement_target_required": u"请右键点击地面摆放载具",
    "placement_out_of_range": u"目标太远，请靠近地面再摆放",
    "placement_not_visible": u"目标被遮挡，请选择眼前的地面",
    "no_safe_loaded_ground": u"前方没有可用的已加载平地",
    "no_safe_loaded_air": u"地面上方没有足够的已加载空域",
    "flight_obstructed": u"飞行方向被阻挡，已悬停，可反向离开",
    "glider_path_unavailable": u"前方地形未加载或碰撞形状不明，滑翔机已安全结束",
    "no_owned_vehicle": u"尚无自己的载具，请先部署",
    "vehicle_not_ready": u"载具尚未展开完成或正在清理",
    "vehicle_already_exists": u"已有自己的载具，请先接入或回收",
    "vehicle_unavailable": u"载具不可接入，请检查剩余时间、距离和维度",
    "vehicle_type_unavailable": u"此类载具仍在开发中，暂不可选择",
    "vehicle_selected": u"载具已选择，固定配置已同步",
    "recover_before_select": u"请先回收当前载具，再选择其他类型",
    "preview_recalled": u"载具已回收",
    "recalled": u"载具已回收",
    "recovered": u"载具已回收",
    "recall_too_far": u"请退出遥控并靠近载具后回收",
    "cleanup_pending": u"载具清理尚未完成，请稍后刷新",
    "stale_session": u"会话已失效，请重新接入",
    "journal_unavailable": u"载具记录暂不可用，已停止操作以保留状态",
    "exit_before_recall": u"请先退出遥控，再靠近载具回收",
    "connection_timeout": u"接入准备已超时，请重新接入",
    "vehicle_setup_failed": u"载具初始化失败，请换一处已加载地面重试",
    "ability_failed": u"载具能力执行失败，已停止本次操作",
    "preview_limit": u"本世界遥控载具数量已达上限",
    "must_exit_control": u"请先退出遥控再进行此操作",
    "ability_used": u"载具能力已使用",
    "ability_cooldown": u"载具能力冷却中",
    "ability_not_supported": u"当前载具不具有此能力",
    "unknown_ability": u"此能力尚未实现",
    "connect_before_ability": u"请先接入载具",
    "confirm_required": u"2秒内再次按F或引爆按钮确认",
    "confirmation_expired": u"引爆确认已过期，请重新确认",
    "self_destruct_started": u"载具正在引爆",
    "self_destructed": u"载具已引爆",
    "lifetime_expired": u"载具使用时间已耗尽",
    "exit_before_service": u"请先退出遥控再回收",
    "service_out_of_range": u"请靠近自己的载具后回收",
    "spawn_failed": u"载具创建失败，请换一处平地重试",
    "player_unavailable": u"当前玩家状态不允许操作",
    "request_too_fast": u"操作过快，请稍后重试",
    "invalid_request": u"请求格式不受支持",
    "entity_unloaded": u"载具未加载，已退出遥控",
    "controller_not_available": u"玩家状态改变，已退出遥控",
    "signal_lost": u"信号已中断，已退出遥控",
    "body_moved": u"本体发生位移，已退出遥控",
    "input_timeout": u"输入超时，已退出遥控",
    "motion_failed": u"载具运动失败，已退出遥控",
    "adapter_failure": u"引擎操作失败，已退出遥控",
    "manual_exit": u"已退出遥控",
    "new_session": u"载具已切换会话，本次遥控结束",
}


def finite(value, default=0.0):
    try:
        result = float(value)
        return default if math.isnan(result) or math.isinf(result) else result
    except (TypeError, ValueError, OverflowError):
        return default


def vector3(value):
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        return None
    result = tuple(finite(v, None) for v in value)
    return result if all(v is not None for v in result) else None


class RemoteCarClient(Base):
    def __init__(self, namespace, name):
        Base.__init__(self, namespace, name)
        self.f = api.GetEngineCompFactory()
        self.level = api.GetLevelId()
        self.player = api.GetLocalPlayerId()
        self.game = self.f.CreateGame(self.level)
        self.camera = self.f.CreateCamera(self.level)
        self.operation = self.f.CreateOperation(self.level)
        self.view = self.f.CreatePlayerView(self.player)
        self.item = self.f.CreateItem(self.player)
        self.client_nonce = uuid.uuid4().hex
        self.tick = 0
        self.request_id = 0
        self.sequence = 0
        self.server_tick = -1
        self.snapshot_seq = 0
        self.last_snapshot = -SERVER_TIMEOUT
        self.last_clock = time.time()
        self.local_load_complete = False
        self.follow_camera = camera_follow.FollowCamera()
        self.foot_camera = camera_follow.DelayedFootAnchor()
        self.held_change_pending = False
        self.camera_acquired = False
        self.connection_snapshot = None
        self.terrain_check_tick = -99
        self.terrain_check_ok = False
        self.camera_pos_component = None
        self.camera_model_component = None
        self.camera_anchor_source = None
        self.camera_last_requested = None
        self.camera_body_tick = None
        self.camera_body_box = None
        self.block_info = None
        self.session = None
        self.active = False
        self.pending = None
        self.blocked_sessions = set()
        self.vehicle = None
        self.ride = None
        self.position = None
        self.configuration = {"vehicle_type": catalog.DEFAULT_VEHICLE_TYPE,
                              "definition": catalog.definition(catalog.DEFAULT_VEHICLE_TYPE)}
        self.selection_request = None
        self.last_ability_tick = -99
        self.destruct_deadline = 0
        self.detonation_notice = None
        self.ability_request = None
        self.cooldowns = {}
        self.query_registered = False
        self.camera_query_registered = False
        self.animation_entity = None
        self.animation_value = None
        self.animation_seq = -1
        self.attack_until = 0
        self.keys = {}
        self.blocked_inputs = set()
        self.pressed = set()
        self.jump_pending = False
        self.restore_jobs = []
        self.warned = set()
        self.destroyed = False
        self.tablet = False
        self.ui_initialized = False
        self.registered = False
        self.ui_retry = 0
        self.hud = None
        self.workshop = None
        self.workshop_registered = False
        self.menu = False
        self.dimension = None
        self.target_dimension = None
        self.message = u"手持对应道具：J说明 / G部署 / R接入 / V近身回收"
        self.EnsurePresentation()
        self.DefineEvent("CarCommand")
        self.DefineEvent("CarInput")
        self.DefineEvent('OperatorClientReady')
        events = (("UiInitFinished", self.OnUI), ("OnScriptTickClient", self.OnTick),
                  ("OnLocalPlayerStopLoading", self.OnLocalLoaded),
                  ("GameRenderTickEvent", self.OnRender), ("OnKeyPressInGame", self.OnKey),
                  ("PushScreenEvent", self.OnPush), ("PopScreenAfterClientEvent", self.OnPop),
                  ("DimensionChangeClientEvent", self.OnDimensionStart),
                  ("DimensionChangeFinishClientEvent", self.OnDimensionFinish),
                  ("AddEntityClientEvent", self.OnEntityCreated),
                  ("RemoveEntityClientEvent", self.OnRemove),
                  ("AddPlayerCreatedClientEvent", self.OnPlayerCreated),
                  ("EntityStopRidingEvent", self.OnStopRiding),
                  ("HealthChangeClientEvent", self.OnHealthChange),
                  ("OnBackButtonReleaseClientEvent", self.OnBack),
                  ("ClientItemTryUseEvent", self.OnTabletUse),
                  ("ClientItemUseOnEvent", self.OnTabletUseOn),
                  ("OnCarriedNewItemChangedClientEvent", self.OnHeldItemChanged),
                  ("LeftClickBeforeClientEvent", self.OnAttackPress),
                  ("LeftClickReleaseClientEvent", self.OnAttackRelease),
                  ("RightClickBeforeClientEvent", self.OnRightClick),
                  ("HoldBeforeClientEvent", self.BlockInteraction),
                  ("TapBeforeClientEvent", self.BlockInteraction))
        for event, callback in events:
            self.ListenForEvent(api.GetEngineNamespace(), api.GetEngineSystemName(), event, self, callback)
        self.ListenForEvent(NS, SERVER, "CarSnapshot", self, self.OnSnapshot)
        self.ListenForEvent(NS, SERVER, "CarReply", self, self.OnReply)
        self.ListenForEvent(NS, SERVER, "CarCombatEvent", self, self.OnCombatEvent)

    def Command(self, action, session=None, fields=None):
        self.request_id += 1
        payload = dict(protocol=PROTOCOL_VERSION, request_id=self.request_id,
                       client_nonce=self.client_nonce, action=action, session=session)
        fields = fields or {}
        if action == "ability":
            payload["ability"] = fields.get("ability")
            payload["confirmed"] = fields.get("confirmed", False)
        elif action == "deploy" and "placement" in fields:
            payload["placement"] = copy.deepcopy(fields["placement"])
        self.NotifyToServer("CarCommand", payload)
        return self.request_id

    def Safe(self, label, callback, default=None):
        try:
            return callback()
        except Exception as exc:
            if label not in self.warned:
                self.warned.add(label)
                logger.warning("[RemoteCar] %s: %s", label, exc)
            return default

    def HeldItemName(self):
        item = self.Safe("carried item", self.item.GetCarriedItem, None)
        return item.get("newItemName", item.get("itemName")) if isinstance(item, dict) else None

    def HoldingTablet(self):
        return catalog.controller_vehicle(self.HeldItemName()) is not None

    def HeldVehicleType(self):
        name = self.HeldItemName()
        return catalog.controller_vehicle(name) or catalog.vehicle_for_item(name)

    def EnsurePresentation(self):
        if not hasattr(self, 'local_load_complete'):
            self.local_load_complete = False
        if not hasattr(self, 'rider_visibility'):
            self.rider_visibility = rider_visibility.RiderVisibility(self.f,
                lambda message: logger.warning('[RemoteCar] %s', message))
            self.rider_visibility.add(self.player, self.tick)
        if not hasattr(self, 'ride'):
            self.ride = None
        if not hasattr(self, 'flight_visual'):
            self.flight_visual = flight_visual.FlightVisual(self.f, self.level,
                lambda message: logger.warning('[RemoteCar] %s', message))
            self.flight_visual_failed = False
            self.render_look_clock = None
        if not hasattr(self, 'foot_camera'):
            self.foot_camera = camera_follow.DelayedFootAnchor()
        if not hasattr(self, 'held_change_pending'):
            self.held_change_pending = False
        if not hasattr(self, 'blast_flash'):
            self.blast_flash = blast_fx.BlastFlash(self.f, self.level)
        # Also permits the official dev-tool script reload from 0.2.x. No
        # presentation callback may leave a deferred placement behind on exit.
        if not hasattr(self, "follow_camera"):
            self.follow_camera = camera_follow.FollowCamera()
            self.camera_acquired = False
            self.connection_snapshot = None
        if not hasattr(self, 'hand_sound_events'):
            self.hand_sound_events = []
            self.hand_sound_sequence = 0
        if not hasattr(self, "sounds"):
            self.sounds = audio.SoundPresenter(self.f, self.level, self.player,
                lambda message: logger.warning('[RemoteCar] %s', message))
            self.sound_position = None
        if not hasattr(self, "thirdperson"):
            self.thirdperson = thirdperson.ThirdPersonTablet(self.f, self.level, self.player,
                lambda message: logger.warning('[RemoteCar] %s', message))
            self.thirdperson_seeded = False
        if not hasattr(self, "hand_display"):
            self.hand_display = getattr(self, "hand_item", None)
            self.hand_identity = None
            self.hand_switching = False
            self.hand_suspended = False
            self.hand_dead = False
            self.viewmodel = viewmodel.PlayerViewModel(self.f, self.player, self.level)
        if hasattr(self, "hand_item"):
            if not hasattr(self, "placement_request"):
                self.placement_request = None
            return
        self.hand_item = None
        self.hand_action = 0
        self.hand_started = 0
        self.hand_switching = False
        self.hand_queries_registered = False
        self.presentation_phase = "idle"
        self.presentation_progress = 0.0
        self.phase_started = 0
        self.placement_pending = None
        self.placement_request = None

    def WriteHandQueries(self):
        self.EnsurePresentation()
        if not self.hand_queries_registered:
            register = self.f.CreateQueryVariable(self.level).Register
            action_ok = self.Safe("register hand action", lambda:
                register(presentation.HAND_ACTION_QUERY, 0.0), False)
            time_ok = self.Safe("register hand time", lambda:
                register(presentation.HAND_TIME_QUERY, 0.0), False)
            self.hand_queries_registered = bool(action_ok and time_ok)
        if not self.hand_queries_registered:
            return
        component = self.f.CreateQueryVariable(self.player)
        elapsed = presentation.action_time(self.hand_action, self.tick - self.hand_started, self.hand_display)
        self.Safe("hand action", lambda: component.Set(presentation.HAND_ACTION_QUERY, float(self.hand_action)))
        self.Safe("hand time", lambda: component.Set(presentation.HAND_TIME_QUERY, elapsed))
        self.UpdateViewModel()

    def UpdateViewModel(self):
        # The original-position proxy owns the operating pose. Real riders use
        # native riding presentation and are hidden by authoritative ModAttr.
        self.thirdperson.set_local(False)
        if self.viewmodel.cleanup_jobs:
            self.Safe("retry viewmodel cleanup", self.viewmodel.flush_cleanup)
        if self.hand_display and not self.destroyed and not self.hand_suspended and not self.hand_dead:
            self.Safe("install viewmodel", lambda: self.viewmodel.install(self.tick), False)
        visible = (not self.destroyed and not self.menu and not self.active and not self.camera_acquired
                   and not self.hand_suspended and not self.hand_dead
                   and not self.rider_visibility.hidden(self.player))
        index = viewmodel.item_index(self.hand_display)
        self.Safe("update viewmodel", lambda: self.viewmodel.show(index, visible))

    def StartHandAction(self, name):
        self.EnsurePresentation()
        self.hand_action = presentation.HAND_ACTIONS[name]
        self.hand_started = self.tick
        self.hand_sound_sequence += 1
        self.hand_sound_events = list(enumerate(presentation.sound_events(name, self.hand_display)))
        self.WriteHandQueries()
        self.UpdateHandSounds()

    def UpdateHandSounds(self):
        if (self.active or self.camera_acquired or self.menu or self.hand_suspended or self.hand_dead or
                self.destroyed or self.rider_visibility.hidden(self.player)):
            self.hand_sound_events = []
            return
        elapsed = max(0., (self.tick - self.hand_started) / 30.0)
        remaining = []
        action = next((name for name, value in presentation.HAND_ACTIONS.items() if value == self.hand_action), 'idle')
        for index, (seconds, sound, volume) in self.hand_sound_events:
            if elapsed + .000001 >= seconds:
                self.sounds.hand_action(action, self.hand_display,
                    (self.hand_sound_sequence, index), sound_id=sound, volume=volume)
            else:
                remaining.append((index, (seconds, sound, volume)))
        self.hand_sound_events = remaining

    def OnCombatEvent(self, args):
        if (self.destroyed or not isinstance(args, dict) or
                args.get('protocol') != PROTOCOL_VERSION or args.get('player_id') != self.player or
                not isinstance(args.get('event_id'), string_types) or not args.get('event_id')):
            return
        self.EnsurePresentation()
        name = args.get('name')
        if name not in ('deploy', 'jump', 'destroy', 'recover', 'hurt_car', 'hurt_player',
                        'detonate', 'hit', 'kill') or self.menu:
            return
        if args.get('confirmed') is not True:
            return
        if name == 'detonate':
            if args.get('dimension') != self.Safe('blast dimension', self.game.GetCurrentDimension):
                return
            self.Safe('blast flash', lambda: self.blast_flash.event(args['event_id'], args.get('position'), self.tick))
            if (args.get('entity_id') == getattr(self, 'detonation_notice', None) and
                    self.detonation_notice is not None and self.message == REPLIES['self_destruct_started']):
                self.message = REPLIES['self_destructed']
                self.RefreshHUD()
        self.sounds.event('destroy' if name == 'detonate' else name, args['event_id'], position=args.get('position'),
            entity_id=args.get('entity_id'), confirmed=args.get('confirmed') is True,
            sound_id=args.get('sound_id'))

    def UpdateThirdPerson(self):
        # AOI creation events cover later players; this single scan also covers
        # players already present when a developer reloads only the scripts.
        if self.ui_initialized and not self.thirdperson_seeded:
            players = self.Safe('third-person existing players', api.GetPlayerList, None) if hasattr(api, 'GetPlayerList') else [self.player]
            if isinstance(players, (list, tuple)):
                self.thirdperson.add(self.player, self.tick)
                self.rider_visibility.add(self.player, self.tick)
                for player in players:
                    if player != self.player:
                        self.thirdperson.add(player, self.tick)
                        self.rider_visibility.add(player, self.tick)
                self.thirdperson_seeded = True
        self.thirdperson.set_local(False)
        self.thirdperson.step(self.tick)
        self.rider_visibility.step(self.tick)

    def UpdateMovementSound(self):
        if not self.active or not self.vehicle or self.menu:
            self.sounds.movement(False, self.tick)
            self.sound_position = None
            return
        if self.tick % 3:
            return
        component = self.camera_pos_component or self.f.CreatePos(self.vehicle['entity_id'])
        pos = vector3(self.Safe('movement sound position', component.GetFootPos))
        previous = self.sound_position
        moving = bool(pos and (self.IsDrone() or self.IsGlider() or previous and
                      (pos[0] - previous[0]) ** 2 + (pos[2] - previous[2]) ** 2 > .0001))
        self.sound_position = pos
        vehicle_type = self.vehicle.get('vehicle_type', self.configuration['vehicle_type'])
        sound = catalog.definition(vehicle_type).get('sounds', {}).get('move')
        self.sounds.movement(moving, self.tick, entity_id=self.vehicle['entity_id'], position=pos, sound_id=sound)

    def SyncHeldPresentation(self, from_tick=False):
        self.EnsurePresentation()
        if self.held_change_pending and not from_tick:
            return
        self.held_change_pending = False
        name = self.HeldItemName()
        chosen = catalog.controller_vehicle(name) or catalog.vehicle_for_item(name)
        if chosen:
            self.configuration = {'vehicle_type': chosen, 'definition': catalog.definition(chosen)}
        name = name if viewmodel.item_index(name) else None
        slot = self.Safe("carried slot", self.item.GetSlotId, None) if hasattr(self.item, "GetSlotId") else None
        identity = (slot, name)
        if identity == self.hand_identity:
            return
        if self.active or self.pending or self.presentation_phase in ("connect_open", "connect_wait"):
            self.Exit(u"已切换手持物品，取消遥控", True)
        self.hand_item = name
        self.hand_identity = identity
        self.placement_pending = None
        self.presentation_phase = "idle"
        self.presentation_progress = 0.0
        if self.hand_switching:
            # Latest actual slot wins. Repeated scrolling must not restart the
            # outgoing animation, nor queue up models that are no longer held.
            return
        if self.hand_display and not self.menu and not self.hand_suspended:
            self.hand_switching = True
            self.StartHandAction("holster")
        else:
            self.FinishHandSwitch()

    def FinishHandSwitch(self):
        self.hand_switching = False
        self.hand_display = self.hand_item
        self.StartHandAction("draw" if self.hand_display and not self.menu else "idle")

    def OnHeldItemChanged(self, args=None):
        # Item events may run inside an engine entity-registry traversal. Native
        # item/pose/camera calls are deferred to the next normal script tick.
        self.held_change_pending = True

    def HandAction(self, name):
        self.SyncHeldPresentation()
        if (not self.hand_item or self.active or self.pending or self.menu or
                self.presentation_phase in ("connect_open", "connect_wait") or self.placement_pending or
                self.hand_switching):
            return
        if name == "inspect":
            self.StartHandAction("inspect")
            self.message = u"检视中"
        self.RefreshHUD()

    def BeginPlacement(self, args):
        self.SyncHeldPresentation()
        if (catalog.vehicle_for_item(self.hand_item) is None or self.hand_switching or self.active or self.pending or
                self.menu or self.placement_pending or self.placement_request or self.hand_action == 5):
            return
        coordinates = [args.get(axis) for axis in ("x", "y", "z")]
        if (isinstance(args.get("face"), bool) or args.get("face") != 1 or any(isinstance(v, bool) or
                not isinstance(v, integer_types) for v in coordinates)):
            self.message = u"请对地面顶面右键摆放"
            self.RefreshHUD()
            return
        self.placement_pending = {"block": coordinates, "face": 1}
        self.StartHandAction("place")
        self.message = u"正在部署" + catalog.definition(catalog.vehicle_for_item(self.hand_item))['display_name']
        self.RefreshHUD()

    def UpdatePresentation(self):
        self.SyncHeldPresentation(True)
        self.UpdateHandSounds()
        if self.placement_request and self.tick - self.placement_request[1] >= 150:
            self.placement_request = None
        if self.presentation_phase == "connect_open":
            connect_ticks = presentation.commit_ticks('connect_open', self.hand_display)
            self.presentation_progress = min(1.0, (self.tick - self.phase_started) / float(connect_ticks))
            if self.tick - self.phase_started >= connect_ticks:
                self.BeginConnect()
        elif self.presentation_phase == "disconnect":
            self.presentation_progress = min(1.0, (self.tick - self.phase_started) / float(presentation.DISCONNECT_TICKS))
            if self.presentation_progress >= 1.0:
                self.presentation_phase = "idle"
        elapsed = self.tick - self.hand_started
        if self.hand_switching and presentation.action_finished(2, elapsed, self.hand_display):
            self.FinishHandSwitch()
            elapsed = 0
        if self.placement_pending and elapsed >= presentation.commit_ticks('place', self.hand_display):
            target, self.placement_pending = self.placement_pending, None
            if catalog.vehicle_for_item(self.hand_item) is not None and not self.menu and not self.active and not self.hand_switching:
                try:
                    self.placement_request = (self.request_id + 1, self.tick)
                    self.Command("deploy", fields={"placement": target})
                    self.message = u"正在确认摆放位置"
                except Exception as exc:
                    self.placement_request = None
                    self.message = u"摆放请求发送失败"
                    self.Safe("placement send", lambda: logger.warning("[RemoteCar] placement: %s", exc))
        if self.hand_action in (1, 3, 5) and presentation.action_finished(self.hand_action, elapsed, self.hand_display):
            self.StartHandAction("idle")
        self.WriteHandQueries()
        if self.presentation_phase != "idle" or self.hand_action != 0:
            self.RefreshHUD()

    def BeginConnect(self):
        # The raise/zoom animation finishes before the authority handshake.
        # No player operation or camera is locked until both reply and snapshot.
        if self.menu or self.destroyed or not self.HoldingTablet() or self.hand_switching:
            self.Exit(u"接入已取消", True)
            return
        self.presentation_phase = "connect_wait"
        self.presentation_progress = 1.0
        self.connection_snapshot = None
        self.pending = dict(request_id=self.request_id + 1, tick=self.tick, reply=False, session=None, phase='prepare')
        try:
            self.message = u"正在连接载具"
            self.Command("connect", self.session)
        except Exception as exc:
            self.Exit(u"接入请求发送失败", True)
            self.Safe("connect send", lambda: logger.warning("[RemoteCar] connect: %s", exc))

    def OnTabletUse(self, args):
        if getattr(self, 'held_change_pending', False):
            args['cancel'] = True
            return
        item = args.get("itemDict")
        if (args.get("playerId") != self.player or not isinstance(item, dict) or
                catalog.controller_vehicle(item.get("newItemName", item.get("itemName"))) is None):
            return
        args["cancel"] = True
        if not self.active and not self.pending and self.presentation_phase == "idle" and not self.hand_switching:
            self.OpenWorkshop()

    def OnRightClick(self, args):
        if getattr(self, 'held_change_pending', False):
            args['cancel'] = True
            return
        self.EnsurePresentation()
        if self.active or self.pending or self.presentation_phase in ("connect_open", "connect_wait"):
            args["cancel"] = True
        elif self.HoldingTablet():
            # Works even when the custom tablet has no native use action, and
            # prevents opening the looked-at chest/entity behind the workshop.
            args["cancel"] = True
            if not self.hand_switching:
                self.OpenWorkshop()

    def OnTabletUseOn(self, args):
        if getattr(self, 'held_change_pending', False):
            args['ret'] = True
            return
        item = args.get("itemDict")
        if args.get("entityId") != self.player or not isinstance(item, dict):
            return
        name = item.get("newItemName", item.get("itemName"))
        if catalog.vehicle_for_item(name) is not None:
            args["ret"] = True
            self.BeginPlacement(args)
            return
        if catalog.controller_vehicle(name) is None:
            return
        args["ret"] = True
        if not self.active and not self.pending and self.presentation_phase == "idle" and not self.hand_switching:
            self.OpenWorkshop()

    def CameraPosition(self, foot):
        row = self.vehicle or {}
        definition = catalog.definition(row.get('vehicle_type', self.configuration['vehicle_type']))
        config = row.get('camera', definition.get('camera', {}))
        forward = vector3(self.camera.GetForward())
        if forward is None:
            # The SDK camera rotation has the opposite sign to F3 rotation.
            rotation = vector3(self.camera.GetCameraRotation())
            if rotation is None:
                raise ValueError('camera rotation unavailable')
            pitch, yaw = math.radians(-rotation[0]), math.radians(-rotation[1])
            forward = (-math.sin(yaw) * math.cos(pitch), -math.sin(pitch),
                       math.cos(yaw) * math.cos(pitch))
        def raycast(origin, direction, distance):
            return api.getEntitiesOrBlockFromRay(origin, direction, distance, False,
                                                api.GetMinecraftEnum().RayFilterType.OnlyBlocks)
        # The body must stay visible, including to other players. Clip the chase
        # segment against its bounds instead of hiding it or scanning all entities.
        if getattr(self, 'camera_body_tick', None) != self.tick or getattr(self, 'camera_body_box', None) is None:
            body_foot = vector3(self.f.CreatePos(self.player).GetFootPos())
            self.camera_body_box = camera_follow.player_bounds(body_foot)
            self.camera_body_tick = self.tick
        return self.follow_camera.position(foot, forward, config, self.tick, raycast,
                                           (self.camera_body_box,))

    def IsDrone(self):
        row = self.vehicle or {}
        definition = catalog.definition(row.get('vehicle_type', self.configuration['vehicle_type']))
        return row.get('camera', definition.get('camera', {})).get('mode') == 'first_person_drone'

    def IsGlider(self):
        return (self.vehicle or {}).get('vehicle_type', self.configuration['vehicle_type']) == 'bomb_glider'

    def CameraTerrainReady(self, foot, force=False):
        # Detached cameras cannot make the client receive/render distant chunks.
        # Check a small loaded neighborhood at 5Hz, not every render frame.
        if not force and self.tick - self.terrain_check_tick < 6:
            return self.terrain_check_ok
        self.terrain_check_tick = self.tick
        self.terrain_check_ok = False
        try:
            if self.block_info is None:
                self.block_info = self.f.CreateBlockInfo(self.level)
            limit = finite(self.block_info.GetBlockRenderDistance(), None)
            player_pos = vector3(self.f.CreatePos(self.player).GetFootPos())
            if limit is None or limit <= 0 or player_pos is None:
                return False
            horizontal = math.sqrt((foot[0]-player_pos[0])**2 + (foot[2]-player_pos[2])**2)
            if horizontal > max(8., limit - 16.):
                return False
            y = int(math.floor(foot[1]))
            for dx, dz in ((0, 0), (-2, 0), (2, 0), (0, -2), (0, 2)):
                block = self.block_info.GetBlock((int(math.floor(foot[0])) + dx, y,
                                                 int(math.floor(foot[2])) + dz))
                if not isinstance(block, (tuple, list)) or len(block) < 2 or not block[0]:
                    return False
            self.terrain_check_ok = True
        except Exception as exc:
            self.Safe('camera terrain query', lambda: logger.warning('[RemoteCar] terrain: %s', exc))
        return self.terrain_check_ok

    def FollowCameraPosition(self, foot):
        return self.CameraPosition(self.CameraVisualAnchor(foot))

    def CameraVisualAnchor(self, foot):
        # Native render bones freeze outside the view on the tested runtime,
        # including hidden drones. Use one bounded physical history for all
        # modes. Geometry/ray origins receive the same delayed anchor; loading
        # and entity checks in OnRender still use the current physical feet.
        anchor = self.foot_camera.sample(foot, camera_follow.monotonic_time())
        if self.foot_camera.did_reset:
            self.follow_camera.reset()
        self.camera_anchor_source = self.foot_camera.source
        return anchor

    def AimAngles(self):
        forward = vector3(self.Safe("camera forward", lambda: self.camera.GetForward()))
        if forward is not None:
            horizontal = math.sqrt(forward[0] ** 2 + forward[2] ** 2)
            if horizontal * horizontal + forward[1] ** 2 > .000001:
                return (math.degrees(math.atan2(-forward[0], forward[2])),
                        max(-89., min(89., math.degrees(math.atan2(-forward[1], horizontal)))))
        # Older runtime fallback follows the documented camera/F3 sign rule.
        rotation = vector3(self.Safe("camera rotation", self.camera.GetCameraRotation))
        return (-rotation[1], max(-89., min(89., -rotation[0]))) if rotation else None

    def OpenWorkshop(self):
        self.EnsurePresentation()
        if self.workshop or self.destroyed:
            return
        if self.presentation_phase in ("connect_open", "connect_wait") or self.hand_switching:
            return
        if not self.HoldingTablet():
            self.message = u"请先手持遥控电脑"
            self.RefreshHUD()
            return
        if self.active or self.pending:
            self.Exit(u"已退出遥控，打开载具终端", True)
        if self.hud is None or not self.ui_initialized or self.restore_jobs:
            self.message = u"界面尚未就绪，请稍后再打开载具终端"
            self.RefreshHUD()
            return
        if not self.workshop_registered:
            self.workshop_registered = bool(self.Safe("register workshop", lambda: api.RegisterUI(
                NS, "RemoteCarWorkshop", "CodMilitary.ui.RemoteCarWorkshop", "cg_rc.workshop"), False))
        if not self.workshop_registered:
            self.message = u"载具终端界面注册失败，请重新进入世界"
            return
        self.menu = True
        self.workshop = self.Safe("open workshop", lambda: api.PushScreen(
            NS, "RemoteCarWorkshop", {"system": self}))
        if self.workshop is None:
            self.menu = False
            self.message = u"载具终端打开失败"
        else:
            self.RequestAction("status")
        self.RefreshHUD()

    def OnWorkshopDestroyed(self, node):
        if self.workshop is node:
            self.workshop = None
            top = self.Safe("top UI after workshop", lambda: api.GetTopUI())
            self.menu = top not in GAME_SCREENS if isinstance(top, string_types) else False
            self.ClearInput()
            self.RefreshHUD()

    def SelectVehicle(self, vehicle_type):
        # Legacy UI callbacks cannot turn one controller into another prop.
        self.message = u"每个道具对应固定载具，请切换手持物品"
        self.RefreshHUD()
        return False

    def InstalledAbilities(self):
        row = self.vehicle or {}
        vehicle_type = row.get('vehicle_type')
        if vehicle_type not in VEHICLE_ORDER or not catalog.available(vehicle_type):
            return []
        provided = row.get('abilities')
        allowed = catalog.capabilities(vehicle_type)
        if not isinstance(provided, (list, tuple, dict)):
            return []
        return [name for name in allowed if name in provided]

    def UseAbility(self, ability="self_destruct"):
        if not self.active or not self.session or self.menu:
            self.message = u"请先接入载具后使用能力"
            self.RefreshHUD()
            return False
        if ability not in self.InstalledAbilities():
            self.message = u"当前载具不具有此能力"
            self.RefreshHUD()
            return False
        if self.ability_request or self.tick - self.last_ability_tick < 3:
            return False
        if finite(self.cooldowns.get(ability)) > 0:
            self.message = u"载具能力冷却中"
            return False
        confirmed = ability == "self_destruct" and self.destruct_deadline > self.tick
        self.last_ability_tick = self.tick
        try:
            self.SendInput()
            if not self.active:
                return False
            self.ability_request = (self.request_id + 1, self.tick, self.session)
            self.Command("ability", self.session, {"ability": ability, "confirmed": confirmed})
            if confirmed:
                self.destruct_deadline = 0
            return True
        except Exception:
            self.ability_request = None
            self.message = u"能力请求发送失败，请重试"
            self.RefreshHUD()
            return False



    def OnAttackPress(self, args):
        # Left-click never detonates a vehicle. Keep vanilla attacks blocked
        # while the camera is detached; deliberate ability keys use a handshake.
        if self.active or self.pending or self.camera_acquired:
            args["cancel"] = True

    def OnAttackRelease(self, args=None):
        pass

    def SetAnimation(self, entity, value):
        if not entity:
            return
        if not self.query_registered:
            self.query_registered = bool(self.Safe("register animation query", lambda:
                self.f.CreateQueryVariable(self.level).Register(ACTION_QUERY, 0.0), False))
        if not self.query_registered:
            return
        if entity == self.animation_entity and value == self.animation_value:
            return
        success = self.Safe("set animation query", lambda:
            self.f.CreateQueryVariable(entity).Set(ACTION_QUERY, float(value)), False)
        if success:
            self.animation_entity, self.animation_value = entity, value

    def ShowControlledModel(self, entity):
        if not self.camera_query_registered:
            self.camera_query_registered = bool(self.Safe("register camera visibility query", lambda:
                self.f.CreateQueryVariable(self.level).Register(CAMERA_QUERY, 0.0), False))
        if not self.camera_query_registered:
            raise RuntimeError('controlled vehicle query unavailable')
        # Local controlled entity only: keep its native render bones updating
        # offscreen. Drone resources additionally use this to hide its hull;
        # ground resources keep their model visible. Other entities stay at 0.
        component = self.f.CreateQueryVariable(entity)
        # Undo registered first: acquisition may fail after the render edit.
        self.restore_jobs.append((self.RestoreControlledModel, (entity,)))
        if component.Set(CAMERA_QUERY, 1.0) is False:
            raise RuntimeError('controlled vehicle render rejected')

    def RestoreControlledModel(self, entity):
        # HasEntity is the documented CLIENT existence query (integer 0/1).
        # A removed local render object has no visibility query left to undo.
        # Unknown/failed existence checks do not excuse a failed query write,
        # and this exemption never applies to camera or operation restoration.
        exists = self.Safe('controlled model existence', lambda: self.game.HasEntity(entity), None)
        if isinstance(exists, integer_types) and not isinstance(exists, bool) and exists == 0:
            return True
        return self.f.CreateQueryVariable(entity).Set(CAMERA_QUERY, 0.0)

    def AnimationSnapshot(self, args):
        row = self.vehicle or {}
        entity = row.get("entity_id")
        if not isinstance(entity, string_types) or not entity:
            return
        if entity != self.animation_entity:
            self.animation_seq = -1
            self.attack_until = 0
        state = row.get("state")
        action = args.get("action", row.get("action"))
        sequence = args.get("action_seq", row.get("action_seq", 0))
        action_map = {"deploy": 1, "deploying": 1, "attack": 2, "fire": 2,
                      "recall": 3, "recalling": 3, "destroy": 4, "destroying": 4}
        value = action_map.get(action, action if isinstance(action, integer_types) else 0)
        if state in ("deploying", "recalling", "destroying", "detonating"):
            self.SetAnimation(entity, {"deploying": 1, "recalling": 3, "destroying": 4, "detonating": 2}[state])
            if state == 'detonating':
                self.attack_until = self.tick + 7
        elif value == 2 and isinstance(sequence, integer_types) and sequence > self.animation_seq:
            self.attack_until = self.tick + 7
            self.SetAnimation(entity, 2)
        elif value == 4:
            self.SetAnimation(entity, 4)
        elif self.tick >= self.attack_until:
            self.SetAnimation(entity, 0)
        if isinstance(sequence, integer_types):
            self.animation_seq = max(self.animation_seq, sequence)

    def RequestAction(self, action):
        if getattr(self, 'held_change_pending', False):
            return
        self.EnsurePresentation()
        if self.destroyed:
            return
        if action == "exit":
            self.Exit(u"已退出遥控", True)
            return
        if action == "workshop":
            self.OpenWorkshop()
            return
        if action == "inspect":
            self.HandAction(action)
            return
        if action == "ability":
            self.UseAbility()
            return
        if action == "self_destruct":
            self.UseAbility("self_destruct")
            return
        if action not in ("deploy", "connect", "recall", "status"):
            return
        self.SyncHeldPresentation()
        if self.hand_switching and action != "status":
            self.message = u"正在切换手持物品，请稍候"
            self.RefreshHUD()
            return
        if self.presentation_phase in ("connect_open", "connect_wait"):
            return
        if not self.active and not self.HoldingTablet():
            self.message = u"请先手持遥控电脑"
            self.RefreshHUD()
            return
        if self.active and action in ("deploy", "connect"):
            self.message = u"请先退出遥控再进行此操作"
            self.RefreshHUD()
            return
        if action == "connect":
            if self.vehicle and self.vehicle.get('vehicle_type') != catalog.controller_vehicle(self.HeldItemName()):
                self.message = REPLIES['controller_item_mismatch']
                self.RefreshHUD()
                return
            if self.pending or self.restore_jobs or self.hud is None or self.menu:
                self.message = u"界面或恢复流程尚未就绪，请稍后接入"
                return
            self.presentation_phase = "connect_open"
            self.presentation_progress = 0.0
            self.phase_started = self.tick
            self.StartHandAction("connect_open")
            self.message = u"正在打开控制屏幕"
            self.RefreshHUD()
            return
        try:
            self.message = u"已发送请求，等待服务端确认"
            self.Command(action, self.session)
        except Exception as exc:
            self.pending = None
            self.message = u"请求发送失败，未锁定本体"
            self.Safe("command failure", lambda: logger.warning("[RemoteCar] command: %s", exc))
        self.RefreshHUD()

    def OnReply(self, args):
        if (not isinstance(args, dict) or args.get("protocol") != PROTOCOL_VERSION or
                args.get("client_nonce") != self.client_nonce):
            return
        request_id = args.get("request_id")
        if not isinstance(request_id, integer_types) or isinstance(request_id, bool):
            return
        if request_id < 1 or request_id > self.request_id:
            return
        code = args.get("code")
        fallback = u"请求已处理" if args.get("ok") is True else u"请求未完成，请稍后刷新"
        self.message = REPLIES.get(code, fallback) if isinstance(code, string_types) else fallback
        self.Safe("reply log", lambda: logger.info(
            "[RemoteCar] reply id=%s code=%s ok=%s", request_id, code, args.get("ok")))
        self.EnsurePresentation()
        if code == 'self_destruct_started' and args.get('ok') is True:
            self.detonation_notice = (self.vehicle or {}).get('entity_id')
        if self.placement_request and request_id == self.placement_request[0]:
            self.placement_request = None
        if self.selection_request and request_id == self.selection_request[0]:
            self.selection_request = None
        if self.ability_request and request_id == self.ability_request[0]:
            same_session = self.active and self.session == self.ability_request[2]
            self.ability_request = None
            if code == 'confirm_required' and same_session:
                self.destruct_deadline = self.tick + 60
            else:
                self.destruct_deadline = 0
        if self.pending and request_id == self.pending["request_id"]:
            token = args.get("session")
            expected = 'connection_prepared' if self.pending.get('phase') == 'prepare' else 'connected'
            if (args.get("ok") is True and code == expected and
                    isinstance(token, string_types) and token and
                    (self.pending.get('session') is None or token == self.pending['session'])):
                self.pending["reply"] = True
                self.pending["session"] = token
            else:
                self.Exit(self.message if args.get('ok') is not True else u"接入确认不完整，已取消接入", True)
        self.AdvanceConnection()
        self.RefreshHUD()

    def RideMatches(self):
        ride, vehicle = self.ride, self.vehicle or {}
        return (isinstance(ride, dict) and ride.get('state') == 'mounted' and
                ride.get('vehicle_id') == vehicle.get('entity_id') and
                isinstance(ride.get('proxy_id'), string_types) and bool(ride.get('proxy_id')) and
                ride.get('proxy_id') not in (self.player, vehicle.get('entity_id')))

    def LocalRideReady(self):
        if not self.RideMatches():
            return False
        self.rider_visibility.add(self.player, self.tick)
        rider = self.Safe('local riding entity', lambda: self.game.GetRiderId(self.player), None)
        return rider == self.vehicle.get('entity_id') and self.rider_visibility.hidden_ready(self.player)

    def AdvanceConnection(self):
        """Join reply and snapshot in either order, then activate exactly once."""
        pending = self.pending
        snapshot = self.connection_snapshot
        if not pending or not pending.get('reply') or not snapshot:
            return
        token = pending.get('session')
        if not token or token in self.blocked_sessions or snapshot.get('session') != token:
            return
        if snapshot.get('client_nonce') != self.client_nonce or not self.vehicle:
            return
        if pending.get('phase') == 'prepare':
            if snapshot.get('connection_pending') is not True or snapshot.get('controlling') is True:
                return
            # Server mounted first; entity/ModAttr replication may arrive after
            # the prepared snapshot. Wait within the existing prepare timeout.
            if not self.LocalRideReady():
                self.message = u"等待骑乘与隐身同步"
                return
            self.session = token
            if not self.AcquireControl():
                self.Exit(u"镜头或输入接管失败，已恢复本体", True)
                return
            self.camera_acquired = True
            self.pending = dict(phase='activate', request_id=self.request_id + 1,
                                tick=self.tick, reply=False, session=token)
            self.connection_snapshot = None
            self.WriteHandQueries()
            try:
                self.message = u"镜头已就绪，正在确认控制"
                self.Command('activate', token)
            except Exception:
                self.Exit(u"控制确认发送失败，已恢复本体", True)
        elif snapshot.get('controlling') is True:
            if not self.camera_acquired or not self.LocalRideReady():
                self.Exit(u"镜头尚未就绪，已取消控制", True)
                return
            self.pending = None
            self.active = True
            self.sequence = 0
            self.presentation_phase = "control"
            self.presentation_progress = 1.0
            self.StartHandAction("idle")
            self.message = (u"滑翔中：鼠标引导 / W加速 S减速 / Shift推进 / F引爆 / X结束" if self.IsGlider()
                            else u"机载连接：空格升 / C降 / Shift加速 / F引爆 / X退出" if self.IsDrone()
                            else u"遥控中：WASD / 空格跳跃 / X或ESC退出")
            if self.IsGlider():
                # Continuous flight starts on activation; send the actual view
                # immediately rather than waiting for the next 3-tick interval.
                self.SendInput()

    def OnSnapshot(self, args):
        if not isinstance(args, dict) or args.get("protocol") != PROTOCOL_VERSION:
            return
        nonce = args.get("client_nonce")
        if nonce is not None and nonce != self.client_nonce:
            return
        if args.get("controlling") is True and nonce != self.client_nonce:
            return
        stamp = args.get("tick")
        sequence = args.get("snapshot_seq")
        if (not isinstance(sequence, integer_types) or isinstance(sequence, bool) or
                sequence <= self.snapshot_seq):
            return
        if (not isinstance(stamp, integer_types) or isinstance(stamp, bool) or
                stamp < 0 or stamp < self.server_tick):
            return
        self.snapshot_seq = sequence
        self.server_tick = stamp
        self.last_snapshot = self.tick
        vehicle = args.get("vehicle")
        self.vehicle = vehicle if isinstance(vehicle, dict) else None
        ride = args.get('ride')
        self.ride = dict(ride) if isinstance(ride, dict) else None
        if self.vehicle:
            self.EnsurePresentation()
            self.flight_visual.track(self.vehicle.get('entity_id'), self.vehicle.get('vehicle_type'))
        self.position = vector3(args.get("position"))
        configured = args.get("configuration")
        if isinstance(configured, dict):
            vehicle_type = self.HeldVehicleType() or configured.get('vehicle_type')
            if vehicle_type in VEHICLE_ORDER and catalog.available(vehicle_type):
                self.configuration = {"vehicle_type": vehicle_type,
                                      "definition": catalog.definition(vehicle_type)}
        row = self.vehicle or {}
        cooldowns = row.get("cooldowns", {})
        if row.get('state') == 'detonating' and (self.active or self.message == REPLIES['self_destruct_started']):
            self.detonation_notice = row.get('entity_id')
        self.cooldowns = dict((key, max(0., finite(value))) for key, value in cooldowns.items()
                              if key in catalog.ABILITIES) if isinstance(cooldowns, dict) else {}
        self.AnimationSnapshot(args)
        token = args.get("session")
        controlling = args.get("controlling") is True
        self.connection_snapshot = dict(session=token, controlling=controlling,
                                        connection_pending=args.get('connection_pending') is True,
                                        client_nonce=nonce)
        if self.active:
            if not controlling or token != self.session or not self.vehicle or not self.RideMatches():
                reason = args.get("reason")
                message = u"服务端已结束本次遥控"
                if isinstance(reason, string_types):
                    message = REPLIES.get(reason, message)
                self.Exit(message, False)
            elif self.IsDrone() and args.get('reason') == 'flight_obstructed':
                self.message = REPLIES['flight_obstructed']
            elif self.IsDrone() and args.get('reason') == 'connected' and self.message == REPLIES['flight_obstructed']:
                self.message = REPLIES['connected']
        elif self.pending:
            if (self.pending.get('phase') == 'activate' and
                    (token != self.session or not self.vehicle or
                     not (controlling or args.get('connection_pending') is True))):
                self.Exit(u"服务端已取消接入，已恢复本体", False)
            else:
                self.AdvanceConnection()
        elif (not self.vehicle and getattr(self, 'detonation_notice', None) and
              self.message == REPLIES['self_destruct_started'] and
              args.get('reason') in ('self_destructed', 'ability_failed')):
            # Detonation already ended control at its start. A terminal snapshot
            # still needs to finish the notice after active became false.
            self.message = REPLIES[args['reason']]
            self.detonation_notice = None
        self.RefreshHUD()

    def AcquireControl(self):
        self.EnsurePresentation()
        if (self.menu or self.hud is None or not self.vehicle or self.restore_jobs or
                not self.HoldingTablet() or self.hand_switching):
            return False
        if self.vehicle.get('vehicle_type') != catalog.controller_vehicle(self.HeldItemName()):
            self.message = REPLIES['controller_item_mismatch']
            return False
        entity = self.vehicle.get("entity_id")
        if not isinstance(entity, string_types) or not entity or not self.LocalRideReady():
            return False
        try:
            pos = vector3(self.f.CreatePos(entity).GetFootPos())
            if pos is None:
                return False  # Do not drive an unloaded entity using stale server positions.
            if not self.CameraTerrainReady(pos, True):
                self.message = u"载具附近地形尚未加载，请靠近后重试"
                return False
            self.camera_pos_component = self.f.CreatePos(entity)
            self.camera_model_component = None
            self.camera_anchor_source = 'native_rider'
            self.foot_camera.reset()
            self.camera_last_requested = None
            self.follow_camera.reset()
            self.camera_body_tick = None
            self.camera_body_box = None
            perspective = self.view.GetPerspective()
            rotation = vector3(self.camera.GetCameraRotation())
            previous_anchor = vector3(self.camera.GetCameraAnchor())
            previous_offset = vector3(self.camera.GetCameraOffset())
            yaw_lock = self.camera.IsModCameraLockYaw()
            pitch_lock = self.camera.IsModCameraLockPitch()
            if perspective not in (0, 1, 2) or rotation is None or previous_anchor is None or previous_offset is None:
                return False
            row = self.vehicle
            definition = catalog.definition(row.get('vehicle_type'))
            attached = camera_follow.rider_camera_settings(row.get('camera', definition['camera']),
                self.f.CreatePos(self.player).GetFootPos(), pos, self.camera.GetFpHeight())
            # Existing explicit camera locks may belong to another mod.
            if yaw_lock or pitch_lock:
                self.message = u"当前镜头已有锁定，暂不接管"
                return False
            states = []
            for suffix in ("Move", "Jump", "Attack", "OpenInv", "Inair", "Perspective"):
                value = getattr(self.operation, "IsCan" + suffix)()
                if not isinstance(value, bool):
                    return False
                states.append((suffix, value))
            # Register undo before mutations, including setters that could partly fail.
            for suffix, value in states:
                if value:
                    setter = getattr(self.operation, "SetCan" + suffix)
                    self.restore_jobs.append((setter, (value,)))
                    if setter(False) is False:
                        raise RuntimeError("operation lock rejected: " + suffix)
            self.restore_jobs.extend(((self.camera.SetCameraAnchor, (previous_anchor,)),
                                      (self.camera.SetCameraOffset, (previous_offset,)),
                                      (self.camera.SetCameraRotation, (rotation,)),
                                      (self.view.SetPerspective, (perspective,)),
                                      (self.camera.LockModCameraYaw, (int(yaw_lock),)),
                                      (self.camera.LockModCameraPitch, (int(pitch_lock),))))
            # Native riding supplies all positional interpolation and terrain
            # boom compression. Do not detach, bind another actor, or set a
            # world-space camera position. Keep arbitrary look input available.
            if self.view.SetPerspective(attached['perspective']) is False:
                raise RuntimeError("riding perspective rejected")
            if self.camera.SetCameraAnchor(attached['anchor']) is not True:
                raise RuntimeError("riding anchor rejected")
            if self.camera.SetCameraOffset(attached['offset']) is not True:
                raise RuntimeError("riding offset rejected")
            self.ShowControlledModel(entity)
            self.ClearInput()
            return True
        except Exception as exc:
            logger.warning("[RemoteCar] cannot acquire: %s", exc)
            self.RestoreControl()
            return False

    def RestoreControl(self):
        # Keep failed undo jobs for subsequent ticks; never unlock unrelated settings.
        pending = []
        for method, arguments in self.restore_jobs:
            try:
                if method(*arguments) is False:
                    pending.append((method, arguments))
            except Exception:
                pending.append((method, arguments))
        self.restore_jobs = pending

    def ClearInput(self):
        self.render_look_clock = None
        self.keys.clear()
        self.blocked_inputs.clear()
        self.pressed.clear()
        self.jump_pending = False
        self.ability_request = None
        self.destruct_deadline = 0

    def Exit(self, reason, notify=True):
        self.EnsurePresentation()
        if reason not in (REPLIES['self_destruct_started'], REPLIES['self_destructed']):
            self.detonation_notice = None
        token = self.session or (self.pending or {}).get('session')
        had_session = bool(token or self.pending or self.active)
        had_presentation = self.presentation_phase in ("connect_open", "connect_wait", "control")
        self.active = False
        self.pending = None
        self.session = None
        self.camera_acquired = False
        self.connection_snapshot = None
        self.follow_camera.reset()
        self.foot_camera.reset()
        self.camera_pos_component = None
        self.camera_model_component = None
        self.camera_anchor_source = None
        self.camera_last_requested = None
        self.camera_body_tick = None
        self.camera_body_box = None
        if token:
            self.blocked_sessions.add(token)
        self.ClearInput()
        self.sounds.stop(preserve_combat=not (self.menu or self.destroyed))
        self.sound_position = None
        self.RestoreControl()
        self.placement_pending = None
        if had_session or had_presentation:
            self.presentation_phase = "disconnect"
            self.presentation_progress = 0.0
            self.phase_started = self.tick
            self.StartHandAction("idle")
        elif self.hand_action == presentation.HAND_ACTIONS["place"]:
            self.StartHandAction("idle")
        if notify and had_session:
            self.Safe("exit request", lambda: self.Command("exit", token))
        self.message = reason
        self.RefreshHUD()

    def SetInput(self, name, down, source="touch"):
        if not self.active:
            return
        key = (source, name)
        if down and name in HOLD_ACTIONS:
            if key not in self.keys and key not in self.blocked_inputs:
                self.keys[key] = self.tick
        else:
            self.keys.pop(key, None)
            self.blocked_inputs.discard(key)

    def Jump(self):
        if self.active and not self.IsDrone() and not self.IsGlider():
            self.jump_pending = True

    def Axes(self):
        names = set(name for source, name in self.keys)
        return (int("forward" in names) - int("back" in names),
                int("right" in names) - int("left" in names), names)

    def SendInput(self):
        if not self.active or not self.session or self.pending or not self.camera_acquired:
            return
        aim = self.AimAngles()
        if aim is None:
            self.Exit(u"无法读取镜头方向，已退出", True)
            return
        forward, strafe, names = self.Axes()
        flying = self.IsDrone()
        gliding = self.IsGlider()
        self.sequence += 1
        payload = dict(protocol=PROTOCOL_VERSION, session=self.session, client_nonce=self.client_nonce, seq=self.sequence,
                       forward=forward, strafe=0 if gliding else strafe, yaw=aim[0],
                       pitch=aim[1], jump=self.jump_pending if not (flying or gliding) else False,
                       vertical=float(int('ascend' in names) - int('descend' in names)) if flying else 0.0,
                       boost=bool((flying or gliding) and 'boost' in names))
        self.jump_pending = False
        try:
            self.NotifyToServer("CarInput", payload)
        except Exception:
            self.Exit(u"输入发送失败，已退出", True)

    def OnKey(self, args):
        if getattr(self, 'held_change_pending', False):
            return
        self.EnsurePresentation()
        key = str(args.get("key"))
        down = str(args.get("isDown")) == "1"
        if down and key in ("27", "88", "18") and (self.active or self.pending or
                self.presentation_phase in ("connect_open", "connect_wait") or self.placement_pending):
            self.Exit(u"已退出遥控", True)
            return
        if args.get("screenName") not in GAME_SCREENS:
            if self.active or self.pending or self.presentation_phase in ("connect_open", "connect_wait"):
                self.Exit(u"切换界面，已退出遥控", True)
            self.ClearInput()
            return
        repeat = key in self.pressed
        if down:
            self.pressed.add(key)
        else:
            self.pressed.discard(key)
        if self.active:
            if self.IsGlider() and key in FLIGHT_KEYS:
                if FLIGHT_KEYS[key] == 'boost':
                    self.SetInput('boost', down, 'keyboard')
            elif self.IsDrone() and key in FLIGHT_KEYS:
                self.SetInput(FLIGHT_KEYS[key], down, "keyboard")
            elif key in DRIVE_KEYS:
                self.SetInput(DRIVE_KEYS[key], down, "keyboard")
            elif key == "32" and down and not repeat:
                self.Jump()
            elif key == "70" and not down and repeat:
                self.UseAbility("self_destruct")
        if not down and key in KEY_ACTIONS:
            self.RequestAction(KEY_ACTIONS[key])

    def BlockInteraction(self, args):
        self.EnsurePresentation()
        if self.active or self.pending or self.camera_acquired or self.presentation_phase in ("connect_open", "connect_wait"):
            args["cancel"] = True

    def OnBack(self, args=None):
        self.EnsurePresentation()
        if (self.active or self.pending or self.placement_pending or
                self.presentation_phase in ("connect_open", "connect_wait")):
            self.Exit(u"已退出遥控", True)

    def OnPush(self, args):
        if args.get("screenDef", "").startswith("cg_rc."):
            return
        self.menu = args.get("screenName") not in GAME_SCREENS
        if self.menu:
            self.Exit(u"打开其他界面，已退出遥控", True)
            self.UpdateViewModel()

    def OnPop(self, args):
        self.menu = args.get("screenName") not in GAME_SCREENS
        self.ClearInput()
        self.SyncHeldPresentation()
        if not self.menu:
            self.FinishHandSwitch()
        self.RefreshHUD()

    def OnEntityCreated(self, args):
        # Creation events cover other players' aircraft too. No world scan or
        # repeated component creation is needed in the render callback.
        entity_type = args.get('engineTypeStr')
        if entity_type == 'minecraft:player':
            self.EnsurePresentation()
            self.rider_visibility.refresh(args.get('id'), self.tick)
        for vehicle_type in ('bomb_glider', 'bomb_drone'):
            if entity_type == catalog.definition(vehicle_type).get('entity_id'):
                self.EnsurePresentation()
                self.flight_visual.track(args.get('id'), vehicle_type)
                break

    def OnRemove(self, args):
        entity = args.get("id", args.get("entityId"))
        self.EnsurePresentation()
        self.flight_visual.untrack(entity)
        self.thirdperson.remove(entity)
        self.rider_visibility.remove(entity)
        if entity == self.animation_entity:
            self.animation_entity = None
            self.animation_value = None
            self.animation_seq = -1
        if entity == self.player or (self.vehicle and entity == self.vehicle.get("entity_id")):
            if (entity != self.player and entity == getattr(self, 'detonation_notice', None) and
                    self.message in (REPLIES['self_destruct_started'], REPLIES['self_destructed'])):
                self.Exit(self.message, False)
            else:
                self.Exit(u"目标或玩家已移除，已退出遥控", True)
        if entity == self.player:
            self.hand_suspended = True
            self.Safe("remove viewmodel", self.viewmodel.close)

    def OnHealthChange(self, args):
        if args.get("entityId") != self.player:
            return
        self.EnsurePresentation()
        health = finite(args.get("to"), None)
        if health is None:
            return
        dead = health <= 0
        if dead == self.hand_dead:
            return
        self.hand_dead = dead
        if dead:
            self.Exit(u"玩家已死亡，已退出遥控", True)
            self.UpdateViewModel()
        else:
            self.SyncHeldPresentation()
            self.FinishHandSwitch()

    def OnPlayerCreated(self, args):
        self.EnsurePresentation()
        player = args.get("playerId")
        if player:
            self.thirdperson.refresh(player, self.tick)
            self.rider_visibility.refresh(player, self.tick)
        if args.get("playerId") == self.player:
            self.EnsurePresentation()
            self.hand_suspended = False
            self.viewmodel.retry_after = 0
            self.RefreshHandLife()
            self.SyncHeldPresentation()
            self.FinishHandSwitch()

    def OnStopRiding(self, args):
        if (args.get('id') != self.player or not (self.active or self.pending or self.camera_acquired) or
                args.get('rideId') != (self.vehicle or {}).get('entity_id')):
            return
        if (self.RideMatches() and not self.hand_dead and
                not args.get('entityIsBeingDestroyed') and not args.get('switchingRides')):
            # Server handles the same event. Forced API dismount/teleport/death
            # cannot be cancelled; OnTick detects that and exits, never remounts.
            args['cancel'] = True
        else:
            # A native dismount can be the server's accepted detonation return,
            # arriving before its product snapshot. Restore locally without
            # sending a new manual-cancel command for that valid transaction.
            self.Exit(u"骑乘已结束，正在返回本体", False)

    def OnLocalLoaded(self, args):
        if args.get('playerId') != self.player:
            return
        self.local_load_complete = True
        self.Safe('operator client loaded', lambda: self.NotifyToServer('OperatorClientReady', {}))

    def RefreshHandLife(self):
        # A respawn may recreate the renderer without a separate health-change
        # callback. Read the engine rather than assuming a creation means alive.
        health = self.Safe("player render health", lambda:
            self.f.CreateQueryVariable(self.player).GetMolangValue('query.health'), None)
        health = finite(health, None)
        if health is not None:
            self.OnHealthChange({"entityId": self.player, "to": health})

    def OnDimensionStart(self, args):
        self.Safe('clear blast flash', lambda: self.blast_flash.update(self.tick, True))
        if args.get("playerId") != self.player:
            return
        self.local_load_complete = False
        self.Exit(u"切换维度，已退出遥控", True)
        self.flight_visual.clear()
        self.hand_suspended = True
        self.UpdateViewModel()
        self.target_dimension = args.get("toDimensionId")
        self.ResetUI()
        self.registered = False
        self.workshop_registered = False
        self.ui_retry = self.tick + 15

    def OnDimensionFinish(self, args):
        if args.get("playerId") == self.player:
            self.hand_suspended = False
            self.SyncHeldPresentation()
            self.FinishHandSwitch()
            self.target_dimension = args.get("toDimensionId")
            self.ui_retry = self.tick + 3

    def OnUI(self, args=None):
        self.Exit(u"遥控界面已就绪，手持电脑操作", True)
        self.hand_suspended = False
        self.ResetUI()
        self.ui_initialized = True
        self.thirdperson_seeded = False
        self.registered = False
        self.workshop_registered = False
        self.ui_retry = self.tick + 3
        if self.local_load_complete:
            self.Safe('operator client ready resend', lambda: self.NotifyToServer('OperatorClientReady', {}))

    def ResetUI(self):
        old = self.hud
        self.hud = None
        if old:
            self.Safe("remove HUD", old.SetRemove)
        workshop = self.workshop
        self.workshop = None
        if workshop:
            if self.Safe("top screen", lambda: api.GetTopScreen()) is workshop:
                self.Safe("pop workshop", lambda: api.PopScreen())
            else:
                self.Safe("remove workshop", workshop.SetRemove)
        self.menu = False

    def BuildUI(self):
        self.ui_retry = self.tick + 30
        current = self.Safe("dimension", self.game.GetCurrentDimension)
        if current is None or (self.target_dimension is not None and current != self.target_dimension):
            return
        if not self.registered:
            self.registered = bool(self.Safe("register HUD", lambda: api.RegisterUI(
                NS, "RemoteCarHUD", "CodMilitary.ui.RemoteCarHUD", "cg_rc.hud"), False))
        if not self.registered:
            return
        self.hud = self.Safe("create HUD", lambda: api.CreateUI(
            NS, "RemoteCarHUD", {"isHud": 1, "system": self}))
        if self.hud:
            self.dimension = current
            self.target_dimension = None
            self.RefreshHUD()

    def RefreshHUD(self):
        if self.hud:
            self.Safe("refresh HUD", self.hud.Refresh)
        if self.workshop:
            self.Safe("refresh workshop", self.workshop.Refresh)

    def OnHUDDestroyed(self, node):
        if self.hud is node:
            self.hud = None
            self.Exit(u"遥控界面已关闭", True)
            self.ui_retry = self.tick + 3

    def OnTick(self, args=None):
        if self.destroyed:
            return
        self.tick += 1
        self.Safe('expire blast flash', lambda: self.blast_flash.update(self.tick))
        now = time.time()
        if now - self.last_clock > 2.0 or now < self.last_clock:
            self.Exit(u"客户端暂停或时间中断，已退出遥控", True)
        self.last_clock = now
        for ability in list(self.cooldowns):
            self.cooldowns[ability] = max(0., self.cooldowns[ability] - 1.)
        if self.animation_value == 2 and self.tick >= self.attack_until:
            self.SetAnimation(self.animation_entity, 0)
        # A prepared connection already owns its camera while the server's
        # activate reply is in flight. Its undo stack is not failed cleanup.
        if not self.active and not self.camera_acquired and self.restore_jobs:
            self.RestoreControl()
        self.UpdatePresentation()
        self.UpdateThirdPerson()
        self.UpdateMovementSound()
        if self.pending and self.pending.get('phase') == 'prepare':
            self.AdvanceConnection()
        if self.camera_acquired and not self.LocalRideReady():
            # The server observes its own ride relationship every tick and
            # owns return/retirement. Do not race an already accepted blast.
            self.Exit(u"骑乘连接已失效，正在返回本体", False)
        if self.selection_request and self.tick - self.selection_request[1] > 150:
            self.selection_request = None
            self.message = u"选择请求等待超时，请刷新载具状态"
        if self.ability_request and self.tick - self.ability_request[1] > 60:
            self.ability_request = None
            self.destruct_deadline = 0
            self.message = u"能力请求等待超时，请重新确认"
        if self.ui_initialized and self.hud is None and self.tick >= self.ui_retry:
            self.BuildUI()
        if self.tick % 6 == 0:
            if self.hand_dead:
                self.RefreshHandLife()
            self.tablet = self.HoldingTablet()
            current = self.Safe("dimension", self.game.GetCurrentDimension)
            if self.dimension is not None and current is not None and current != self.dimension:
                self.Exit(u"维度已改变，已退出遥控", True)
                self.flight_visual.clear()
                self.ResetUI()
                self.registered = False
                self.workshop_registered = False
                self.dimension = current
                self.ui_retry = self.tick + 3
            self.RefreshHUD()
        if self.pending and self.tick - self.pending["tick"] >= SERVER_TIMEOUT:
            self.Exit(u"接入超时，已恢复本体", True)
        if not self.active:
            return
        if self.tick % 6 == 0:
            position = vector3(self.Safe('riding vehicle position', lambda:
                self.camera_pos_component.GetFootPos()))
            if position is None or not self.CameraTerrainReady(position):
                self.Exit(u"骑乘地形尚未加载，正在返回本体", True)
                return
        if self.tick - self.last_snapshot >= SERVER_TIMEOUT:
            self.Exit(u"服务端60tick无有效快照，已退出遥控", True)
            return
        for key, started in list(self.keys.items()):
            if self.tick - started >= HOLD_LEASE:
                self.keys.pop(key, None)
                self.blocked_inputs.add(key)
                self.message = u"持续输入已安全停止，请松开后重新按下"
        if self.tick % INPUT_INTERVAL == 0:
            self.SendInput()

    def UpdateRenderLook(self, now):
        previous = getattr(self, 'render_look_clock', None)
        self.render_look_clock = now
        if previous is None or now is None:
            return
        dt = now - previous
        if dt <= 0.0 or dt > 0.25:
            return  # No queued camera jump after a stall or a clock reset.
        _, _, names = self.Axes()
        yaw = int('look_right' in names) - int('look_left' in names)
        pitch = int('look_down' in names) - int('look_up' in names)
        if not (yaw or pitch):
            return
        rotation = vector3(self.Safe('camera rotation', self.camera.GetCameraRotation))
        if rotation:
            step = LOOK_DEGREES_PER_SECOND * dt
            self.Safe('turn camera', lambda: self.camera.SetCameraRotation((
                max(-89., min(89., rotation[0] + pitch * step)),
                (rotation[1] + yaw * step + 180.) % 360. - 180., rotation[2])))

    def OnRender(self, args=None):
        # Hand state is updated by simulation ticks/events, never per render frame.
        if self.destroyed:
            return
        now = camera_follow.monotonic_time()
        if not self.flight_visual_failed:
            try:
                self.flight_visual.render(now)
            except Exception as exc:
                self.flight_visual_failed = True
                self.Safe('disable failed aircraft visuals', self.flight_visual.close)
                logger.warning('[RemoteCar] aircraft visual layer stopped: %s', exc)
        if self.held_change_pending or not (self.active or self.camera_acquired) or not self.vehicle:
            self.render_look_clock = None
            return
        if self.active and not self.menu and not self.pending:
            self.UpdateRenderLook(now)
        else:
            self.render_look_clock = None
        # Position follows the real rider entirely inside the native renderer.
        # No physical foot reads, extra ray bundle or world-space camera writes
        # are made from this render callback.

    def Destroy(self):
        if self.destroyed:
            return
        self.Exit(u"遥控系统关闭", True)
        self.Safe('close blast flash', lambda: self.blast_flash.update(self.tick, True))
        self.destroyed = True
        self.hand_item = None
        self.hand_display = None
        self.hand_switching = False
        self.presentation_phase = "idle"
        self.StartHandAction("idle")
        self.Safe("close viewmodel", self.viewmodel.close)
        self.sounds.close()
        self.thirdperson.close()
        self.rider_visibility.close()
        self.flight_visual.close()
        # Best effort once more while the world is still available. During
        # normal life pending cleanup is retried by UpdateViewModel every tick.
        if self.viewmodel.cleanup_jobs:
            self.Safe("final viewmodel cleanup", self.viewmodel.flush_cleanup)
        self.ResetUI()
        self.RestoreControl()
        self.UnListenAllEvents()
