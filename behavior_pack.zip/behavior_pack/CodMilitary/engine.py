# -*- coding: utf-8 -*-
"""Small NetEase server adapter. All mutating calls target this mod's previews."""
import math
import uuid
import json
import mod.server.extraServerApi as api
from mod_log import logger
from CodMilitary import config, storage, catalog


def finite(value):
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return None if math.isnan(number) or math.isinf(number) else number


def vector(value):
    if not isinstance(value, (tuple, list)) or len(value) != 3:
        return None
    result = tuple(finite(part) for part in value)
    if any(part is None for part in result) or any(abs(part) > 30000000 for part in result):
        return None
    return result


# Conservative spawn support for the preview; no placement inside a container,
# fluid, half-block or an unknown custom block. Runtime driving uses collisions.
PREVIEW_FLOORS = frozenset((
    "minecraft:grass", "minecraft:grass_block", "minecraft:dirt",
    "minecraft:stone", "minecraft:bedrock", "minecraft:cobblestone",
    "minecraft:planks", "minecraft:oak_planks", "minecraft:sand",
    "minecraft:gravel", "minecraft:netherrack", "minecraft:end_stone",
    "minecraft:concrete", "minecraft:stonebrick", "minecraft:iron_block",
))

# Conservative envelope around the .7-wide drone/.8-wide glider, both .35 high.
# This is collision clearance, not a render size or a player-body adjustment.
FLIGHT_HALF_WIDTH = 0.45
FLIGHT_HEIGHT = 0.45


class EnginePort(object):
    def __init__(self, system):
        self.system = system
        self.f = api.GetEngineCompFactory()
        self.level = api.GetLevelId()
        self.enums = api.GetMinecraftEnum()
        self.game = self.f.CreateGame(self.level)
        self.warned = set()
        self.owners = {}
        self.preview_types = frozenset(catalog.definition(kind)['entity_id']
                                       for kind in catalog.VEHICLE_IDS)

    def warn(self, label, error):
        if label not in self.warned:
            self.warned.add(label)
            logger.warning("[RemoteCar] %s: %s", label, error)

    def safe(self, label, operation, default=None):
        try:
            return operation()
        except Exception as exc:
            self.warn(label, exc)
            return default

    def load_journal(self):
        # Do not turn a failed read into an empty journal.
        return self.f.CreateExtraData(self.level).GetExtraData(storage.JOURNAL_KEY)

    def save_journal(self, journal):
        # Plain ASCII also preserves legacy nested Unicode item metadata at
        # the Python 2 SDK bridge. Readback is required before reporting success.
        storage.decode_journal(journal)
        encoded = json.dumps(journal, ensure_ascii=True, allow_nan=False,
                             separators=(',', ':'), sort_keys=True)
        component = self.f.CreateExtraData(self.level)
        component.SetExtraData(storage.JOURNAL_KEY, encoded, True)
        return component.GetExtraData(storage.JOURNAL_KEY) == encoded

    def preview_entity_type(self, entity_type):
        # Include disabled fixed definitions for identity-based cleanup only.
        return entity_type in self.preview_types

    def owner(self, player):
        if player in self.owners:
            return self.owners[player]
        component = self.f.CreateExtraData(player)
        value = component.GetExtraData(storage.OWNER_KEY)
        if value is None:
            value = uuid.uuid4().hex
            if not component.SetExtraData(storage.OWNER_KEY, value, True):
                return None
            if component.GetExtraData(storage.OWNER_KEY) != value:
                return None
        if not storage.identifier(value):
            return None
        self.owners[player] = value
        return value

    def player_context(self, player):
        if player not in api.GetPlayerList():
            return None
        try:
            pos = vector(self.f.CreatePos(player).GetFootPos())
            dim = self.f.CreateDimension(player).GetEntityDimensionId()
            hp = finite(self.f.CreateAttr(player).GetAttrValue(self.enums.AttrType.HEALTH))
            rot = self.f.CreateRot(player).GetRot()
            yaw = finite(rot[1]) if isinstance(rot, (list, tuple)) and len(rot) == 2 else None
            item = self.f.CreateItem(player).GetPlayerItem(self.enums.ItemPosType.CARRIED, 0, False)
            held = (item.get("newItemName") or item.get("itemName")) if isinstance(item, dict) else None
            vehicle_type = catalog.vehicle_for_item(held)
            controller_type = catalog.controller_vehicle(held)
            capsule = vehicle_type is not None
            head = vector(self.f.CreatePos(player).GetPos()) if capsule else None
            creative = self.game.GetPlayerGameType(player) == 1
            owner = self.owner(player)
            if pos is None or dim is None or hp is None or yaw is None or not owner:
                return None
            # Ignore transient dimension-loading positions.
            if abs(pos[1]) >= 32000:
                return None
            return dict(position=pos, dimension=dim, hp=hp, alive=hp > 0,
                        yaw=yaw, creative=creative, tablet=controller_type is not None,
                        held_item=held, controller_type=controller_type,
                        capsule=capsule, vehicle_type=vehicle_type,
                        head_position=head, owner=owner)
        except Exception as exc:
            self.warn("player context", exc)
            return None

    def spawn_site(self, context):
        origin, yaw = context["position"], math.radians(context["yaw"])
        x = int(math.floor(origin[0] - math.sin(yaw) * 2.0))
        z = int(math.floor(origin[2] + math.cos(yaw) * 2.0))
        top = int(math.floor(origin[1] + 0.2))
        dim = context["dimension"]
        chunk = self.f.CreateChunkSource(self.level)
        blocks = self.f.CreateBlockInfo(self.level)
        for y in range(top + 1, top - 3, -1):
            if not chunk.CheckChunkState(dim, (x, y, z)):
                continue
            below = blocks.GetBlockNew((x, y - 1, z), dim)
            foot = blocks.GetBlockNew((x, y, z), dim)
            head = blocks.GetBlockNew((x, y + 1, z), dim)
            if not all(isinstance(block, dict) for block in (below, foot, head)):
                continue
            if (below.get("name") in PREVIEW_FLOORS and
                    foot.get("name") == "minecraft:air" and head.get("name") == "minecraft:air"):
                return (x + 0.5, y + 0.08, z + 0.5)
        return None

    def flight_area_clear(self, dimension, start, end):
        """Check a short swept volume using existing documented block APIs.

        The inflated AABB is deliberately conservative around corners. Fluids,
        plants and unknown block types count as obstacles in this prototype.
        Missing query results fail closed; this method never loads chunks.
        """
        start, end = vector(start), vector(end)
        if start is None or end is None:
            return False
        low = (min(start[0], end[0])-FLIGHT_HALF_WIDTH,
               min(start[1], end[1]), min(start[2], end[2])-FLIGHT_HALF_WIDTH)
        high = (max(start[0], end[0])+FLIGHT_HALF_WIDTH,
                max(start[1], end[1])+FLIGHT_HEIGHT,
                max(start[2], end[2])+FLIGHT_HALF_WIDTH)
        bounds = [(int(math.floor(low[i])), int(math.floor(high[i]))) for i in range(3)]
        count = 1
        for begin, finish in bounds:
            count *= finish-begin+1
        if count > 128:
            return False
        try:
            chunks = self.f.CreateChunkSource(self.level)
            blocks = self.f.CreateBlockInfo(self.level)
            for x in range(bounds[0][0], bounds[0][1]+1):
                for y in range(bounds[1][0], bounds[1][1]+1):
                    for z in range(bounds[2][0], bounds[2][1]+1):
                        point = (x, y, z)
                        if not chunks.CheckChunkState(dimension, point):
                            return False
                        block = blocks.GetBlockNew(point, dimension)
                        if not isinstance(block, dict) or block.get('name') != 'minecraft:air':
                            return False
            return True
        except Exception as exc:
            self.warn('flight clearance', exc)
            return False

    def flight_site(self, context, ground_site, movement):
        ground = vector(ground_site)
        height = finite(movement.get('launch_height'))
        if ground is None or height is None or not .08 <= height <= 4.0:
            return None
        site = (ground[0], float(math.floor(ground[1]))+height, ground[2])
        return site if self.flight_area_clear(context['dimension'], ground, site) else None

    def air_record(self, record):
        # Persisted cleanup rows predate transient mobility state. Their exact
        # catalog definition still selects the right braking behavior.
        if record.get('mobility') in ('ground', 'air', 'glider'):
            return record['mobility'] in ('air', 'glider')
        return catalog.definition(record.get('vehicle_type', catalog.DEFAULT_VEHICLE))['movement']['kind'] in ('air', 'glider')

    def placement_site(self, context, placement):
        """Rebuild and validate the clicked site using only this player's world.

        GetPos is the documented server player-head reference. Raycasts use
        the authoritative dimension and the first BLOCK hit, never client hit
        coordinates. Failed/unavailable queries reject placement.
        """
        x, y, z = placement['block']
        site = (x + 0.5, y + 1.08, z + 0.5)
        body = context['position']
        if sum((site[i] - body[i]) ** 2 for i in range(3)) > 16.0:
            return None, 'placement_out_of_range'
        head = vector(context.get('head_position'))
        if head is None:
            return None, 'player_unavailable'
        # Aim just inside the top so a non-penetrating ray hits the support.
        target = (x + 0.5, y + 0.999, z + 0.5)
        delta = tuple(target[i] - head[i] for i in range(3))
        length = math.sqrt(sum(part * part for part in delta))
        if length <= 0.001 or length > 4.0:
            return None, 'placement_out_of_range'
        dim = context['dimension']
        chunk = self.f.CreateChunkSource(self.level)
        blocks = self.f.CreateBlockInfo(self.level)
        try:
            for pos in ((x, y, z), (x, y + 1, z), (x, y + 2, z)):
                if not chunk.CheckChunkState(dim, pos):
                    return None, 'no_safe_loaded_ground'
            support = blocks.GetBlockNew((x, y, z), dim)
            foot = blocks.GetBlockNew((x, y + 1, z), dim)
            upper = blocks.GetBlockNew((x, y + 2, z), dim)
            if (not all(isinstance(row, dict) for row in (support, foot, upper)) or
                    support.get('name') not in PREVIEW_FLOORS or
                    foot.get('name') != 'minecraft:air' or
                    upper.get('name') != 'minecraft:air'):
                return None, 'no_safe_loaded_ground'
            # A short diagonal may cross a chunk not containing either end.
            steps = max(1, int(math.ceil(length * 4.0)))
            for step in range(steps + 1):
                point = tuple(int(math.floor(head[i] + delta[i] * step / steps))
                              for i in range(3))
                if not chunk.CheckChunkState(dim, point):
                    return None, 'no_safe_loaded_ground'
            hits = api.getEntitiesOrBlockFromRay(
                dim, head, tuple(part / length for part in delta),
                max(1, int(math.ceil(length))), False, self.enums.RayFilterType.OnlyBlocks)
            if not isinstance(hits, list) or not hits or not isinstance(hits[0], dict):
                return None, 'placement_not_visible'
            hit = hits[0]
            point = vector(hit.get('hitPos'))
            if (hit.get('type') != 'Block' or vector(hit.get('pos')) != (x, y, z) or
                    point is None or abs(point[1] - (y + 1.0)) > 0.02 or
                    not x <= point[0] <= x + 1.0 or not z <= point[2] <= z + 1.0):
                return None, 'placement_not_visible'
            return site, None
        except Exception as exc:
            self.warn('placement validation', exc)
            return None, 'placement_not_visible'

    def spawn(self, position, dimension, yaw, vehicle_id, entity_type):
        if not self.preview_entity_type(entity_type):
            return None
        entity = self.system.CreateEngineEntityByTypeStr(entity_type, position,
                                                        (0.0, yaw), dimension)
        if entity in (None, "", "-1"):
            return None
        try:
            tag = self.f.CreateExtraData(entity)
            if not tag.SetExtraData(storage.ENTITY_TAG, vehicle_id, True):
                raise ValueError("entity tag write failed")
            if tag.GetExtraData(storage.ENTITY_TAG) != vehicle_id:
                raise ValueError("entity tag readback mismatch")
            return entity
        except Exception as exc:
            self.warn("tag preview", exc)
            # Exact ID from this creation call only, never a world-wide cleanup.
            if not self.system.DestroyEntity(entity):
                self.warn("untagged preview cleanup", entity)
            return None

    def owned(self, record):
        entity = record["entity_id"]
        try:
            expected = record.get('entity_type', config.CAR_ENTITY)
            return (self.preview_entity_type(expected) and
                    self.f.CreateEngineType(entity).GetEngineTypeStr() == expected and
                    self.f.CreateExtraData(entity).GetExtraData(storage.ENTITY_TAG) == record["vehicle_id"])
        except Exception:
            return False

    def inspect(self, record):
        if not self.owned(record):
            return None
        try:
            entity = record["entity_id"]
            pos = vector(self.f.CreatePos(entity).GetFootPos())
            motion = vector(self.f.CreateActorMotion(entity).GetMotion())
            dimension = self.f.CreateDimension(entity).GetEntityDimensionId()
            hp = finite(self.f.CreateAttr(entity).GetAttrValue(self.enums.AttrType.HEALTH))
            if pos is None or motion is None or dimension is None or hp is None:
                return None
            result = dict(position=pos, motion=motion, dimension=dimension, hp=hp)
            if self.air_record(record):
                rot = self.f.CreateRot(entity).GetRot()
                result['yaw'] = finite(rot[1]) if isinstance(rot, (tuple, list)) and len(rot) == 2 else None
                result['pitch'] = finite(rot[0]) if isinstance(rot, (tuple, list)) and len(rot) == 2 else None
            return result
        except Exception as exc:
            self.warn("inspect preview", exc)
            return None

    def move(self, record, motion):
        if not self.owned(record) or vector(motion) is None:
            return False
        if self.air_record(record):
            # Neutral always remains available for a safe three-axis hover,
            # even when the swept destination has just unloaded.
            if any(abs(part) > 0.0 for part in motion):
                if record.get('mobility') == 'glider':
                    return self.move_glider(record, motion).get('ok', False)
                observed = self.inspect(record)
                if not observed:
                    return False
                movement = catalog.definition(record['vehicle_type'])['movement']
                speed = movement['max_speed'] * movement['boost_multiplier']
                vertical = movement['vertical_speed'] * movement['boost_multiplier']
                if (sum(part*part for part in motion) > speed*speed+1.e-9 or
                        abs(motion[1]) > vertical+1.e-9):
                    return False
                ahead = tuple(observed['position'][i]+motion[i]*2.0 for i in range(3))
                base = finite(record.get('flight_base_y'))
                if base is None:
                    return False
                low, high = base+.08, base+movement['max_altitude']
                # Allow movement back into the envelope after external knockback.
                if ((ahead[1] > high+1.e-6 and motion[1] >= 0) or
                        (ahead[1] < low-1.e-6 and motion[1] <= 0)):
                    return False
                if not self.flight_area_clear(observed['dimension'], observed['position'], ahead):
                    return False
            return bool(self.safe('SetMotion flight', lambda: self.f.CreateActorMotion(
                record['entity_id']).SetMotion(motion), False))
        # Never drive deliberately into an unloaded chunk. This does not move
        # the player body or claim to force client terrain streaming.
        if abs(motion[0]) + abs(motion[2]) > 0:
            observed = self.inspect(record)
            if not observed:
                return False
            ahead = tuple(int(math.floor(observed['position'][i] + motion[i] * 2.0))
                          for i in range(3))
            if not self.safe('motion chunk', lambda: self.f.CreateChunkSource(
                    self.level).CheckChunkState(observed['dimension'], ahead), False):
                return False
        return bool(self.safe("SetMotion", lambda: self.f.CreateActorMotion(
            record["entity_id"]).SetMotion(motion), False))

    def turn(self, record, yaw):
        if self.owned(record):
            self.safe("SetRot", lambda: self.f.CreateRot(record["entity_id"]).SetRot((0.0, yaw)))

    def turn_flight(self, record, yaw, pitch):
        if self.owned(record):
            self.safe('SetRot flight', lambda: self.f.CreateRot(record['entity_id']).SetRot((pitch, yaw)))

    def move_glider(self, record, motion):
        """Sweep a short, bounded vehicle volume; never infer impact from failure.

        Only known full-cube preview blocks can trigger automatic detonation.
        Unknown shapes, fluids and unloaded cells stop flight without explosion.
        This is a pre-contact collision check, not a native physics event.
        """
        motion = vector(motion)
        observed = self.inspect(record) if self.owned(record) else None
        if motion is None or observed is None:
            return {'ok':False, 'code':'unavailable'}
        movement = catalog.definition(record['vehicle_type'])['movement']
        magnitude_squared = sum(v*v for v in motion)
        if (movement.get('kind') != 'glider' or magnitude_squared > movement['max_speed']**2+1.e-9 or
                magnitude_squared < movement['min_speed']**2-1.e-9):
            return {'ok':False, 'code':'speed_limit'}
        start = observed['position']
        end = tuple(start[i]+motion[i]*2. for i in range(3))
        base = finite(record.get('flight_base_y'))
        if base is None or (end[1] > base+movement['max_altitude']+1.e-6 and motion[1] >= 0):
            return {'ok':False, 'code':'height_limit'}
        low = (min(start[0],end[0])-FLIGHT_HALF_WIDTH,min(start[1],end[1]),min(start[2],end[2])-FLIGHT_HALF_WIDTH)
        high = (max(start[0],end[0])+FLIGHT_HALF_WIDTH,max(start[1],end[1])+FLIGHT_HEIGHT,max(start[2],end[2])+FLIGHT_HALF_WIDTH)
        bounds = [(int(math.floor(low[i])),int(math.floor(high[i]))) for i in range(3)]
        if any(b-a+1 > 6 for a,b in bounds):
            return {'ok':False, 'code':'invalid_sweep'}
        impact = False
        try:
            chunks=self.f.CreateChunkSource(self.level);blocks=self.f.CreateBlockInfo(self.level)
            for x in range(bounds[0][0],bounds[0][1]+1):
                for y in range(bounds[1][0],bounds[1][1]+1):
                    for z in range(bounds[2][0],bounds[2][1]+1):
                        point=(x,y,z)
                        if not chunks.CheckChunkState(observed['dimension'],point):
                            return {'ok':False,'code':'unloaded'}
                        block=blocks.GetBlockNew(point,observed['dimension'])
                        if not isinstance(block,dict) or not block.get('name'):
                            return {'ok':False,'code':'query_failed'}
                        if block['name']=='minecraft:air':continue
                        # Minkowski-expanded full cube + segment slab test,
                        # avoiding false impacts at the swept AABB's corners.
                        bmin=(x-FLIGHT_HALF_WIDTH,y-FLIGHT_HEIGHT,z-FLIGHT_HALF_WIDTH)
                        bmax=(x+1.+FLIGHT_HALF_WIDTH,y+1.,z+1.+FLIGHT_HALF_WIDTH)
                        enter,leave=0.,1.
                        for axis in range(3):
                            delta=end[axis]-start[axis]
                            if abs(delta)<1.e-9:
                                if not bmin[axis] <= start[axis] <= bmax[axis]:enter,leave=1.,0.;break
                            else:
                                a=(bmin[axis]-start[axis])/delta;b=(bmax[axis]-start[axis])/delta
                                enter=max(enter,min(a,b));leave=min(leave,max(a,b))
                        if enter>leave:continue
                        if block['name'] not in PREVIEW_FLOORS:
                            return {'ok':False,'code':'unknown_obstacle'}
                        impact=True
            if impact:
                return {'ok':False,'impact':True,'code':'verified_full_cube_impact'}
            accepted=self.f.CreateActorMotion(record['entity_id']).SetMotion(motion)
            return {'ok':bool(accepted),'code':'moving' if accepted else 'motion_failed'}
        except Exception as exc:
            self.warn('glider movement',exc)
            return {'ok':False,'code':'query_failed'}

    def brake(self, record):
        observed = self.inspect(record)
        if observed:
            self.move(record, (0.0, 0.0 if self.air_record(record) else observed["motion"][1], 0.0))

    def destroy_owned(self, record):
        if not self.owned(record):
            # Unloaded, missing and foreign identities are not interchangeable.
            # Keep the journal until an explicit remove event or exact match.
            return False
        return bool(self.safe("DestroyEntity", lambda: self.system.DestroyEntity(
            record["entity_id"]), False))

    def notify(self, player, event, payload):
        if player in api.GetPlayerList():
            self.safe("notify " + event, lambda: self.system.NotifyToClient(player, event, payload))

    def preview_tag(self, entity):
        try:
            if not self.preview_entity_type(self.f.CreateEngineType(entity).GetEngineTypeStr()):
                return None
            tag = self.f.CreateExtraData(entity).GetExtraData(storage.ENTITY_TAG)
            return tag if storage.identifier(tag) else None
        except Exception:
            return None

    def loaded_preview_ids(self):
        # Only used for pending cleanup, not a per-frame/world-wide gameplay scan.
        # Filter by exact namespace BEFORE reading any per-entity metadata.
        rows = self.safe("loaded entities", lambda: api.GetEngineActor(), {})
        if not isinstance(rows, dict):
            return []
        return [entity for entity, row in rows.items()
                if isinstance(row, dict) and self.preview_entity_type(row.get("identifier"))]
