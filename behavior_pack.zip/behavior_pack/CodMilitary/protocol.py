# -*- coding: utf-8 -*-
"""Pure, bounded wire validators. Sender identity comes from engine __id__.

Unknown fields are dropped, including playerId and any client-supplied
loadout. These validators do not authenticate sessions or reject replayed
sequence numbers; the authoritative server performs those stateful checks.
"""

import math

from . import config, catalog

try:
    integer_types = (int, long)
    string_types = (basestring,)
except NameError:
    integer_types = (int,)
    string_types = (str,)

NUMBER_TYPES = integer_types + (float,)
ACTIONS = ('deploy', 'connect', 'activate', 'exit', 'recall', 'status', 'ability', 'select_vehicle')
MAX_REQUEST_ID = 2147483647
COMBAT_EVENT_NAMES = ('hurt_car', 'hurt_player', 'deploy', 'jump', 'destroy', 'recover',
                     'detonate', 'hit', 'kill')


def _placement(value):
    """A clicked top face only; never accept a client spawn point/dimension."""
    if not isinstance(value, dict) or set(value) != set(('block', 'face')):
        raise ValueError('placement must contain only block and face')
    block = value.get('block')
    if not isinstance(block, list) or len(block) != 3:
        raise ValueError('placement block must be three integers')
    for index, coordinate in enumerate(block):
        if isinstance(coordinate, bool) or not isinstance(coordinate, integer_types):
            raise ValueError('placement block must be three integers')
        low, high = (-31999, 31997) if index == 1 else (-29999999, 29999999)
        if coordinate < low or coordinate > high:
            raise ValueError('placement block is outside the allowed range')
    if _positive_integer(value.get('face'), 'placement face', 1) != 1:
        raise ValueError('placement requires a top face')
    return {'block': tuple(block), 'face': 1}


def _positive_integer(value, field, maximum=None):
    if isinstance(value, bool) or not isinstance(value, integer_types):
        raise ValueError(field + ' must be an integer')
    if value <= 0 or (maximum is not None and value > maximum):
        raise ValueError(field + ' is outside the allowed range')
    return value


def _payload_version(payload):
    if not isinstance(payload, dict):
        raise ValueError('payload must be a dictionary')
    version = payload.get('protocol')
    if isinstance(version, bool) or not isinstance(version, integer_types):
        raise ValueError('protocol must be an integer')
    if version != config.PROTOCOL_VERSION:
        raise ValueError('unsupported protocol')
    return version


def _session(value, required, field='session'):
    if value is None and not required:
        return None
    if not isinstance(value, string_types):
        raise ValueError(field + ' must be an ASCII string')
    if len(value) > 64 or (required and not value):
        raise ValueError('invalid ' + field + ' length')
    try:
        value.encode('ascii')
    except (UnicodeEncodeError, UnicodeDecodeError):
        raise ValueError(field + ' must be ASCII')
    return value


def _finite_number(value, field):
    if isinstance(value, bool) or not isinstance(value, NUMBER_TYPES):
        raise ValueError(field + ' must be a number')
    try:
        number = float(value)
    except (OverflowError, ValueError):
        raise ValueError(field + ' must be finite')
    if math.isnan(number) or math.isinf(number):
        raise ValueError(field + ' must be finite')
    return number


def validate_command(payload):
    """Return a normalized command; optional missing/None session is None."""
    version = _payload_version(payload)
    request_id = _positive_integer(
        payload.get('request_id'), 'request_id', MAX_REQUEST_ID)
    action = payload.get('action')
    if not isinstance(action, string_types) or action not in ACTIONS:
        raise ValueError('unsupported action')
    result = {
        'protocol': version,
        'request_id': request_id,
        'action': action,
        'session': _session(payload.get('session'), action in ('activate', 'ability')),
        'client_nonce': _session(payload.get('client_nonce', 'legacy'),
                                 True, 'client_nonce'),
    }
    if 'placement' in payload:
        if action != 'deploy':
            raise ValueError('placement is only valid for deploy')
        result['placement'] = _placement(payload['placement'])
    if action == 'select_vehicle':
        vehicle_type = payload.get('vehicle_type')
        if not isinstance(vehicle_type, string_types) or vehicle_type not in catalog.VEHICLE_IDS:
            raise ValueError('unsupported vehicle type')
        result['vehicle_type'] = vehicle_type
    if action == 'ability':
        ability = payload.get('ability')
        if not isinstance(ability, string_types) or ability not in catalog.ABILITIES:
            raise ValueError('unsupported ability')
        result['ability'] = ability
        confirmed = payload.get('confirmed', False)
        if not isinstance(confirmed, bool):
            raise ValueError('confirmation must be boolean')
        result['confirmed'] = confirmed
    return result


def validate_input(payload):
    """Validate axes, normalize yaw to [-180,180), and clamp pitch."""
    version = _payload_version(payload)
    session = _session(payload.get('session'), True)
    seq = _positive_integer(payload.get('seq'), 'seq', MAX_REQUEST_ID)
    forward = _finite_number(payload.get('forward'), 'forward')
    strafe = _finite_number(payload.get('strafe'), 'strafe')
    vertical = _finite_number(payload.get('vertical', 0.0), 'vertical')
    if any(not -1.0 <= value <= 1.0 for value in (forward, strafe, vertical)):
        raise ValueError('movement axis outside [-1,1]')
    yaw = _finite_number(payload.get('yaw'), 'yaw')
    pitch = _finite_number(payload.get('pitch'), 'pitch')
    jump = payload.get('jump')
    if not isinstance(jump, bool):
        raise ValueError('jump must be a boolean')
    boost = payload.get('boost', False)
    if not isinstance(boost, bool):
        raise ValueError('boost must be a boolean')
    return {
        'protocol': version,
        'session': session,
        'client_nonce': _session(payload.get('client_nonce', 'legacy'), True, 'client_nonce'),
        'seq': seq,
        'forward': forward,
        'strafe': strafe,
        'vertical': vertical,
        'boost': boost,
        'yaw': (yaw + 180.0) % 360.0 - 180.0,
        'pitch': max(-89.0, min(89.0, pitch)),
        'jump': jump,
    }
