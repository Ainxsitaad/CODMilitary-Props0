# -*- coding: utf-8 -*-
"""Small engine-event layer over the fixed-vehicle authority service.

Damage sounds are confirmed by an observed health decrease, never merely by
an attack intent or a mutable pre-damage event. No legacy equipment imports.
"""
import math
import uuid
import copy
from CodMilitary import config, protocol, catalog
from CodMilitary.service import CarService


class PlayableCarService(CarService):
    def __init__(self, engine):
        CarService.__init__(self, engine)
        self.event_epoch = uuid.uuid4().hex
        self.event_seq = 0
        self.damage_before = {}
        self.pending_hurt = []
        self.pending_blast = []

    def begin_blast_hit(self, record, entity, hp, position):
        # Register before Hurt: MobDieEvent may be synchronous, and the vehicle
        # is removed immediately after the one authoritative blast pass.
        attempt = dict(tick=self.tick, record=copy.deepcopy(record), entity=entity,
                       before=hp, position=position, after=None, accepted=False,
                       applying=True, source_confirmed=False, killed=False)
        self.pending_blast.append(attempt)
        self.pending_blast = self.pending_blast[-64:]
        return attempt

    def emit_event(self, record, name, position=None, damage=None, target=None):
        if name not in protocol.COMBAT_EVENT_NAMES or not record.get('player'):
            return None
        if position is None:
            observed = self.engine.inspect(record)
            position = observed['position'] if observed else None
        if not isinstance(position, (tuple, list)) or len(position) != 3:
            return None
        self.event_seq += 1
        message = {'protocol': config.PROTOCOL_VERSION,
                   'event_id': self.event_epoch + ':' + str(self.event_seq),
                   'name': name, 'position': list(position),
                   'entity_id': record['player'] if name == 'hurt_player' else record['entity_id'],
                   'vehicle_id': record['vehicle_id'], 'vehicle_type': record.get('vehicle_type'),
                   'source_entity_id': record['entity_id'], 'player_id': record['player'],
                   'confirmed': True, 'server_tick': self.tick,
                   'dimension': record.get('dimension')}
        sounds = catalog.definition(record['vehicle_type']).get('sounds', {})
        message['sound_id'] = sounds.get('destroy' if name == 'detonate' else name)
        if target is not None:
            message['target_entity_id'] = target
        if damage is not None:
            message['damage'] = max(0.0, float(damage))
        self.engine.notify(record['player'], 'CarCombatEvent', message)
        return message

    def damage(self, args):
        entity = args.get('entityId')
        if not self._positive_damage(args.get('damage')):
            return
        if any(entity in (row.get('player'), row['entity_id']) for row in self.records.values()):
            self.damage_before[entity] = (self.tick, self.engine.entity_health(entity))

    @staticmethod
    def _positive_damage(amount):
        return (not isinstance(amount, bool) and isinstance(amount, (int, float)) and
                not math.isnan(float(amount)) and 0 < amount < 1000000)

    def actual_hurt(self, args):
        entity, amount = args.get('entityId'), args.get('damage')
        if not self._positive_damage(amount):
            return
        for attempt in self.pending_blast:
            row = attempt['record']
            if (attempt['entity'] == entity and self.tick - attempt['tick'] <= 2 and
                    args.get('srcId') == row['player'] and
                    args.get('projectileId') == row['entity_id']):
                attempt['source_confirmed'] = True
        before = self.damage_before.get(entity)
        if not before or before[1] is None or self.tick - before[0] > 2:
            return
        for record in list(self.records.values()):
            name = ('hurt_car' if entity == record['entity_id'] else
                    'hurt_player' if entity == record.get('player') else None)
            if name:
                row = (self.tick, record, entity, name, before[1], amount,
                       self.engine.entity_position(entity))
                if row not in self.pending_hurt:
                    self.pending_hurt.append(row)
        self.pending_hurt = self.pending_hurt[-64:]

    def mob_die(self, args):
        for attempt in self.pending_blast:
            if (attempt['entity'] == args.get('id') and self.tick - attempt['tick'] <= 2 and
                    args.get('attacker') == attempt['record']['player'] and
                    (attempt['applying'] or attempt['source_confirmed'])):
                attempt['killed'] = True
        # The owned vehicle's death is cleanup, never an implicit detonation.
        for record in list(self.records.values()):
            if record['entity_id'] == args.get('id'):
                self.retire(record, 'vehicle_destroyed')

    def step(self):
        CarService.step(self)
        pending_blast = []
        for attempt in self.pending_blast:
            if not attempt['accepted']:
                continue
            hp = attempt['after']
            if hp is None and attempt['source_confirmed']:
                hp = self.engine.entity_health(attempt['entity'])
            if attempt['killed'] or hp == 0:
                self.emit_event(attempt['record'], 'kill', attempt['position'], attempt['before'], attempt['entity'])
            elif hp is not None and 0 < hp < attempt['before']:
                self.emit_event(attempt['record'], 'hit', attempt['position'], attempt['before'] - hp, attempt['entity'])
            elif self.tick - attempt['tick'] < 2:
                # A null health query is not death: it can mean unloading.
                attempt['after'] = None
                pending_blast.append(attempt)
        self.pending_blast = pending_blast
        pending = []
        for tick, record, entity, name, before, amount, position in self.pending_hurt:
            hp = self.engine.entity_health(entity)
            if hp is not None and hp < before:
                self.emit_event(record, name, position, min(amount, before - hp))
                if (name == 'hurt_player' and self.control_reserved(record.get('player'))
                        and not self.engine.operator_snapshot(record)):
                    self.stop(record, 'body_hurt')
                    self.snapshot(record['player'])
            elif self.tick - tick < 2:
                pending.append((tick, record, entity, name, before, amount, position))
        self.pending_hurt = pending
        self.damage_before = dict((key, value) for key, value in self.damage_before.items()
                                  if self.tick - value[0] <= 2)
