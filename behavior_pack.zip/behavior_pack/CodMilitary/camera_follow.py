# -*- coding: utf-8 -*-
"""Bounded third-person camera geometry, independent of the engine bridge.

Ray casts use the documented integer distance and precise hitPos contract.
A missing hit is clear space; bridge failures and malformed block hits abort
camera control rather than allowing a camera to pass through unknown terrain.
"""
import math
import sys
import time
from collections import deque


def monotonic_time():
    """Use a monotonic wall clock; Python 2 Unix CPU time is not suitable."""
    clock = getattr(time, 'monotonic', None)
    if clock is None and sys.platform == 'win32':
        clock = getattr(time, 'clock', None)
    try:
        return number(clock(), None) if clock else None
    except Exception:
        return None


class DelayedFootAnchor(object):
    """100ms delayed physical samples; no render-bone dependency or extrapolation.

    Repeated frame reads are not new physics samples. After a long idle an old
    position anchor may be inserted only inside the continuously observed idle
    interval, so the first moving step does not interpolate across that idle.
    """
    DELAY = .100
    MAX_GAP = .5
    TELEPORT = 1.5
    MAX_SAMPLES = 16

    def __init__(self):
        self.reset()

    def reset(self):
        self.samples = deque()
        self.last_now = None
        self.last_foot = None
        self.stable_since = None
        self.did_reset = True
        self.source = 'foot'

    def sample(self, foot, now):
        foot, now = vector(foot), number(now, None)
        if foot is None:
            self.reset()
            raise ValueError('physical camera anchor missing')
        if now is None:
            had_samples = bool(self.samples)
            self.reset()
            self.did_reset = had_samples
            return foot
        reset = self.last_now is None or now < self.last_now or now-self.last_now > self.MAX_GAP
        if self.last_foot is not None:
            reset = reset or sum((foot[i]-self.last_foot[i])**2 for i in range(3)) > self.TELEPORT**2
            reset = reset or now == self.last_now and foot != self.last_foot
        self.did_reset = reset
        if reset:
            self.samples.clear()
            self.samples.append((now, foot))
            self.stable_since = now
        elif foot != self.last_foot:
            if now-self.samples[-1][0] > self.DELAY:
                anchor_time = min(self.last_now, max(self.stable_since, now-.05))
                if anchor_time > self.samples[-1][0]:
                    self.samples.append((anchor_time, self.last_foot))
            self.samples.append((now, foot))
            self.stable_since = now
        self.last_now, self.last_foot = now, foot
        self.source = 'delayed_foot'
        target = now-self.DELAY
        while len(self.samples) > 2 and self.samples[1][0] <= target:
            self.samples.popleft()
        while len(self.samples) > self.MAX_SAMPLES:
            # Preserve the target's left bracket even at very high render rates.
            # Coarsen an interior interval using its observed endpoints only.
            oldest = self.samples.popleft()
            self.samples.popleft()
            self.samples.appendleft(oldest)
        if target <= self.samples[0][0]:
            return self.samples[0][1]
        for index in range(1, len(self.samples)):
            right_time, right = self.samples[index]
            left_time, left = self.samples[index-1]
            if target <= right_time:
                amount = (target-left_time)/(right_time-left_time)
                return tuple(left[i]+(right[i]-left[i])*amount for i in range(3))
        return self.samples[-1][1]


def number(value, default):
    try:
        result = float(value)
        return default if math.isnan(result) or math.isinf(result) else result
    except (TypeError, ValueError, OverflowError):
        return default


def bounded(value, default, low, high):
    return min(high, max(low, number(value, default)))


def vector(value):
    if not isinstance(value, (tuple, list)) or len(value) != 3:
        return None
    result = tuple(number(component, None) for component in value)
    return result if all(component is not None for component in result) else None


def unit(value):
    value = vector(value)
    if value is None:
        raise ValueError('camera direction missing')
    length = math.sqrt(sum(component * component for component in value))
    if length < .0001:
        raise ValueError('camera direction empty')
    return tuple(component / length for component in value)


def settings(row):
    row = row if isinstance(row, dict) else {}
    mode = row.get('mode', 'third_person_follow')
    if mode not in ('third_person_follow', 'first_person_drone', 'third_person_glider'):
        raise ValueError('camera mode not implemented')
    if mode == 'first_person_drone':
        return dict(mode=mode, height=bounded(row.get('height'), .28, .1, 1.5),
                    distance=bounded(row.get('distance'), .65, .1, 1.5),
                    anchor_height=bounded(row.get('anchor_height'), .28, .1, 1.5))
    if mode == 'third_person_glider':
        return dict(mode=mode, height=bounded(row.get('height'), 1.1, .1, 4.),
                    distance=bounded(row.get('distance'), 3.6, .5, 8.),
                    anchor_height=bounded(row.get('anchor_height'), .3, .1, 1.5))
    return dict(mode=mode, height=bounded(row.get('height'), 1.1, .3, 4.),
                distance=bounded(row.get('distance'), 2.5, .5, 8.),
                anchor_height=bounded(row.get('anchor_height'), .35, .1, 1.5))


def rider_camera_settings(row, rider_foot, vehicle_foot, eye_height):
    """Relative native-camera configuration; no detached world position.

    GetFpHeight and observed rider/vehicle feet avoid assuming a seat eye height.
    Native third-person boom length and wall compression are retained: the SDK
    does not document a reliable default-arm offset to subtract from JSON range.
    First-person stays over the vehicle, rather than pushing its anchor forward
    into an unverified wall. Exact riding anchor behavior needs game calibration.
    """
    rider_foot, vehicle_foot = vector(rider_foot), vector(vehicle_foot)
    eye_height = number(eye_height, None)
    if (rider_foot is None or vehicle_foot is None or eye_height is None or
            not .1 <= eye_height <= 3. or
            sum((rider_foot[i]-vehicle_foot[i])**2 for i in range(3)) > 16.):
        raise ValueError('rider transform is not synchronized')
    config = settings(row)
    first_person = config['mode'] == 'first_person_drone'
    target_height = config['height'] if first_person else config['anchor_height']
    anchor_y = target_height-(rider_foot[1]-vehicle_foot[1])-eye_height
    if not -4. <= anchor_y <= 2.:
        raise ValueError('riding camera anchor outside supported envelope')
    return dict(perspective=0 if first_person else 1,
                anchor=(0., anchor_y, 0.),
                offset=(0., 0. if first_person else config['height']-config['anchor_height'], 0.))


def segment_limit(origin, direction, length, raycast):
    hits = raycast(origin, direction, max(1, int(math.ceil(length))))
    if hits is None:
        return length
    if not isinstance(hits, list):
        raise ValueError('camera ray response invalid')
    allowed = length
    for hit in hits:
        if not isinstance(hit, dict):
            raise ValueError('camera ray hit invalid')
        if hit.get('type') != 'Block':
            continue
        position = vector(hit.get('hitPos'))
        if position is None:
            raise ValueError('camera block hit has no precise position')
        along = sum((position[i] - origin[i]) * direction[i] for i in range(3))
        # The SDK ray is rounded up; a hit beyond our segment is irrelevant.
        if 0. <= along <= length + .001:
            allowed = min(allowed, max(0., along - .12))
    return allowed


def player_bounds(foot):
    """Controller body, raised arms and test computer plus near-plane padding.

    The active TP template reaches a 0.843-block horizontal radius across its
    poses; the old 0.48 body-only box let the camera enter the raised arms.
    1.05 covers that rig at any yaw, including the laptop, with 0.2 padding.
    Deliberately local: the controller is the only extra entity queried.
    """
    foot = vector(foot)
    if foot is None:
        raise ValueError('controller body position missing')
    return ((foot[0] - 1.05, foot[1] - .18, foot[2] - 1.05),
            (foot[0] + 1.05, foot[1] + 2.2, foot[2] + 1.05))


def body_segment_limit(origin, direction, length, boxes):
    """Clip a normalized segment against inflated player AABBs (slab test)."""
    allowed = length
    for box in boxes:
        if not isinstance(box, (tuple, list)) or len(box) != 2:
            raise ValueError('camera body bounds invalid')
        low, high = vector(box[0]), vector(box[1])
        if low is None or high is None or any(low[i] > high[i] for i in range(3)):
            raise ValueError('camera body bounds invalid')
        if all(low[i] <= origin[i] <= high[i] for i in range(3)):
            raise ValueError('camera anchor overlaps controller body')
        enter, leave = 0., allowed
        intersects = True
        for axis in range(3):
            if abs(direction[axis]) < .0000001:
                if origin[axis] < low[axis] or origin[axis] > high[axis]:
                    intersects = False
                    break
            else:
                a = (low[axis] - origin[axis]) / direction[axis]
                b = (high[axis] - origin[axis]) / direction[axis]
                enter, leave = max(enter, min(a, b)), min(leave, max(a, b))
                if enter > leave:
                    intersects = False
                    break
        if intersects:
            allowed = min(allowed, max(0., enter - .12))
    return allowed


class FollowCamera(object):
    """At most five probes/call; only small clear turns reuse verified margin."""
    def __init__(self):
        self.reset()

    def reset(self):
        self.tick = None
        self.offset = None
        self.distance = None
        self.direction = None
        self.anchor_height = None
        self.mode = None
        self.probe_direction = None
        self.probe_distance = None
        self.probe_clear = False

    def position(self, foot, forward, config, tick, raycast, body_boxes=()):
        foot = vector(foot)
        if foot is None:
            raise ValueError('vehicle position missing')
        config = settings(config)
        forward = unit(forward)
        anchor = (foot[0], foot[1] + config['anchor_height'], foot[2])
        direction_sign = 1. if config['mode'] == 'first_person_drone' else -1.
        desired = (foot[0] + direction_sign * forward[0] * config['distance'],
                   foot[1] + config['height'] + direction_sign * forward[1] * config['distance'],
                   foot[2] + direction_sign * forward[2] * config['distance'])
        if config['mode'] == 'third_person_follow':
            # A steep upward view formerly requested a point below the car's
            # feet. Never depend solely on a terrain ray to recover that point.
            desired = (desired[0], max(foot[1] + .25, desired[1]), desired[2])
        delta = tuple(desired[i] - anchor[i] for i in range(3))
        length = math.sqrt(sum(component * component for component in delta))
        direction = unit(delta)
        if self.tick == tick and self.offset is not None and self.mode == config['mode']:
            # The engine rotates the view each render frame, while script ticks
            # are 30Hz. Do not discard every intermediate direction. A clear
            # five-ray bundle has .12 side/up/down padding: only reuse half of
            # that margin, shortening the boom by the same endpoint change.
            # Larger/obstructed turns need a new bundle in this render frame.
            # Holding the old direction instead quantizes a 3.6-block glider
            # boom to 30Hz even at 60FPS: a 1-degree turn already exceeds .06.
            candidate = min(length, self.probe_distance)
            change = math.sqrt(sum((direction[i] * candidate -
                                   self.probe_direction[i] * self.probe_distance) ** 2 for i in range(3)))
            if self.probe_clear and change <= .06:
                candidate = max(0., candidate - change)
                self.distance = body_segment_limit(anchor, direction, candidate, body_boxes)
                self.direction = direction
                self.offset = tuple(anchor[i] - foot[i] + direction[i] * self.distance for i in range(3))
                return tuple(foot[i] + self.offset[i] for i in range(3))
        side = (direction[2], 0., -direction[0])
        if sum(component * component for component in side) < .0001:
            side = (1., 0., 0.)
        side = unit(side)
        probes = ((0., 0., 0.), tuple(.12 * v for v in side),
                  tuple(-.12 * v for v in side), (0., .12, 0.), (0., -.12, 0.))
        allowed = length
        for offset in probes:
            origin = tuple(anchor[i] + offset[i] for i in range(3))
            allowed = min(allowed, segment_limit(origin, direction, length, raycast))
        self.probe_clear = allowed == length
        allowed = body_segment_limit(anchor, direction, allowed, body_boxes)
        # Obstructions pull inward immediately. Extra render-frame probes may
        # not multiply the established .25-block/script-tick recovery budget.
        recovery = .25 if self.tick != tick else 0.
        distance = allowed if self.distance is None or self.mode != config['mode'] else min(allowed, self.distance + recovery)
        self.distance = distance
        self.direction = direction
        self.probe_direction = direction
        self.probe_distance = distance
        self.anchor_height = config['anchor_height']
        self.offset = tuple(anchor[i] - foot[i] + direction[i] * distance for i in range(3))
        self.tick = tick
        self.mode = config['mode']
        return tuple(foot[i] + self.offset[i] for i in range(3))
