# -*- coding: utf-8 -*-
"""Shared, engine-free angular flight dynamics (Python 2.7 compatible).

Angles use degrees, angular speeds degrees/second and dt seconds.  A critically
damped second-order spring follows aim instead of teleporting the flight axis.
Physics and render interpolation can use this same math at different rates.
"""
import math

try:
    NUMBER_TYPES = (int, long, float)
except NameError:
    NUMBER_TYPES = (int, float)

RESET_GAP_SECONDS = 0.25
INTEGRATION_STEP_SECONDS = 1.0 / 240.0
TURN_BOUNDS = {
    'response_seconds': (.05, 2.),
    'yaw_speed_degrees_per_second': (1., 360.),
    'yaw_acceleration_degrees_per_second_squared': (1., 3600.),
    'pitch_speed_degrees_per_second': (1., 180.),
    'pitch_acceleration_degrees_per_second_squared': (1., 1800.),
}


def finite(value):
    if isinstance(value, bool) or not isinstance(value, NUMBER_TYPES):
        return False
    try:
        return not math.isnan(float(value)) and not math.isinf(float(value))
    except (ValueError, OverflowError):
        return False


def wrap_degrees(angle):
    return (angle + 180.) % 360. - 180.


def shortest_delta(current, target):
    return wrap_degrees(target - current)


def valid_turn_inertia(settings):
    if not isinstance(settings, dict) or set(settings) != set(TURN_BOUNDS):
        return False
    return all(finite(settings[key]) and low <= settings[key] <= high
               for key, (low, high) in TURN_BOUNDS.items())


def _clamp(value, low, high):
    return max(low, min(high, value))


def advance_axis(angle, angular_velocity, target, dt, response_seconds,
                 max_speed_degrees_per_second,
                 max_acceleration_degrees_per_second_squared,
                 wrapped=False, lower=None, upper=None):
    """Return (angle, angular_velocity) after a bounded second-order step.

    x'' + 2*w*x' + w*w*(x-target) = 0, with w=2/response_seconds.
    Unconstrained intervals use the exact critical-damping solution.  Small
    substeps enforce acceleration/speed limits with trapezoidal displacement
    when the exact solution exceeds those bounds.  This keeps 30Hz physics and
    variable-rate rendering close without a frame-count-dependent lerp.

    A long frame gap retains the current pose and clears stored angular motion;
    it never catches up by jumping to the target. Hard pitch limits similarly
    discard only velocity pointing outside the allowed physical envelope.
    """
    values = (angle, angular_velocity, target, dt, response_seconds,
              max_speed_degrees_per_second,
              max_acceleration_degrees_per_second_squared)
    if (not all(finite(value) for value in values) or dt < 0 or
            response_seconds <= 0 or max_speed_degrees_per_second <= 0 or
            max_acceleration_degrees_per_second_squared <= 0):
        raise ValueError('angular dynamics require finite values and positive limits')
    if ((lower is not None and not finite(lower)) or
            (upper is not None and not finite(upper)) or
            (lower is not None and upper is not None and lower > upper) or
            (wrapped and (lower is not None or upper is not None))):
        raise ValueError('invalid angular envelope')
    if wrapped:
        angle = wrap_degrees(angle)
        target = angle + shortest_delta(angle, target)
    if lower is not None:
        angle, target = max(lower, angle), max(lower, target)
    if upper is not None:
        angle, target = min(upper, angle), min(upper, target)
    velocity = _clamp(angular_velocity, -max_speed_degrees_per_second,
                      max_speed_degrees_per_second)
    if ((lower is not None and angle <= lower and velocity < 0) or
            (upper is not None and angle >= upper and velocity > 0)):
        velocity = 0.
    if dt > RESET_GAP_SECONDS:
        return angle, 0.
    if dt == 0:
        return angle, velocity
    steps = max(1, int(math.ceil(dt / INTEGRATION_STEP_SECONDS)))
    step = dt / steps
    omega = 2. / response_seconds
    decay = math.exp(-omega * step)
    acceleration_step = max_acceleration_degrees_per_second_squared * step
    for unused in range(steps):
        error = angle - target
        coefficient = velocity + omega * error
        exact_angle = target + (error + coefficient * step) * decay
        exact_velocity = (velocity - omega * coefficient * step) * decay
        next_velocity = _clamp(exact_velocity, velocity - acceleration_step,
                               velocity + acceleration_step)
        next_velocity = _clamp(next_velocity, -max_speed_degrees_per_second,
                               max_speed_degrees_per_second)
        next_angle = (exact_angle if next_velocity == exact_velocity else
                      angle + (velocity + next_velocity) * .5 * step)
        if lower is not None and next_angle <= lower:
            next_angle, next_velocity = lower, max(0., next_velocity)
        if upper is not None and next_angle >= upper:
            next_angle, next_velocity = upper, min(0., next_velocity)
        angle, velocity = next_angle, next_velocity
    return (wrap_degrees(angle) if wrapped else angle), velocity


def advance_flight(record, data, stats, dt):
    """Produce authoritative orientation without mutating a rejected proposal."""
    settings = stats['turn_inertia']
    if not valid_turn_inertia(settings):
        raise ValueError('invalid flight turn_inertia')
    yaw, yaw_velocity = advance_axis(
        record.get('flight_yaw', record.get('yaw', 0.)),
        record.get('flight_yaw_velocity', 0.), data['yaw'], dt,
        settings['response_seconds'], settings['yaw_speed_degrees_per_second'],
        settings['yaw_acceleration_degrees_per_second_squared'], wrapped=True)
    pitch, pitch_velocity = 0., 0.
    if stats['mobility'] == 'glider':
        pitch, pitch_velocity = advance_axis(
            record.get('flight_pitch', 0.), record.get('flight_pitch_velocity', 0.),
            data['pitch'], dt, settings['response_seconds'],
            settings['pitch_speed_degrees_per_second'],
            settings['pitch_acceleration_degrees_per_second_squared'],
            lower=-stats['climb_pitch_limit'], upper=stats['dive_pitch_limit'])
    return dict(yaw=yaw, pitch=pitch, yaw_velocity=yaw_velocity,
                pitch_velocity=pitch_velocity)
