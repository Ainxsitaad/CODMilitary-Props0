# -*- coding: utf-8 -*-
"""Server-owned rider hiding, applied once per state change on every client."""
from CodMilitary.sdk_compat import sdk_argument

HIDDEN_ATTR = 'cm.vehicle.rider_hidden'
RETRY_TICKS = 3
MAX_PLAYERS = 128


def enabled(value):
    return value is True or value == 1


class RiderVisibility(object):
    def __init__(self, factory, logger=None):
        self.factory, self.logger = factory, logger
        self.players = {}
        self.tick = 0
        self.closed = False
        self.warned = set()

    def _warn(self, label, error):
        if label not in self.warned and self.logger:
            self.warned.add(label)
            try:
                self.logger('rider visibility %s: %s' % (label, error))
            except Exception:
                pass

    def _apply(self, row):
        desired = row['hidden']
        if row['applied'] == desired or self.tick < row['retry']:
            return
        row['retry'] = self.tick + RETRY_TICKS
        if not desired and not row['owned']:
            row['applied'] = False
            return
        try:
            if row['render'] is None:
                row['render'] = self.factory.CreateActorRender(row['player'])
            if desired and not row['owned']:
                previous = row['render'].GetNotRenderAtAll()
                if not isinstance(previous, bool):
                    raise RuntimeError('prior body visibility unavailable')
                row['previous_hidden'] = previous
            # Remember ownership before setters: rejected calls can partly apply.
            row['owned'] = True
            hidden = True if desired else row['previous_hidden']
            if row['render'].SetNotRenderAtAll(bool(hidden)) is not True:
                raise RuntimeError('body visibility rejected')
            if row['render'].SetPlayerItemInHandVisible(not desired, 0) is not True:
                raise RuntimeError('held-item visibility rejected')
            row['applied'] = desired
            row['owned'] = desired
            if not desired:
                row['previous_hidden'] = None
        except Exception as exc:
            row['applied'] = None
            self._warn('apply', exc)

    def _install(self, row):
        if row['retired'] or (row['subscribed'] and row['initialized']) or self.tick < row['retry']:
            return
        row['retry'] = self.tick + RETRY_TICKS
        try:
            attr = row['attr'] or self.factory.CreateModAttr(row['player'])
            row['attr'] = attr
            def changed(data):
                if row['retired'] or self.players.get(row['player']) is not row:
                    return
                if not isinstance(data, dict) or data.get('entityId', row['player']) != row['player']:
                    return
                row['hidden'] = enabled(data.get('newValue', 0))
                row['initialized'] = True
                row['retry'] = self.tick
                self._apply(row)
            if not row['subscribed']:
                row['callback'] = changed
                result = attr.RegisterUpdateFunc(sdk_argument(HIDDEN_ATTR), changed)
                if result is False:
                    raise RuntimeError('attribute subscription rejected')
                row['subscribed'] = True
            row['hidden'] = enabled(attr.GetAttr(sdk_argument(HIDDEN_ATTR), 0))
            row['initialized'] = True
            row['retry'] = self.tick
            self._apply(row)
        except Exception as exc:
            self._warn('subscribe', exc)

    def add(self, player, tick=0):
        if self.closed or not player:
            return False
        self.tick = max(self.tick, int(tick))
        if player not in self.players:
            if len(self.players) >= MAX_PLAYERS:
                return False
            self.players[player] = dict(player=player, hidden=False, applied=None,
                owned=False, render=None, attr=None, callback=None, subscribed=False,
                initialized=False, previous_hidden=None,
                retired=False, retry=0)
        row = self.players[player]
        if row['retired']:
            return False
        self._install(row)
        return row['subscribed']

    def refresh(self, player, tick=0):
        if player not in self.players:
            return self.add(player, tick)
        row = self.players[player]
        if row['retired'] or self.closed:
            return False
        self.tick = max(self.tick, int(tick))
        row['render'], row['applied'], row['retry'] = None, None, self.tick
        if row['subscribed']:
            try:
                row['hidden'] = enabled(row['attr'].GetAttr(sdk_argument(HIDDEN_ATTR), 0))
            except Exception as exc:
                self._warn('refresh', exc)
        self._install(row)
        self._apply(row)
        return row['subscribed']

    def hidden(self, player):
        row = self.players.get(player)
        return bool(row and (row['hidden'] or row['owned']))

    def hidden_ready(self, player):
        row = self.players.get(player)
        return bool(row and not row['retired'] and row['hidden'] and row['applied'] is True)

    def remove(self, player):
        row = self.players.get(player)
        if row is None:
            return
        row['retired'], row['hidden'], row['retry'] = True, False, self.tick
        if row['subscribed']:
            try:
                result = row['attr'].UnRegisterUpdateFunc(sdk_argument(HIDDEN_ATTR), row['callback'])
                if result is False:
                    raise RuntimeError('attribute unsubscribe rejected')
                row['subscribed'] = False
            except Exception as exc:
                self._warn('unsubscribe', exc)
        self._apply(row)
        if not row['owned'] and not row['subscribed']:
            self.players.pop(player, None)

    def step(self, tick):
        self.tick = int(tick)
        for player, row in list(self.players.items()):
            if row['retired']:
                if self.tick >= row['retry']:
                    self.remove(player)
            else:
                self._install(row)
                self._apply(row)

    def close(self):
        self.closed = True
        for player in list(self.players):
            self.remove(player)
