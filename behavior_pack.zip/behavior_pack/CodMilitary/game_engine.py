# -*- coding: utf-8 -*-
"""Fixed-vehicle SDK port. No chip, weapon or inventory transaction paths.

SDK sources: local mc-netease-sdk 1-ModAPI, entity attributes/Hurt,
world GetEntitiesAround/CanSee. Real-engine verification is still required.
"""
import math
import mod.server.extraServerApi as api
from CodMilitary.engine import EnginePort, finite, vector
from CodMilitary.service import distance
from CodMilitary.operator_link import OperatorLink


class GameplayPort(EnginePort):
    def __init__(self, system):
        EnginePort.__init__(self, system)
        self.operator_link = OperatorLink(self)

    def begin_control(self, record, context):
        return self.operator_link.begin(record, context)

    def end_control(self, record, reason):
        return self.operator_link.finish(record, reason)

    def control_error(self, record):
        return self.operator_link.check(record)

    def operator_snapshot(self, record):
        return self.operator_link.snapshot(record)

    def entity_health(self, entity):
        hp = finite(self.safe('entity health', lambda: self.f.CreateAttr(entity).
                              GetAttrValue(self.enums.AttrType.HEALTH)))
        # GetAttrValue returns -1 when the attribute is unavailable. Missing
        # health (including an entity disappearing) is not a death receipt.
        return hp if hp is not None and hp >= 0 else None

    def entity_position(self, entity):
        return vector(self.safe('entity position', lambda: self.f.CreatePos(entity).GetFootPos()))

    def configure_vehicle(self, record):
        if not self.owned(record):
            return False
        def configure():
            attr = self.f.CreateAttr(record['entity_id'])
            kind = self.enums.AttrType.HEALTH
            return bool(attr.SetAttrMaxValue(kind, record['max_hp']) and
                        attr.SetAttrValue(kind, record['hp']) and
                        finite(attr.GetAttrValue(kind)) == float(record['hp']))
        return bool(self.safe('configure vehicle', configure, False))

    def explode(self, record, parameters, feedback=None):
        """One authoritative area-damage pass, with no fire/block destruction.

        Players are excluded in this preview. CanSee is a conservative
        head-to-head visibility test, not a finished blast-occlusion model.
        No client-supplied target/radius/damage reaches this method.
        """
        if (parameters.get('kind') != 'explosion' or
                parameters.get('break_blocks') is not False or
                parameters.get('friendly_fire') is not False or
                parameters.get('damage_mode') != 'direct_health'):
            return False, 'capability_not_implemented'
        observed = self.inspect(record)
        if not observed:
            return False, 'vehicle_unavailable'
        radius, damage = finite(parameters.get('radius')), finite(parameters.get('damage'))
        if radius is None or damage is None or not 0 < radius <= 16 or not 0 < damage <= 1000:
            return False, 'capability_not_implemented'
        targets = self.game.GetEntitiesAround(record['entity_id'], int(math.ceil(radius)), {})
        if not isinstance(targets, list):
            return False, 'ability_failed'
        players = set(api.GetPlayerList())
        seen = set()
        for entity in targets:
            if entity in seen or entity == record['entity_id'] or entity in players:
                continue
            seen.add(entity)
            # Operator proxies represent players, so the preview's existing
            # no-player-blast policy must cover them as well as riding bodies.
            if self.safe('blast proxy type', lambda e=entity:
                         self.f.CreateEngineType(e).GetEngineTypeStr()) == 'cg_rc:operator_proxy':
                continue
            pos, hp = self.entity_position(entity), self.entity_health(entity)
            if pos is None or hp is None or hp <= 0 or distance(pos, observed['position']) > radius:
                continue
            dimension = self.safe('blast dimension', lambda e=entity:
                                  self.f.CreateDimension(e).GetEntityDimensionId())
            if dimension != observed['dimension']:
                continue
            visible = self.safe('blast visibility', lambda e=entity: self.game.CanSee(
                record['entity_id'], e, radius, True, 360.0, 360.0), False)
            if not visible:
                continue
            # Exactly one Hurt call per target. The configured direct-health
            # policy uses Override; no second CreateExplosion damage path.
            attempt = feedback(record, entity, hp, pos) if feedback else None
            accepted = self.safe('blast damage', lambda e=entity: self.f.CreateHurt(e).Hurt(
                damage, self.enums.ActorDamageCause.Override,
                record['player'], record['entity_id'], True), False)
            if attempt is not None:
                attempt['applying'] = False
                attempt['accepted'] = accepted is True
                attempt['after'] = self.entity_health(entity)
        return True, 'self_destructed'
