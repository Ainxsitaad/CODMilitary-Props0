# -*- coding: utf-8 -*-
"""Fixed vehicle definitions; presence in the catalog does not enable a plan.

The server resolves the chosen type; client data never defines its abilities.
"""
import copy
from CodMilitary.vehicle_registry import VEHICLE_DEFINITIONS, VEHICLE_ORDER, ITEM_DEFINITIONS, RESOURCE_CONTRACT

try:
    string_types = (basestring,)
except NameError:
    string_types = (str,)

DEFAULT_VEHICLE = 'explosive_car'
DEFAULT_VEHICLE_TYPE = DEFAULT_VEHICLE
VEHICLE_IDS = tuple(VEHICLE_ORDER)
VEHICLES = VEHICLE_DEFINITIONS
ABILITIES = ('self_destruct',)
CONTROLLER_ITEMS = tuple(VEHICLE_DEFINITIONS[k]['controller_item_id'] for k in VEHICLE_ORDER
                         if VEHICLE_DEFINITIONS[k].get('enabled'))
VEHICLE_ITEMS = tuple(VEHICLE_DEFINITIONS[k]['item_id'] for k in VEHICLE_ORDER
                     if VEHICLE_DEFINITIONS[k].get('enabled') and VEHICLE_DEFINITIONS[k].get('item_id'))


def definition(vehicle_type):
    if not isinstance(vehicle_type, string_types) or vehicle_type not in VEHICLE_DEFINITIONS:
        raise ValueError('unknown vehicle type')
    return copy.deepcopy(VEHICLE_DEFINITIONS[vehicle_type])


def available(vehicle_type):
    return (isinstance(vehicle_type, string_types) and vehicle_type in VEHICLE_DEFINITIONS
            and VEHICLE_DEFINITIONS[vehicle_type].get('enabled') is True)


def capabilities(vehicle_type):
    row = definition(vehicle_type)
    return sorted(row['abilities']) if row['enabled'] else []


def vehicle_for_item(item):
    if not isinstance(item, string_types):
        return None
    row = ITEM_DEFINITIONS.get(item, {})
    if row.get('resource_role') != 'vehicle':
        return None
    vehicle_type = row.get('vehicle_type')
    return vehicle_type if available(vehicle_type) and VEHICLE_DEFINITIONS[vehicle_type].get('item_id') == item else None


def controller_vehicle(item):
    if not isinstance(item, string_types):
        return None
    row = ITEM_DEFINITIONS.get(item, {})
    kind = row.get('vehicle_type')
    if row.get('resource_role') != 'controller' or not available(kind):
        return None
    return kind if VEHICLE_DEFINITIONS[kind].get('controller_item_id') == item else None


def controller_item(vehicle_type):
    if not available(vehicle_type):
        return None
    item = VEHICLE_DEFINITIONS[vehicle_type].get('controller_item_id')
    return item if controller_vehicle(item) == vehicle_type else None


def stats_for(vehicle_type):
    row = definition(vehicle_type)
    movement = row['movement']
    return {'hp': row['health'], 'max_speed': movement['max_speed'],
            'signal_warn': row['signal']['warn'], 'signal_cutoff': row['signal']['cutoff'],
            'lifetime_seconds': row['lifetime_seconds'],
            'deploy_ticks': row['deploy_ticks'], 'camera_height': row['camera']['height'],
            'jump_impulse': movement['jump_impulse'], 'velocity_blend': movement['velocity_blend'],
            'mobility': movement['kind'], 'entity_id': row['entity_id'], 'item_id': row['item_id'],
            'vertical_speed': movement.get('vertical_speed', 0.),
            'boost_multiplier': movement.get('boost_multiplier', 1.),
            'max_altitude': movement.get('max_altitude', 0.),
            'launch_height': movement.get('launch_height', 0.),
            'min_speed': movement.get('min_speed', 0.),
            'cruise_speed': movement.get('cruise_speed', 0.),
            'acceleration': movement.get('acceleration', .02),
            'turn_inertia': copy.deepcopy(movement.get('turn_inertia')),
            'climb_pitch_limit': movement.get('climb_pitch_limit', 35.),
            'dive_pitch_limit': movement.get('dive_pitch_limit', 65.),
            'dive_speed_bonus': movement.get('dive_speed_bonus', 0.)}


def item_definition(item_id):
    if not isinstance(item_id, string_types) or item_id not in ITEM_DEFINITIONS:
        raise ValueError('unknown item')
    return copy.deepcopy(ITEM_DEFINITIONS[item_id])


def resource_for(vehicle_type):
    definition(vehicle_type)
    return copy.deepcopy(RESOURCE_CONTRACT['vehicles'][vehicle_type])
