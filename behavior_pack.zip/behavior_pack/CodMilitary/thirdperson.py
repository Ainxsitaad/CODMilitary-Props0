# -*- coding: utf-8 -*-
"""Owned third-person arm poses on the real player; no geometry/skin replacement.

The native held tablet remains an attachable. Server ModAttr selects operation;
Molang checks the actual held item and native view/state on each render pass.
"""
from CodMilitary.sdk_compat import sdk_argument
from CodMilitary import presentation, catalog

CONTROL_ATTR = 'cm.vehicle.control_pose'
READY_QUERY = 'query.mod.cg_rc_tp_ready'
CONTROL_QUERY = 'query.mod.cg_rc_tp_controlled'
BASE_CONDITION = ("query.mod.cg_rc_tp_ready > 0 && !variable.is_first_person"
             " && !query.is_in_ui && !(variable.is_paperdoll ?? 0.0)"
             " && !(variable.map_face_icon ?? 0.0) && query.is_alive"
             " && !query.is_sleeping && !query.is_swimming && !query.is_gliding"
             " && !query.is_riding && !query.is_using_item")


def item_condition(item):
    return "query.is_item_name_any('slot.weapon.mainhand', '%s')" % item


def pose_alias(item, action):
    return 'cg_rc_tp_' + item.split(':', 1)[-1] + '_' + action


CONDITION = BASE_CONDITION + ' && (' + ' || '.join(item_condition(item) for item in catalog.CONTROLLER_ITEMS) + ')'
ALIASES = tuple(pose_alias(item, name) for item in catalog.CONTROLLER_ITEMS for name in ('idle', 'operate'))
RETRY_TICKS = 60
MAX_PLAYERS = 128


def enabled(value):
    return value is True or value == 1


class ThirdPersonTablet(object):
    def __init__(self, factory, level, localplayer, logger=None):
        self.factory, self.level, self.localplayer = factory, level, localplayer
        self.logger = logger
        self.players = {}
        self.registered = set()
        self.local_control = False
        self.closed = False
        self.tick = 0
        self.logged = set()

    def _log(self, label, error):
        if label in self.logged:
            return
        self.logged.add(label)
        if self.logger:
            try:
                callback = self.logger if callable(self.logger) else self.logger.warning
                callback('[RemoteCar ThirdPerson] ' + label + ': ' + str(error))
            except Exception:
                pass

    def _call(self, method, *args):
        result = method(*tuple(sdk_argument(value) for value in args))
        if result is False:
            raise RuntimeError('third-person API rejected ' + getattr(method, '__name__', 'call'))
        return result

    def _register(self):
        register = self.factory.CreateQueryVariable(self.level).Register
        for name in (READY_QUERY, CONTROL_QUERY):
            if name not in self.registered:
                self._call(register, name, 0.0)
                self.registered.add(name)

    def _write_control(self, row):
        value = self.local_control if row['player'] == self.localplayer else row['controlled']
        value = float(bool(value))
        if row['ready'] and value != row['last_control'] and self.tick >= row['control_retry_at']:
            try:
                self._call(row['query'].Set, CONTROL_QUERY, value)
                row['last_control'] = value
                row['control_retry_at'] = 0
            except Exception:
                # A bridge may mutate then reject: cached old state is unknown.
                row['last_control'] = None
                row['control_retry_at'] = self.tick + RETRY_TICKS
                raise

    def _install(self, row):
        if row['retired'] or row['ready'] or self.tick < row['retry_at']:
            return row['ready']
        row['retry_at'] = self.tick + RETRY_TICKS
        try:
            if row['cleanup'] and not self._cleanup(row):
                return False
            self._register()
            player = row['player']
            row['render'] = self.factory.CreateActorRender(player)
            row['query'] = self.factory.CreateQueryVariable(player)
            row['attr'] = self.factory.CreateModAttr(player)
            self._call(row['query'].Set, READY_QUERY, 0.0)
            self._call(row['query'].Set, CONTROL_QUERY, 0.0)

            def changed(data):
                if self.closed or row['retired'] or self.players.get(player) is not row:
                    return
                if not isinstance(data, dict) or data.get('entityId', player) != player:
                    return
                value = enabled(data.get('newValue', 0))
                if value != row['controlled']:
                    row['control_retry_at'] = self.tick
                row['controlled'] = value
                try:
                    self._write_control(row)
                except Exception as error:
                    self._log('attribute update', error)

            row['callback'] = changed
            row['subscribed'] = True
            self._call(row['attr'].RegisterUpdateFunc, CONTROL_ATTR, changed)
            row['controlled'] = enabled(row['attr'].GetAttr(sdk_argument(CONTROL_ATTR), 0))
            for item in catalog.CONTROLLER_ITEMS:
                for name, control in (('idle', '< 0.5'), ('operate', '>= 0.5')):
                    alias = pose_alias(item, name)
                    condition = BASE_CONDITION + ' && ' + item_condition(item) + ' && query.mod.cg_rc_tp_controlled ' + control
                    animation = presentation.hand_config(item).get('third_person_animations', {}).get(
                        name, 'animation.cg_rc.tablet_player.' + name)
                    self._call(row['render'].AddPlayerAnimation, alias, animation)
                    # Track before the write: a bridge may mutate then report failure.
                    row['scripts'].add(alias)
                    self._call(row['render'].AddPlayerScriptAnimate, alias, condition, True)
            self._call(row['render'].RebuildPlayerRender)
            row['ready'] = True
            row['last_control'] = None
            row['control_retry_at'] = self.tick
            self._write_control(row)
            self._call(row['query'].Set, READY_QUERY, 1.0)
            return True
        except Exception as error:
            self._log('install', error)
            row['ready'] = False
            self._queue_cleanup(row)
            self._cleanup(row)
            return False

    def add(self, player, tick=0):
        if self.closed or not player:
            return False
        self.tick = max(self.tick, int(tick))
        row = self.players.get(player)
        if row is not None and not row['retired']:
            return self._install(row)
        if row is not None and not self._cleanup(row):
            return False
        if len(self.players) >= MAX_PLAYERS and player not in self.players:
            self._log('player limit', MAX_PLAYERS)
            return False
        row = {'player': player, 'ready': False, 'retired': False, 'render': None,
               'query': None, 'attr': None, 'callback': None, 'subscribed': False,
               'controlled': False, 'last_control': None, 'retry_at': self.tick,
               'control_retry_at': self.tick,
               'refresh_pending': False,
               'scripts': set(), 'cleanup': []}
        self.players[player] = row
        return self._install(row)

    def refresh(self, player, tick=0):
        """Actor-created event may rebuild an existing player without removal."""
        if self.closed or not player:
            return False
        self.tick = max(self.tick, int(tick))
        if self.remove(player):
            return self.add(player, self.tick)
        self.players[player]['refresh_pending'] = True
        return False

    def set_local(self, active):
        if self.closed:
            return
        changed = self.local_control != bool(active)
        self.local_control = bool(active)
        row = self.players.get(self.localplayer)
        if row is not None and not row['retired']:
            if changed:
                row['control_retry_at'] = self.tick
            try:
                self._write_control(row)
            except Exception as error:
                self._log('local update', error)

    def _queue_cleanup(self, row):
        row['ready'] = False
        row['last_control'] = None
        if row['cleanup']:
            return
        if row['query'] is not None:
            row['cleanup'].extend((('query', READY_QUERY), ('query', CONTROL_QUERY)))
        if row['subscribed']:
            row['cleanup'].append(('unsubscribe', None))
        for alias in row['scripts']:
            row['cleanup'].append(('script', alias))
        if row['scripts']:
            row['cleanup'].append(('rebuild', None))

    def _cleanup(self, row):
        pending = []
        for operation, value in row['cleanup']:
            if operation == 'rebuild' and any(name == 'script' for name, unused in pending):
                pending.append((operation, value))
                continue
            try:
                if operation == 'query':
                    self._call(row['query'].Set, value, 0.0)
                elif operation == 'unsubscribe':
                    self._call(row['attr'].UnRegisterUpdateFunc, CONTROL_ATTR, row['callback'])
                    row['subscribed'] = False
                elif operation == 'script':
                    # No RemovePlayerScriptAnimate: neutralize only owned keys.
                    self._call(row['render'].AddPlayerScriptAnimate, value, '0.0', True)
                elif operation == 'rebuild':
                    self._call(row['render'].RebuildPlayerRender)
            except Exception as error:
                pending.append((operation, value))
                self._log('cleanup ' + operation, error)
        row['cleanup'] = pending
        if not pending:
            row['scripts'].clear()
        return not pending

    def remove(self, player):
        row = self.players.get(player)
        if row is None:
            return True
        row['retired'] = True
        row['refresh_pending'] = False
        self._queue_cleanup(row)
        if self._cleanup(row):
            self.players.pop(player, None)
            return True
        row['retry_at'] = self.tick + RETRY_TICKS
        return False

    def step(self, tick):
        self.tick = int(tick)
        retries = 0
        for player, row in list(self.players.items()):
            if row['ready']:
                desired = self.local_control if player == self.localplayer else row['controlled']
                if (row['last_control'] != float(bool(desired)) and self.tick >= row['control_retry_at']
                        and retries < 2):
                    retries += 1
                    try:
                        self._write_control(row)
                    except Exception as error:
                        self._log('control retry', error)
                continue
            if self.tick < row['retry_at'] or retries >= 2:
                continue
            retries += 1
            if row['retired'] or self.closed:
                if self._cleanup(row):
                    self.players.pop(player, None)
                    if row['refresh_pending'] and not self.closed:
                        self.add(player, self.tick)
                else:
                    row['retry_at'] = self.tick + RETRY_TICKS
            else:
                self._install(row)

    def close(self):
        self.closed = True
        self.local_control = False
        for player in list(self.players):
            self.remove(player)
        # Destroy has no guaranteed later tick. One bounded final retry handles
        # transient bridge failures; persistent failures remain logged/inert.
        for player, row in list(self.players.items()):
            if self._cleanup(row):
                self.players.pop(player, None)
