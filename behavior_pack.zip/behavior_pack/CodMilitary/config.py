# -*- coding: utf-8 -*-
"""Remote car prototype constants; game runtime must support Python 2.7."""

VERSION = '0.3.0'
NS = 'CodMilitary'
SERVER = 'RemoteCarServer'
CLIENT = 'RemoteCarClient'
PROTOCOL_VERSION = 2
CAR_ENTITY = 'cg_rc:remote_car'
TABLET_ITEM = 'cg_rc:explosive_car_controller'
CONTROLLER_ITEM = TABLET_ITEM  # Default-car compatibility alias; use catalog helpers for all types.
CAPSULE_ITEM = 'cg_rc:car_capsule'

TICK_RATE = 30
SNAPSHOT_INTERVAL = 5
INPUT_TIMEOUT_TICKS = 15
SESSION_TIMEOUT_TICKS = 60
CONNECT_TIMEOUT_TICKS = 90
DEPLOY_TICKS = 30
REQUEST_INTERVAL_TICKS = 3
PROTOTYPE_MODE = True
# Framework prototype only: survival inventory transactions are not enabled.
CREATIVE_TEST_BUILD = True
