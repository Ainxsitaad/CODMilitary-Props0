# -*- coding: utf-8 -*-
"""NetEase event bindings. Identity is ALWAYS the transport's __id__."""
import mod.server.extraServerApi as api
from mod_log import logger
from CodMilitary import config, catalog
from CodMilitary.game_engine import GameplayPort as EnginePort
from CodMilitary.runtime_service import PlayableCarService as CarService

Base = api.GetServerSystemCls()


class RemoteCarServer(Base):
    def __init__(self, namespace, name):
        Base.__init__(self, namespace, name)
        self.closed = False
        self.listeners = []
        self.port = EnginePort(self)
        self.service = CarService(self.port)
        self.port.operator_link.bind_service(self.service)
        self.loaded_candidates = set()
        self.pose_states = {}
        self.pose_retry = {}
        for event in ("CarSnapshot", "CarReply", "CarCombatEvent"):
            self.DefineEvent(event)
        self.listen(config.NS, config.CLIENT, "CarCommand", self.OnCommand)
        self.listen(config.NS, config.CLIENT, "CarInput", self.OnInput)
        self.listen(config.NS, config.CLIENT, "OperatorClientReady", self.OnOperatorReady)
        for event, callback in (
                ("OnScriptTickServer", self.OnTick),
                ("DelServerPlayerEvent", self.OnLeave),
                ("PlayerIntendLeaveServerEvent", self.OnIntendLeave),
                ("PlayerRespawnFinishServerEvent", self.OnRespawn),
                ("PlayerDieEvent", self.OnDeath),
                ("EntityRemoveEvent", self.OnRemove),
                ("AddEntityServerEvent", self.OnAdd),
                ("OnGroundServerEvent", self.OnGround),
                ("DamageEvent", self.OnDamage),
                ("ActuallyHurtServerEvent", self.OnActualHurt),
                ("MobDieEvent", self.OnMobDie),
                ("HealthChangeBeforeServerEvent", self.OnHealthBefore),
                ("HealthChangeServerEvent", self.OnHealthChanged),
                ("StartRidingServerEvent", self.OnStartRide),
                ("EntityStopRidingEvent", self.OnStopRide),
                ("PlayerAttackEntityEvent", self.CancelPlayerAction),
                ("PlayerInteractServerEvent", self.CancelPlayerAction),
                ("ServerPlayerTryDestroyBlockEvent", self.CancelPlayerAction),
                ("ServerItemUseOnEvent", self.CancelItemUse)):
            self.listen(api.GetEngineNamespace(), api.GetEngineSystemName(), event, callback)
        logger.info("[RemoteCar] framework %s loaded; creative fixed-vehicle preview", config.VERSION)

    def listen(self, namespace, system, event, callback):
        self.ListenForEvent(namespace, system, event, self, callback)
        self.listeners.append((namespace, system, event, callback))

    def sender(self, args):
        if not isinstance(args, dict):
            return None
        player = args.get("__id__")
        return player if player in api.GetPlayerList() else None

    def OnCommand(self, args):
        if self.closed:
            return
        player = self.sender(args)
        if player is not None:
            try:
                self.service.command(player, args)
            except Exception as exc:
                self.port.warn("command", exc)
                record = self.service.vehicle_for(player)
                if record:
                    self.service.stop(record, "adapter_failure")
                self.service.reply(player, {}, False, "adapter_failure")
                self.service.snapshot(player)

    def OnInput(self, args):
        if self.closed:
            return
        player = self.sender(args)
        if player is not None:
            try:
                self.service.input(player, args)
            except Exception as exc:
                self.port.warn('input', exc)
                record = self.service.vehicle_for(player)
                if record:
                    self.service.stop(record, 'adapter_failure')

    def OnTick(self, args=None):
        if self.closed:
            return
        self.port.operator_link.tick()
        self.service.step()
        if self.service.tick % 3 == 0:
            self.SyncControlPoses()
            candidates = list(self.loaded_candidates)
            self.loaded_candidates.clear()
            if candidates:
                self.ReconcileLoaded(candidates)
        # Recover entities that were already loaded before event registration.
        pending = any(record["state"] == "cleanup_pending"
                      for record in self.service.records.values())
        if pending and (self.service.tick == 30 or self.service.tick % 300 == 0):
            self.ReconcileLoaded()

    def ReconcileLoaded(self, candidates=()):
        # Include all loaded identities so a duplicated tag is ambiguous even
        # when only one of its entities fired AddEntityServerEvent this tick.
        grouped = {}
        for entity in set(self.port.loaded_preview_ids()) | set(candidates):
            tag = self.port.preview_tag(entity)
            if tag:
                grouped.setdefault(tag, []).append(entity)
        for tag, entities in grouped.items():
            if len(entities) == 1:
                self.service.loaded(entities[0], tag)

    def SyncControlPoses(self, clear=False):
        """Transient third-person pose; authority and lifetime stay on server.

        ModAttr automatically synchronizes to clients. It must not be saved
        into the world, and unchanged state must not generate network writes.
        """
        if not hasattr(self, 'pose_states'):
            self.pose_states, self.pose_retry = {}, {}
        players = set(api.GetPlayerList())
        for player in set(self.pose_states) | set(self.pose_retry):
            if player not in players:
                self.pose_states.pop(player, None)
                self.pose_retry.pop(player, None)
        for player in players:
            # The real body is hidden on the vehicle. The stationary proxy
            # has its own animation; do not animate the rider as an operator.
            value = 0
            if self.pose_states.get(player) == value:
                continue
            if not clear and self.service.tick < self.pose_retry.get(player, 0):
                continue
            try:
                result = self.port.f.CreateModAttr(player).SetAttr('cm.vehicle.control_pose', value, False, False)
                if result is False:
                    raise RuntimeError('control pose rejected')
                self.pose_states[player] = value
                self.pose_retry.pop(player, None)
            except Exception as exc:
                self.pose_retry[player] = self.service.tick + 60
                self.port.warn('control pose sync', exc)

    def OnLeave(self, args):
        player = args.get("id")
        self.service.owner_leave(player)
        self.port.owners.pop(player, None)
        self.pose_states.pop(player, None)
        self.pose_retry.pop(player, None)

    def OnOperatorReady(self, args):
        player = self.sender(args)
        if not self.closed and player is not None:
            self.port.operator_link.player_loaded(player)

    def OnRespawn(self, args):
        if not self.closed:
            self.port.operator_link.player_loaded(args.get('playerId'), respawn=True)

    def OnIntendLeave(self, args):
        player = args.get('playerId')
        self.port.operator_link.player_leaving(player)
        self.service.owner_leave(player)

    def OnDeath(self, args):
        self.port.operator_link.mob_die(args)
        self.service.owner_leave(args.get("id"), "owner_died")

    def OnRemove(self, args):
        self.port.operator_link.entity_removed(args.get('id'))
        self.service.removed(args.get("id"))

    def OnAdd(self, args):
        entity = args.get("id")
        if (self.port.preview_entity_type(args.get("engineTypeStr")) and entity and
                any(row['state'] == 'cleanup_pending' for row in self.service.records.values()) and
                len(self.loaded_candidates) < 64):
            self.loaded_candidates.add(entity)

    def OnGround(self, args):
        self.service.grounded(args.get("id"))

    def OnDamage(self, args):
        # The link zeros proxy/remote-body attacks and forwards allowed proxy
        # hits synchronously. Observe the remaining positive real-player hit
        # so the existing confirmed-health-decrease sound path still works.
        self.port.operator_link.damage(args)
        self.service.damage(args)

    def OnActualHurt(self, args):
        self.service.actual_hurt(args)

    def OnMobDie(self, args):
        self.port.operator_link.mob_die(args)
        self.service.mob_die(args)

    def OnHealthBefore(self, args):
        self.port.operator_link.health_before(args)

    def OnHealthChanged(self, args):
        self.port.operator_link.health_changed(args)

    def OnStartRide(self, args):
        self.port.operator_link.allow_ride(args)

    def OnStopRide(self, args):
        row = self.service.vehicle_for(args.get('id'))
        if (row and self.service.control_reserved(args.get('id')) and
                row['entity_id'] == args.get('rideId') and
                args.get('exitFromRider') and not args.get('entityIsBeingDestroyed') and
                not args.get('switchingRides')):
            args['cancel'] = True
        # Forced stop/teleport/death cannot be cancelled. The next authoritative
        # check observes the missing rider and returns through the same journal.

    def CancelPlayerAction(self, args):
        if self.service.control_reserved(args.get("playerId")):
            args["cancel"] = True

    def CancelItemUse(self, args):
        item = args.get('itemDict')
        held = (item.get('newItemName') or item.get('itemName')) if isinstance(item, dict) else None
        # The delayed CarCommand is the sole creation route. The native use
        # event may be absent when the client already canceled it with ret.
        if catalog.vehicle_for_item(held) or self.service.control_reserved(args.get("entityId")):
            args["ret"] = True

    def Destroy(self):
        if self.closed:
            return
        self.closed = True
        self.service.close()
        self.SyncControlPoses(clear=True)
        for namespace, system, event, callback in self.listeners:
            self.port.safe("unlisten " + event, lambda ns=namespace, sy=system, ev=event, cb=callback:
                           self.UnListenForEvent(ns, sy, ev, self, cb))
        self.listeners = []
