# -*- coding: utf-8 -*-
"""Server-owned vehicle movement and capability extension contracts."""
import re
try:
    string_types = (basestring,)
except NameError:
    string_types = (str,)

class HandlerRegistry(object):
    def __init__(self):
        self.handlers = {}

    def register(self, identifier, handler):
        if not isinstance(identifier, string_types) or not re.match(r'^[a-z][a-z0-9_]{0,47}$', identifier) or not callable(handler):
            raise ValueError('invalid vehicle handler')
        if identifier in self.handlers:
            raise ValueError('handler already registered')
        self.handlers[identifier] = handler

    def available(self, identifier):
        return identifier in self.handlers

    def execute(self, identifier, context):
        handler = self.handlers.get(identifier)
        if handler is None:
            return {'ok': False, 'code': 'capability_not_implemented'}
        # Context is server-owned. An enabled JSON definition alone cannot
        # implement a driver/ability or grant client authority.
        return handler(context)

class AbilityRegistry(HandlerRegistry):
    """handler({record, definition, tick}) -> {ok, code, delay_ticks}.

    Handlers propose a server-owned action; the lifecycle commits it. No
    client target, damage, inventory result or world coordinate is accepted.
    """

class MovementRegistry(HandlerRegistry):
    """handler({record, observed, input, stats}) -> velocity proposal.

    Air types must have an explicit implemented driver before deployment.
    Lifecycle, permissions, lifetime and camera restoration remain shared.
    """

FEATURES = {'fixed_vehicle_types': True, 'ground_remote_control': True,
            'self_destruct': True, 'air_flight': True,
            'glider_flight': True,
            'mounted_weapons': False, 'survival_inventory': False,
            'persistent_active_vehicle_restore': False,
            'two_phase_control': True, 'preview_cleanup_journal': True}
