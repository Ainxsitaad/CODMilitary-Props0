# -*- coding: utf-8 -*-
"""NetEase Remote Tactical Car. Python 2.7 compatible game package."""
