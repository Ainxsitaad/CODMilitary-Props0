# -*- coding: utf-8 -*-
"""Identity cleanup journal; NOT an active-vehicle or inventory save format.

Only the current product schema is accepted. Unknown fields or versions lock
the journal without replacing its contents or attempting a migration.
Only this product's cm.vehicle keys are accessed; other products' world data
is not read, migrated or overwritten. Sessions and active lifetime never reload.
"""
import copy
import json
import math
try:
    string_types = (basestring,)
    integer_types = (int, long)
except NameError:
    string_types = (str,)
    integer_types = (int,)
SCHEMA = 3
JOURNAL_FIELDS = frozenset(('schema', 'mode', 'records'))
JOURNAL_RECORD_FIELDS = frozenset(('vehicle_id', 'entity_id', 'owner',
                                 'entity_type', 'vehicle_type'))
JOURNAL_KEY = 'cm.vehicle.preview_journal.v1'
ENTITY_TAG = 'cm.vehicle.id.v1'
OWNER_KEY = 'cm.vehicle.owner_uuid.v1'
MAX_RECORDS = 64
INSTANCE_SCHEMA = 1
INSTANCE_FIELDS = frozenset(('schema', 'vehicle_id', 'owner', 'vehicle_type',
                             'remaining_seconds', 'hp', 'revision'))

def identifier(value):
    return isinstance(value, string_types) and 0 < len(value) <= 128

def validate_instance(raw):
    """Future persistent instance contract, pure validation only.

    The current preview does NOT save or restore this envelope. It deliberately
    excludes entity IDs, control tokens, input sequences and client UI state.
    Inventory commits and active-world recovery need a separate implementation.
    """
    if not isinstance(raw, dict) or set(raw) != INSTANCE_FIELDS:
        raise ValueError('invalid vehicle instance fields')
    if (isinstance(raw['schema'], bool) or raw['schema'] != INSTANCE_SCHEMA or
            not isinstance(raw['schema'], integer_types)):
        raise ValueError('unsupported vehicle instance schema')
    for name in ('vehicle_id', 'owner', 'vehicle_type'):
        if not identifier(raw[name]):
            raise ValueError('invalid vehicle instance identity')
    revision = raw['revision']
    if isinstance(revision, bool) or not isinstance(revision, integer_types) or not 0 <= revision <= 2147483647:
        raise ValueError('invalid vehicle instance revision')
    for name, maximum in (('remaining_seconds', 86400), ('hp', 1000000)):
        number = raw[name]
        if (isinstance(number, bool) or not isinstance(number, integer_types + (float,)) or
                not 0 <= number <= maximum or math.isnan(float(number)) or math.isinf(float(number))):
            raise ValueError('invalid vehicle instance value')
    return copy.deepcopy(raw)

def instance_envelope(record, revision=0):
    """Project a live record for future storage adapters; does not persist it."""
    row = dict((key, record[key]) for key in ('vehicle_id', 'owner', 'vehicle_type', 'hp'))
    row.update(schema=INSTANCE_SCHEMA, remaining_seconds=record['remaining_seconds'], revision=revision)
    return validate_instance(row)

def decode_journal(raw):
    if isinstance(raw, string_types):
        if len(raw) > 20000000:
            raise ValueError('preview journal too large')
        raw = json.loads(raw)
    if raw is None:
        return []
    if (not isinstance(raw, dict) or set(raw) != JOURNAL_FIELDS or
            isinstance(raw.get('schema'), bool) or
            not isinstance(raw.get('schema'), integer_types) or raw['schema'] != SCHEMA):
        raise ValueError('unsupported preview journal schema')
    if raw.get('mode') != 'preview_cleanup':
        raise ValueError('unexpected journal mode')
    rows = raw.get('records')
    if not isinstance(rows, list) or len(rows) > MAX_RECORDS:
        raise ValueError('invalid journal records')
    result, vehicles, entities, owners = [], set(), set(), set()
    for row in rows:
        if not isinstance(row, dict) or set(row) != JOURNAL_RECORD_FIELDS:
            raise ValueError('invalid journal entry')
        clean = dict((key, row[key]) for key in JOURNAL_RECORD_FIELDS)
        if not all(identifier(value) for value in clean.values()):
            raise ValueError('invalid journal identity')
        for key, seen in (('vehicle_id', vehicles), ('entity_id', entities), ('owner', owners)):
            if clean[key] in seen:
                raise ValueError('duplicate journal identity')
            seen.add(clean[key])
        result.append(clean)
    return result

def encode_journal(records):
    rows = []
    for record in records:
        row = dict((key, copy.deepcopy(record[key])) for key in JOURNAL_RECORD_FIELDS)
        rows.append(row)
    raw = {'schema': SCHEMA, 'mode': 'preview_cleanup', 'records': rows}
    decode_journal(raw)
    return raw
