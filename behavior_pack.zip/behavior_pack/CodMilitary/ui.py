# -*- coding: utf-8 -*-
"""Vehicle terminal and restrained COD-style health/time driving HUD."""
import mod.client.extraClientApi as api
from CodMilitary.client import finite, HOLD_ACTIONS, VEHICLE_ORDER, VERSION
from CodMilitary import catalog
Screen = api.GetScreenNodeCls()
HOLD_BUTTONS = ("forward", "back", "left", "right", "look_left", "look_right", "look_up", "look_down")
FLIGHT_BUTTONS = ("ascend", "descend", "boost")
GLIDER_BUTTONS = ("look_left", "look_right", "look_up", "look_down", "forward", "back", "boost")
IDLE_BUTTONS = ("deploy", "connect", "status", "recall_idle", "workshop", "inspect")
DRIVE_BUTTONS = ("jump", "self_destruct", "exit")
ACTION_BUTTONS = IDLE_BUTTONS + DRIVE_BUTTONS
WORKSHOP_BUTTONS = ("recover", "close")


class Controls(Screen):
    def __init__(self, namespace, name, params):
        Screen.__init__(self, namespace, name, params)
        self.system = params.get("system")
        self.controls = {}
        self.values = {}
        self.ready = False

    def Control(self, path):
        if path not in self.controls:
            control = self.GetBaseUIControl(path)
            if control is not None:
                self.controls[path] = control
            return control
        return self.controls[path]

    def Set(self, path, kind, value):
        key = (path, kind)
        if self.values.get(key) == value:
            return
        control = self.Control(path)
        if control is None:
            return
        if kind == "text":
            control.asLabel().SetText(value.replace(u"%", u"%%"))
        elif kind == "visible":
            control.SetVisible(value)
        elif kind == "alpha":
            control.SetAlpha(value)
        self.values[key] = value

    def Button(self, path):
        control = self.Control(path)
        if control is None:
            raise RuntimeError("Missing remote-car button: " + path)
        button = control.asButton()
        button.AddTouchEventParams({"isSwallow": True})
        return button

    def Name(self, args):
        return args.get("ButtonPath", "").rstrip("/").rsplit("/", 1)[-1]


class RemoteCarHUD(Controls):
    def Create(self):
        for name in HOLD_BUTTONS + FLIGHT_BUTTONS + ACTION_BUTTONS:
            group = ("drone_flight" if name in FLIGHT_BUTTONS else "drive" if name in HOLD_BUTTONS
                     else "idle" if name in IDLE_BUTTONS else "actions")
            button = self.Button("/" + group + "/" + name)
            button.SetButtonTouchDownCallback(self.OnDown)
            button.SetButtonTouchUpCallback(self.OnUp)
            button.SetButtonTouchCancelCallback(self.OnCancel)
            button.SetButtonTouchMoveOutCallback(self.OnCancel)
        for name in GLIDER_BUTTONS:
            button = self.Button('/glider_controls/' + name)
            button.SetButtonTouchDownCallback(self.OnDown)
            button.SetButtonTouchUpCallback(self.OnUp)
            button.SetButtonTouchCancelCallback(self.OnCancel)
            button.SetButtonTouchMoveOutCallback(self.OnCancel)
        self.ready = True
        self.Refresh()

    def OnDown(self, args):
        name = self.Name(args)
        if self.system and name in HOLD_ACTIONS:
            self.system.SetInput(name, True)

    def OnCancel(self, args):
        if self.system:
            self.system.SetInput(self.Name(args), False)

    def OnUp(self, args):
        if not self.system:
            return
        name = self.Name(args)
        if name in HOLD_ACTIONS:
            self.system.SetInput(name, False)
        elif name == "jump":
            self.system.Jump()
        elif name in ACTION_BUTTONS:
            self.system.RequestAction("recall" if name == "recall_idle" else name)
        self.Refresh()

    def Bar(self, name, value, maximum):
        fraction = max(0., min(1., finite(value) / max(.001, finite(maximum, 1.))))
        count = int(fraction * 20. + .999) if fraction else 0
        for index in range(20):
            self.Set("/telemetry/" + name + "/segment" + str(index), "visible", index < count)

    def DroneTelemetry(self, row, name):
        # Only authoritative snapshot data. Missing readings remain '--'; no
        # fake contacts, radar scans, altitude estimates or frame-time polling.
        altitude = finite(row.get('altitude'), None)
        speed = finite(row.get('horizontal_speed'), None)
        yaw = finite(row.get('yaw'), None)
        signal = finite(row.get('signal'), None)
        remaining = finite(row.get('remaining_seconds'), None)
        health, maximum = finite(row.get('hp'), None), finite(row.get('max_hp'), None)
        heading = None if yaw is None else (yaw + 180.) % 360.
        cardinal = (u'北', u'东北', u'东', u'东南', u'南', u'西南', u'西', u'西北')
        self.Set('/drone_overlay/name', 'text', u'机载视角 / ' + name)
        self.Set('/drone_overlay/heading', 'text', u'航向 --' if heading is None else
                 u'%03d° %s' % (int(heading) % 360, cardinal[int((heading + 22.5) // 45.) % 8]))
        self.Set('/drone_overlay/altitude', 'text', u'起飞点高度 --' if altitude is None else u'高度 %+.1f格' % altitude)
        self.Set('/drone_overlay/speed', 'text', u'水平速度 --' if speed is None else u'速度 %.1f格/秒' % max(0., speed))
        self.Set('/drone_overlay/signal', 'text', u'信号 --' if signal is None else
                 u'信号 %d%%' % int(max(0., min(1., signal)) * 100.))
        self.Set('/drone_overlay/health', 'text', u'机体 --' if health is None or maximum is None else
                 u'机体 %.0f/%.0f' % (max(0., health), max(0., maximum)))
        seconds = max(0, int(remaining)) if remaining is not None else None
        self.Set('/drone_overlay/time', 'text', u'剩余 --' if seconds is None else
                 u'剩余 %02d:%02d' % (seconds // 60, seconds % 60))
        self.Set('/drone_overlay/message', 'text', self.system.message[:44])

    def GliderTelemetry(self, row, name):
        speed, altitude = finite(row.get('horizontal_speed'), None), finite(row.get('altitude'), None)
        max_altitude = finite(row.get('max_altitude'), None)
        signal, life = finite(row.get('signal'), None), finite(row.get('remaining_seconds'), None)
        hp, maximum = finite(row.get('hp'), None), finite(row.get('max_hp'), None)
        self.Set('/glider_overlay/name', 'text', name + u' / 滑翔连接')
        self.Set('/glider_overlay/message', 'text', self.system.message[:44])
        self.Set('/glider_overlay/speed_value', 'text', u'速度 --' if speed is None else u'%.1f格/秒' % max(0., speed))
        self.Set('/glider_overlay/altitude_value', 'text', u'高度 --' if altitude is None else u'%+.1f格' % altitude)
        self.Set('/glider_overlay/altitude_max', 'text', u'--' if max_altitude is None else u'%.0f' % max_altitude)
        self.Set('/glider_overlay/link', 'text', u'信号 --' if signal is None else u'信号 %d%%' % int(max(0., min(1., signal))*100.))
        seconds = max(0, int(life)) if life is not None else None
        self.Set('/glider_overlay/life', 'text', u'剩余 --' if seconds is None else u'剩余 %02d:%02d' % (seconds//60, seconds%60))
        self.Set('/glider_overlay/health', 'text', u'机体 --' if hp is None or maximum is None else u'机体 %.0f/%.0f' % (max(0., hp), max(0., maximum)))
        self.Set('/glider_overlay/boost', 'visible', row.get('boosting') is True)
        # 0..10 is a display ruler in blocks/s, not a claim about top speed.
        for key, value, limit in (('speed', speed, 10.), ('altitude', altitude, max_altitude)):
            count = 0 if value is None or limit is None or limit <= 0 else int(min(1., max(0., value)/limit)*16+.5)
            for index in range(16):
                self.Set('/glider_overlay/' + key + '/segment' + str(index), 'visible', index < count)

    def Refresh(self):
        if not self.ready or not self.system:
            return
        system = self.system
        active = bool(system.active and not system.menu)
        flying = bool(active and system.IsDrone())
        gliding = bool(active and system.IsGlider())
        connecting = bool(system.pending and not system.menu)
        hand_item = getattr(system, "hand_item", None)
        capsule = catalog.vehicle_for_item(hand_item) is not None
        show = bool(not system.menu and (active or system.tablet or system.pending or hand_item))
        self.Set("/status", "visible", show and not active)
        self.Set("/idle", "visible", show and not active and not connecting)
        for name in IDLE_BUTTONS:
            self.Set("/idle/" + name, "visible", not capsule or name == "inspect")
        self.Set("/drive", "visible", active and not gliding)
        self.Set("/actions", "visible", active or connecting)
        self.Set("/actions/exit", "visible", active or connecting)
        self.Set('/actions/exit/caption', 'text', u'X 结束' if gliding else u'X 退出')
        self.Set("/actions/jump", "visible", active and not (flying or gliding))
        self.Set("/telemetry", "visible", active and not (flying or gliding))
        self.Set("/control_message", "visible", active and not (flying or gliding))
        self.Set("/drone_overlay", "visible", flying)
        self.Set("/drone_flight", "visible", flying)
        self.Set('/glider_overlay', 'visible', gliding)
        self.Set('/glider_controls', 'visible', gliding)
        self.Set("/control_message", "text", system.message[:44])
        row = system.vehicle or {}
        self.Set("/hurt_overlay", "visible", active and row.get("body_hurt") is True)
        self.Set("/hurt_overlay", "alpha", .22 + .12 * (system.tick % 10) / 10.)
        chosen = system.HeldVehicleType() or system.configuration['vehicle_type']
        definition = catalog.definition(chosen)
        name = row.get('display_name', definition.get('display_name', u'遥控载具')) if active else definition.get('display_name', u'遥控载具')
        if flying:
            self.DroneTelemetry(row, name)
        elif gliding:
            self.GliderTelemetry(row, name)
        item = catalog.ITEM_DEFINITIONS.get(system.HeldItemName(), {})
        self.Set("/status/title", "text", item.get('display_name', name))
        self.Set("/status/summary", "text", u"右键地面摆放 · " + name if capsule else u"固定载具：" + name)
        self.Set("/status/message", "text", system.message[:48])
        self.Set("/status/limit", "text", u"H检视 · 切换物品自动收放" if capsule else u"J道具说明 · G部署 · R接入 · H检视")
        remaining = max(0, int(finite(row.get('remaining_seconds'))))
        maximum = finite(row.get('lifetime_seconds'), 1.)
        self.Bar('health', row.get('hp'), row.get('max_hp'))
        self.Bar('time', remaining, maximum)
        self.Set("/telemetry/health_value", "text", u"%.0f/%.0f" % (finite(row.get('hp')), finite(row.get('max_hp'))))
        self.Set("/telemetry/time_value", "text", u"%02d:%02d" % (remaining // 60, remaining % 60))
        self.Set("/telemetry/name", "text", name)
        signal = max(0., min(1., finite(row.get('signal', 1.))))
        self.Set("/telemetry/link", "text", u"信号 %.0f%%" % (signal * 100.))
        can_detonate = 'self_destruct' in system.InstalledAbilities()
        self.Set("/actions/self_destruct", "visible", active and can_detonate)
        self.Set("/actions/self_destruct/caption", "text", u"F 确认引爆" if system.destruct_deadline > system.tick else u"F 引爆")
        phase = getattr(system, 'presentation_phase', 'idle')
        progress = max(0., min(1., finite(getattr(system, 'presentation_progress', 0.))))
        transition = show and phase in ('connect_open', 'connect_wait', 'disconnect')
        self.Set('/transition', 'visible', transition)
        self.Set('/transition/shade', 'alpha', .18 * (1. - progress if phase == 'disconnect' else progress))
        self.Set('/transition/label', 'text', u'连接载具...' if phase != 'disconnect' else u'退出控制')

    def Destroy(self):
        self.ready = False
        if self.system:
            self.system.OnHUDDestroyed(self)
        self.controls.clear()
        self.values.clear()


class RemoteCarWorkshop(Controls):
    """Legacy registered class name; the screen is now a vehicle terminal."""
    def Create(self):
        for name in WORKSHOP_BUTTONS:
            self.Button('/panel/' + name).SetButtonTouchUpCallback(self.OnButton)
        self.ready = True
        self.Refresh()

    def OnButton(self, args):
        if not self.system:
            return
        name = self.Name(args)
        if name == 'close':
            api.PopScreen()
            return
        if name == 'recover':
            self.system.RequestAction('recall')
        self.Refresh()

    def Refresh(self):
        if not self.ready or not self.system:
            return
        system = self.system
        held = system.HeldItemName()
        selected = catalog.controller_vehicle(held)
        if selected is None:
            self.Set('/panel/selected', 'text', u'当前未手持操控道具')
            for path in ('description', 'controls', 'details'):
                self.Set('/panel/' + path, 'text', u'')
            self.Set('/panel/note', 'text', u'请返回游戏，拿出要使用的道具。')
            self.Set('/panel/recover', 'visible', False)
            return
        row = catalog.definition(selected)
        item = catalog.item_definition(held)
        stats = catalog.stats_for(selected)
        self.Set('/panel/selected', 'text', u'手持道具：' + item.get('display_name', selected))
        self.Set('/panel/description', 'text', row.get('description', u''))
        flight = row['movement']['kind']
        controls = (u'W/S调速 · Shift加速 · 鼠标/方向键转向\nF二次确认引爆 · X结束并清理' if flight == 'glider'
                    else u'WASD移动 · 空格升/C降 · Shift加速\nF二次确认引爆 · X退出悬停' if flight == 'air'
                    else u'WASD移动 · 空格跳跃 · 鼠标/方向键转向\nF二次确认引爆 · X退出')
        self.Set('/panel/controls', 'text', controls)
        self.Set('/panel/details', 'text', u'生命 %d   使用时间 %d秒   信号范围 %.0f格' % (
            stats['hp'], stats['lifetime_seconds'], stats['signal_cutoff']))
        owned = system.vehicle or {}
        self.Set('/panel/recover', 'visible', owned.get('vehicle_type') == selected)
        self.Set('/panel/note', 'text', u'此物品固定绑定载具。返回游戏按G部署、R接入。')
        self.Set('/panel/message', 'text', system.message[:48])

    def Destroy(self):
        self.ready = False
        if self.system:
            self.system.OnWorkshopDestroyed(self)
        self.controls.clear()
        self.values.clear()
