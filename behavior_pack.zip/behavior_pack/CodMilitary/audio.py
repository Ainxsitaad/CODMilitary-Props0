# -*- coding: utf-8 -*-
"""Local sound presentation. Gameplay confirmation remains on the server.

Uses documented NetEase CustomAudio APIs, not a global music override. Short
movement segments avoid the engine's early StopCustomMusicById failure window.
"""
from collections import OrderedDict
import math
from CodMilitary.audio_registry import REGISTERED_SOUNDS
from CodMilitary import catalog
from CodMilitary.sdk_compat import sdk_argument

try:
    string_types = (basestring,)
except NameError:
    string_types = (str,)

HAND_ACTIONS = {
    'tablet': ('idle', 'draw', 'holster', 'inspect', 'connect_open'),
    'car': ('idle', 'draw', 'holster', 'inspect', 'place'),
}
EVENT_SOUNDS = {
    'hit': ('cg_rc.feedback.hit', .5), 'kill': ('cg_rc.feedback.kill', .55),
    'hurt_car': ('cg_rc.car.hurt', .55),
    'hurt_player': ('cg_rc.feedback.hurt_player', .45),
    'deploy': ('cg_rc.car.deploy', .45), 'jump': ('cg_rc.car.jump', .4),
    'destroy': ('cg_rc.car.destroy', .6), 'recover': ('cg_rc.car.recover', .4),
}
MOVEMENT_SOUND = 'cg_rc.car.move'


def item_family(item):
    if not isinstance(item, string_types):
        return None
    if item in HAND_ACTIONS:
        return item
    if catalog.controller_vehicle(item) is not None:
        return 'tablet'
    if catalog.vehicle_for_item(item) is not None:
        return 'car'
    return None


def valid_position(value):
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        return None
    try:
        result = tuple(float(x) for x in value)
    except (TypeError, ValueError, OverflowError):
        return None
    return None if any(math.isnan(x) or math.isinf(x) for x in result) else result


class SoundPresenter(object):
    def __init__(self, factory, level, player, logger=None):
        self.player = player
        self.logger = logger
        self.comp = None
        self._logged = set()
        self._seen = OrderedDict()
        self._active_names = set()
        self._last_action = None
        self._hand_name = None
        self._last_move_tick = None
        self._moving = False
        try:
            self.comp = factory.CreateCustomAudio(level)
        except Exception as error:
            self._log('create custom audio', error)

    def _log(self, label, error):
        if label in self._logged:
            return
        self._logged.add(label)
        if self.logger:
            try:
                self.logger('audio ' + label + ': ' + str(error))
            except Exception:
                pass

    def _play(self, name, volume, local=True, position=None, entity_id=None):
        if self.comp is None or not isinstance(name, string_types) or name not in REGISTERED_SOUNDS:
            return False
        try:
            engine_name = sdk_argument(name)
            if local:
                sound_id = self.comp.PlayCustomUIMusic(engine_name, volume, 1.0, False)
            else:
                pos = valid_position(position)
                if pos is None:
                    if not entity_id:
                        return False
                    pos = (0.0, 0.0, 0.0)
                sound_id = self.comp.PlayCustomMusic(engine_name, pos, volume, 1.0, False,
                                                     sdk_argument(entity_id))
            if sound_id is None or sound_id is False or str(sound_id).startswith('-'):
                self._log('play ' + name, sound_id)
                return False
            self._active_names.add(name)
            return True
        except Exception as error:
            self._log('play ' + name, error)
            return False

    def _stop_name(self, name, fade=.03):
        if not name or self.comp is None:
            return
        try:
            # Avoid StopCustomMusicById in its documented first-seven-frame
            # failure window. These names are exclusively owned by this mod.
            self.comp.StopCustomMusic(sdk_argument(name), fade)
        except Exception as error:
            self._log('stop ' + name, error)
        self._active_names.discard(name)

    def hand_action(self, action, item, event_id=None, sound_id=None, volume=None):
        family = item_family(item)
        key = (action, item, event_id)
        if key == self._last_action:
            return False
        self._last_action = key
        self._stop_name(self._hand_name)
        self._hand_name = None
        if family is None or action not in HAND_ACTIONS[family]:
            return False
        name = 'cg_rc.hand.' + family + '.' + action
        if sound_id is not None:
            if not isinstance(sound_id, string_types) or not sound_id.startswith('cg_rc.') or sound_id not in REGISTERED_SOUNDS:
                return False
            name = sound_id
        # Idle is a single subtle settling sound on entry, never a loop.
        try:
            volume = (.12 if action == 'idle' else .38) if volume is None else float(volume)
        except (ValueError, TypeError, OverflowError):
            return False
        if math.isnan(volume) or math.isinf(volume) or not 0 <= volume <= 1:
            return False
        played = self._play(name, volume)
        if played:
            self._hand_name = name
        return played

    def event(self, name, event_id, position=None, entity_id=None, confirmed=False, local=True,
              sound_id=None, volume=None):
        if name not in EVENT_SOUNDS or event_id is None:
            return False
        if name in ('hit', 'kill') and confirmed is not True:
            return False
        sound, default_volume = EVENT_SOUNDS[name]
        if sound_id is not None:
            if not isinstance(sound_id, string_types) or not sound_id.startswith('cg_rc.') or sound_id not in REGISTERED_SOUNDS:
                return False
            sound = sound_id
        try:
            volume = default_volume if volume is None else float(volume)
        except (ValueError, TypeError, OverflowError):
            return False
        if math.isnan(volume) or math.isinf(volume) or not 0 <= volume <= 1:
            return False
        key = (name, str(event_id))
        if key in self._seen:
            return False
        # Record before playback: duplicated server packets must not repeatedly
        # retry missing sounds or generate a burst after an engine error.
        self._seen[key] = True
        while len(self._seen) > 256:
            self._seen.popitem(last=False)
        return self._play(sound, volume, local, position, entity_id)

    def movement(self, moving, tick, entity_id=None, position=None, local=True, sound_id=None):
        sound = MOVEMENT_SOUND if sound_id is None else sound_id
        previous = getattr(self, '_move_name', MOVEMENT_SOUND)
        if not moving:
            if self._moving:
                self._stop_name(previous, .04)
            self._moving = False
            self._last_move_tick = None
            return False
        if not isinstance(sound, string_types) or sound not in REGISTERED_SOUNDS:
            return False
        if sound != previous:
            self._stop_name(previous, .04)
            self._last_move_tick = None
        self._move_name = sound
        try:
            tick = int(tick)
        except (ValueError, TypeError, OverflowError):
            return False
        self._moving = True
        if self._last_move_tick is not None and 0 <= tick - self._last_move_tick < 9:
            return False
        self._last_move_tick = tick
        return self._play(sound, .24, local, position, entity_id)

    def stop(self, preserve_combat=False):
        for name in tuple(self._active_names):
            if preserve_combat and name != self._hand_name and name != getattr(self, '_move_name', MOVEMENT_SOUND) and not name.startswith('cg_rc.hand.'):
                continue
            self._stop_name(name)
        self._hand_name = None
        self._last_action = None
        self._last_move_tick = None
        self._moving = False

    def close(self):
        self.stop()
        self.comp = None
